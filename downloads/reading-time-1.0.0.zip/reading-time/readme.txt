=== Reading Time ===
Contributors: yourname
Tags: tag1, tag2, tag3, tag4, tag5
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

One-line summary of what Reading Time does (max 150 chars).

== Description ==

Explain what the plugin does and why someone should install it.

= Free =
* Feature one
* Feature two

= Pro =
[Pro](https://example.com/reading-time-pro) adds ...

== Installation ==
1. Install and activate.
2. Go to Reading Time in the admin and configure it.

== Changelog ==
= 1.0.0 =
* Initial release.
