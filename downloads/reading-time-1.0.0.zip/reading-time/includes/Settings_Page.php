<?php
namespace ReadingTime;

use ReadingTime\Engine\Admin;
use ReadingTime\Engine\Freemium;
use ReadingTime\Engine\Settings;

defined( 'ABSPATH' ) || exit;

class Settings_Page {

	const SAVE = 'readtime_save_settings';

	public function hooks() {
		Admin::register_page( array( $this, 'render' ) );
		add_action( 'admin_post_' . self::SAVE, array( $this, 'save' ) );
	}

	public function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'reading-time' ), 403 );
		}
		check_admin_referer( self::SAVE );
		$in = wp_unslash( $_POST );
		Settings::update(
			array(
				'example_text'   => $in['example_text'] ?? '',
				'example_toggle' => $in['example_toggle'] ?? 'no',
			)
		);
		wp_safe_redirect( add_query_arg( array( 'page' => Admin::MENU_SLUG, 'updated' => 1 ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function render() {
		$s = Settings::all();
		?>
		<div class="wrap">
			<?php Admin::header( __( 'Reading Time', 'reading-time' ) ); ?>
			<?php if ( isset( $_GET['updated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only "saved" notice flag.
 echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Saved.', 'reading-time' ) . '</p></div>'; } ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
				<?php wp_nonce_field( self::SAVE ); ?>
				<table class="form-table" role="presentation">
					<tr><th><label for="example_text"><?php esc_html_e( 'Example text', 'reading-time' ); ?></label></th>
						<td><input name="example_text" id="example_text" class="regular-text" value="<?php echo esc_attr( $s['example_text'] ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Example toggle', 'reading-time' ); ?></th>
						<td><label><input type="checkbox" name="example_toggle" value="yes" <?php checked( $s['example_toggle'], 'yes' ); ?>> <?php esc_html_e( 'Enable', 'reading-time' ); ?></label></td></tr>
				</table>
				<?php
				// Advertise the Pro add-on here, on the plugin's own screen (wp.org guideline 11).
				// Describe it in words; never show its controls locked or greyed out (guideline 5).
				if ( ! Freemium::is_pro() ) :
					?>
					<h2><?php esc_html_e( 'Pro features', 'reading-time' ); ?> <?php echo wp_kses_post( Freemium::badge( 'settings' ) ); ?></h2>
					<p class="description"><?php esc_html_e( 'Describe what your Pro add-on adds.', 'reading-time' ); ?></p>
				<?php endif; ?>
				<?php submit_button( __( 'Save settings', 'reading-time' ) ); ?>
			</form>
		</div>
		<?php
	}
}
