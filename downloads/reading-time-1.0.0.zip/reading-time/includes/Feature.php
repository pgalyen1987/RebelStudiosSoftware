<?php
/**
 * Your plugin's feature goes here, and all of it works in the free plugin:
 * wordpress.org does not accept a plugin that locks its own code until someone pays.
 *
 * Pro features belong in a separate add-on plugin. It plugs in through hooks this
 * file fires, like the one in run(); add a hook wherever an add-on should be able
 * to extend what the free plugin does.
 *
 * @package ReadingTime
 */

namespace ReadingTime;

use ReadingTime\Engine\Settings;

defined( 'ABSPATH' ) || exit;

class Feature {

	public function hooks() {
		// Example: run on init. Replace with your real hooks.
		add_action( 'init', array( $this, 'run' ) );
	}

	public function run() {
		$settings = Settings::all();

		// ... your free feature, complete, using $settings ...

		/**
		 * Fires after the free feature has run. Your Pro add-on adds its features here.
		 *
		 * @param array $settings This plugin's saved settings.
		 */
		do_action( 'readtime_feature_run', $settings );
	}
}
