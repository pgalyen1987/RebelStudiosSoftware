<?php
namespace ReadingTime;

use ReadingTime\Engine\Admin;

defined( 'ABSPATH' ) || exit;

class Plugin {
	private static $instance;
	public static function instance() { return self::$instance ?: ( self::$instance = new self() ); }

	public function boot() {
		( new Feature() )->hooks();
		( new Settings_Page() )->hooks();
		Admin::enqueue();
	}
}
