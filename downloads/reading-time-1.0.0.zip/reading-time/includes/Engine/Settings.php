<?php
/**
 * Options wrapper: one serialized row, typed defaults, sanitized writes.
 * Add your settings to defaults() and sanitize_field().
 *
 * @package ReadingTime\Engine
 */

namespace ReadingTime\Engine;

defined( 'ABSPATH' ) || exit;

class Settings {

	const OPTION_KEY = 'readtime_settings';

	public static function defaults() {
		return array(
			// --- your settings here ---
			'example_text'   => '',
			'example_toggle' => 'no',
		);
	}

	public static function all() {
		$saved = get_option( self::OPTION_KEY, array() );
		return array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
	}

	public static function get( $key, $fallback = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/**
	 * Save settings. Pass values already unslashed, as Settings_Page::save() does with
	 * wp_unslash( $_POST ): WordPress slashes request data once, so unslashing again
	 * here would strip every backslash the user typed.
	 */
	public static function update( array $values ) {
		$current = self::all();
		$clean   = array();
		foreach ( self::defaults() as $key => $default ) {
			$clean[ $key ] = array_key_exists( $key, $values )
				? self::sanitize_field( $key, $values[ $key ], $default )
				: $current[ $key ];
		}
		update_option( self::OPTION_KEY, $clean );
		return $clean;
	}

	public static function seed_defaults() {
		if ( false === get_option( self::OPTION_KEY, false ) ) {
			add_option( self::OPTION_KEY, self::defaults() );
		}
	}

	private static function sanitize_field( $key, $value, $default ) {
		switch ( $key ) {
			case 'example_toggle':
				return 'yes' === $value ? 'yes' : 'no';
			// add cases for your fields
			default:
				return sanitize_text_field( $value );
		}
	}
}
