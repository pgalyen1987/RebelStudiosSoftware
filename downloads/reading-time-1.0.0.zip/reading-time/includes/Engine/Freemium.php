<?php
/**
 * Free / Pro switch.
 *
 * wordpress.org guideline 5: a plugin in the directory is complete on its own. Nothing
 * in it may be locked, limited or time-restricted until someone pays, so there is no
 * "is this feature allowed?" check here, and you should not add one.
 *
 * Pro features live in a separate add-on plugin that you sell yourself. The add-on
 * adds them on this plugin's hooks (see Feature.php) and, once its own licence check
 * passes, answers the `readtime_is_pro` filter with true. This plugin uses that
 * answer for one thing: hiding its "Get Pro" links.
 *
 * @package ReadingTime\Engine
 */

namespace ReadingTime\Engine;

defined( 'ABSPATH' ) || exit;

class Freemium {

	const IS_PRO_FILTER = 'readtime_is_pro';
	const UPGRADE_URL   = 'https://example.com/reading-time-pro'; // your sales page

	/** True once the Pro add-on is active and licensed. Hide upgrade links with it; never lock a feature. */
	public static function is_pro() {
		return (bool) apply_filters( self::IS_PRO_FILTER, false ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- the constant is this plugin's own prefixed hook.
	}

	public static function upgrade_url( $utm_content = 'generic' ) {
		return add_query_arg(
			array( 'utm_source' => 'plugin', 'utm_medium' => 'admin', 'utm_campaign' => 'reading-time', 'utm_content' => sanitize_key( $utm_content ) ),
			self::UPGRADE_URL
		);
	}

	public static function badge( $utm_content = 'badge' ) {
		return sprintf(
			' <a class="readtime-pro-pill" target="_blank" rel="noopener" href="%s">%s</a>',
			esc_url( self::upgrade_url( $utm_content ) ),
			esc_html__( 'Pro', 'reading-time' )
		);
	}
}
