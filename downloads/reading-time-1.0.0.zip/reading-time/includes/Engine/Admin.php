<?php
/**
 * Admin chrome: a top-level settings menu, shared asset enqueue, and a page
 * header carrying the upgrade button. Engine class.
 *
 * @package ReadingTime\Engine
 */

namespace ReadingTime\Engine;

defined( 'ABSPATH' ) || exit;

class Admin {

	const MENU_SLUG = 'reading-time';

	public static function register_page( $render_cb ) {
		add_action(
			'admin_menu',
			function () use ( $render_cb ) {
				add_menu_page(
					__( 'Reading Time', 'reading-time' ),
					__( 'Reading Time', 'reading-time' ),
					'manage_options',
					self::MENU_SLUG,
					$render_cb,
					'dashicons-admin-generic'
				);
			}
		);
	}

	public static function is_own_screen() {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$s = get_current_screen();
		return $s && false !== strpos( (string) $s->id, self::MENU_SLUG );
	}

	public static function enqueue() {
		add_action(
			'admin_enqueue_scripts',
			function () {
				if ( ! self::is_own_screen() ) {
					return;
				}
				wp_enqueue_style( 'readtime-admin', READTIME_URL . 'assets/admin.css', array(), READTIME_VERSION );
			}
		);
	}

	public static function header( $title ) {
		echo '<div class="readtime-header" style="display:flex;align-items:center;justify-content:space-between;margin:12px 0">';
		echo '<h1 style="margin:0">' . esc_html( $title ) . '</h1>';
		if ( ! Freemium::is_pro() ) {
			printf(
				'<a class="button button-primary" target="_blank" rel="noopener" href="%s">%s</a>',
				esc_url( Freemium::upgrade_url( 'header' ) ),
				esc_html__( 'Get Pro', 'reading-time' )
			);
		}
		echo '</div>';
	}
}
