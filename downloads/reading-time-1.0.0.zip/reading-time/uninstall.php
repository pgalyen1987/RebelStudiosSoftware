<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
delete_option( 'readtime_settings' );
