<?php
/**
 * Plugin Name:       Reading Time
 * Description:       One-line summary of what Reading Time does.
 * Version:           1.0.0
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Your Name
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       reading-time
 *
 * @package ReadingTime
 */

defined( 'ABSPATH' ) || exit;

define( 'READTIME_VERSION', '1.0.0' );
define( 'READTIME_FILE', __FILE__ );
define( 'READTIME_PATH', plugin_dir_path( __FILE__ ) );
define( 'READTIME_URL', plugin_dir_url( __FILE__ ) );
define( 'READTIME_BASENAME', plugin_basename( __FILE__ ) );

spl_autoload_register(
	function ( $class ) {
		$prefix = 'ReadingTime\\';
		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}
		$path = READTIME_PATH . 'includes/' . str_replace( '\\', '/', substr( $class, strlen( $prefix ) ) ) . '.php';
		if ( is_readable( $path ) ) {
			require $path;
		}
	}
);

add_action(
	'plugins_loaded',
	function () {
		// No load_plugin_textdomain(): since WordPress 4.6 translations for a plugin hosted on
		// wordpress.org load automatically, and Plugin Check flags the call as discouraged.
		\ReadingTime\Plugin::instance()->boot();
	}
);

register_activation_hook(
	__FILE__,
	function () {
		\ReadingTime\Engine\Settings::seed_defaults();
	}
);
