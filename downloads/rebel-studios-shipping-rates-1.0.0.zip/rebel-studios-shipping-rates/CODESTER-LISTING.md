# Codester listing — Rebel Studios Shipping Rates

**Product to upload:** `SAAS/codester/rebel-studios-shipping-rates-kit-1.0.0-codester.zip`  
(free parent + unlocked Pro in one pack — buyer already paid Codester)

**Preview image (800×400):** `SAAS/previews/codester/wc-shipping-preview-800x400.png`  
**Icon (200×200):** `SAAS/codester/assets/shipping-icon-200.png`  
**Live demo (Playground):** https://rebelstudiossoftware.com/demo-shipping.html  
(boots free plugin from wp.org once listed; until then demo page still documents the admin path)

---

## Title
Rebel Studios Shipping Rates for WooCommerce — Table Rate (Pro Unlocked)

## Short description (≤160 chars if field is tight)
Merchant-owned table rates by zone, weight, cart total and qty. No Jetpack. No live carrier API. Pro CSV + simulator unlocked.

## Full description

WooCommerce Shipping and Jetpack-backed live rates keep changing the deal: carrier accounts, credit cards on file, rates that jump overnight. This plugin does the opposite.

You write a **table of rates** on each shipping zone. A row matches on weight, cart subtotal and quantity. The first match wins. The customer sees the label you wrote — "Ground", "Free over $75", "Heavy parcel". Nothing phones home.

**What you get in this zip**

- Free parent: Rebel Shipping Rates method on any zone
- Flat cost plus optional per-item and per-weight add-ons
- Min/max conditions on weight, cart total, quantity (blank = skip)
- Pro unlocked: shipping-class conditions, stop-after-match, hide other methods, CSV import/export, cart simulator that shows which rule fired and why
- HPOS and block checkout declared compatible
- No licence key — Codester already collected payment

**What it cannot do**

- It does **not** call USPS, UPS, FedEx or any other live carrier API
- It does **not** buy or print postage labels
- It does **not** replace a label tool after the order is paid

If you need a printable label, use your carrier’s site or a label plugin after checkout. This product only decides what the customer is charged at checkout, from a table you control.

**Install**

1. Activate WooCommerce, then the free parent, then the Pro folder (both are in the kit).
2. WooCommerce → Settings → Shipping → open a zone → Add shipping method → Rebel Shipping Rates.
3. Fill the rate table. Save. Add a product with a weight and confirm the label on the cart.

Support: rebelstudiossoftware@gmail.com

## Tags / keywords
woocommerce shipping, table rate shipping, weight based shipping, flat rate shipping, shipping zones, no jetpack

## Category
WordPress / WooCommerce / Shipping

## Suggested price
$29 (one-time) — same ballpark as sibling Rebel Studios Codester Pro packs

## Demo
https://rebelstudiossoftware.com/demo-shipping.html (WordPress Playground; free plugin from wp.org when available)
