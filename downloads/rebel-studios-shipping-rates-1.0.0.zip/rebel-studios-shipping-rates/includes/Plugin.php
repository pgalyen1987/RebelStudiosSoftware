<?php
/**
 * Boots the shipping method and admin helpers.
 *
 * @package RebelStudios\ShippingRates
 */

namespace RebelStudios\ShippingRates;

defined( 'ABSPATH' ) || exit;

class Plugin {

	private static $instance;

	public static function instance() {
		return self::$instance ?: ( self::$instance = new self() );
	}

	public function boot() {
		add_action( 'woocommerce_shipping_init', array( $this, 'load_method' ) );
		add_filter( 'woocommerce_shipping_methods', array( $this, 'register_method' ) );
		add_filter( 'plugin_action_links_' . RSSHP_BASENAME, array( $this, 'action_links' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
	}

	public function load_method() {
		// Autoload brings Shipping_Method in; construct happens when WC instantiates it.
		class_exists( Shipping_Method::class );
	}

	/**
	 * @param array<string,string> $methods Methods keyed by id.
	 * @return array<string,string>
	 */
	public function register_method( $methods ) {
		$methods['rs_shipping_rates'] = Shipping_Method::class;
		return $methods;
	}

	/**
	 * @param array<int,string> $links Plugin row links.
	 * @return array<int,string>
	 */
	public function action_links( $links ) {
		$url = admin_url( 'admin.php?page=wc-settings&tab=shipping' );
		array_unshift(
			$links,
			sprintf(
				'<a href="%s">%s</a>',
				esc_url( $url ),
				esc_html__( 'Shipping zones', 'rebel-studios-shipping-rates' )
			)
		);
		if ( ! apply_filters( 'rsshp_is_pro', false ) ) {
			$links[] = sprintf(
				'<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>',
				esc_url( 'https://rebelstudiossoftware.com/wc-shipping-rates-pro' ),
				esc_html__( 'Get Pro', 'rebel-studios-shipping-rates' )
			);
		}
		return $links;
	}

	public function admin_assets( $hook ) {
		if ( 'woocommerce_page_wc-settings' !== $hook ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['tab'] ) || 'shipping' !== $_GET['tab'] ) {
			return;
		}
		wp_enqueue_style(
			'rsshp-admin',
			RSSHP_URL . 'assets/admin.css',
			array(),
			RSSHP_VERSION
		);
	}
}
