<?php
/**
 * Normalise and evaluate table-rate rows.
 *
 * @package RebelStudios\ShippingRates
 */

namespace RebelStudios\ShippingRates\Engine;

defined( 'ABSPATH' ) || exit;

class Rules {

	/**
	 * Empty starter row for the settings UI.
	 *
	 * @return array<string,mixed>
	 */
	public static function blank_row() {
		return array(
			'enabled'           => 'yes',
			'label'             => '',
			'cost'               => '0',
			'cost_per_item'      => '',
			'cost_per_weight'    => '',
			'min_weight'         => '',
			'max_weight'         => '',
			'min_subtotal'       => '',
			'max_subtotal'       => '',
			'min_qty'            => '',
			'max_qty'            => '',
			'shipping_class'     => '',
			'abort'              => 'no',
			'hide_others'        => 'no',
		);
	}

	/**
	 * @param mixed $raw Instance setting value.
	 * @return array<int,array<string,mixed>>
	 */
	public static function normalize( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$out = array();
		foreach ( $raw as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$base = self::blank_row();
			foreach ( $base as $key => $default ) {
				if ( array_key_exists( $key, $row ) ) {
					$base[ $key ] = is_string( $row[ $key ] ) ? trim( wp_unslash( $row[ $key ] ) ) : $row[ $key ];
				}
			}
			if ( '' === $base['label'] ) {
				continue;
			}
			$out[] = $base;
		}
		return $out;
	}

	/**
	 * Package facts used by every condition.
	 *
	 * @param array<string,mixed> $package WC package.
	 * @return array{weight:float,subtotal:float,qty:float,classes:array<int,string>}
	 */
	public static function package_facts( array $package ) {
		$weight   = 0.0;
		$subtotal = 0.0;
		$qty      = 0.0;
		$classes  = array();

		foreach ( $package['contents'] as $item ) {
			if ( empty( $item['data'] ) || ! is_object( $item['data'] ) ) {
				continue;
			}
			/** @var \WC_Product $product */
			$product   = $item['data'];
			$line_qty  = isset( $item['quantity'] ) ? (float) $item['quantity'] : 0.0;
			$qty      += $line_qty;
			$weight   += (float) $product->get_weight() * $line_qty;
			$subtotal += isset( $item['line_total'] ) ? (float) $item['line_total'] : 0.0;
			$class_id  = $product->get_shipping_class_id();
			if ( $class_id ) {
				$term = get_term( $class_id, 'product_shipping_class' );
				if ( $term && ! is_wp_error( $term ) ) {
					$classes[] = $term->slug;
				}
			} else {
				$classes[] = '';
			}
		}

		return array(
			'weight'   => $weight,
			'subtotal' => $subtotal,
			'qty'      => $qty,
			'classes'  => $classes,
		);
	}

	/**
	 * @param array<string,mixed> $row Rule.
	 * @param array{weight:float,subtotal:float,qty:float,classes:array<int,string>} $facts Package facts.
	 * @param bool                $pro_ok Whether Pro conditions are allowed.
	 * @return array{ok:bool,reason:string}
	 */
	public static function matches( array $row, array $facts, $pro_ok = false ) {
		if ( 'yes' !== $row['enabled'] ) {
			return array(
				'ok'     => false,
				'reason' => 'disabled',
			);
		}

		$checks = array(
			'min_weight'   => array( $facts['weight'], '>=' ),
			'max_weight'   => array( $facts['weight'], '<=' ),
			'min_subtotal' => array( $facts['subtotal'], '>=' ),
			'max_subtotal' => array( $facts['subtotal'], '<=' ),
			'min_qty'      => array( $facts['qty'], '>=' ),
			'max_qty'      => array( $facts['qty'], '<=' ),
		);

		foreach ( $checks as $key => $pair ) {
			$bound = $row[ $key ];
			if ( '' === $bound || null === $bound ) {
				continue;
			}
			$bound = (float) $bound;
			$value = $pair[0];
			$op    = $pair[1];
			if ( '>=' === $op && $value < $bound ) {
				return array(
					'ok'     => false,
					'reason' => sprintf( '%s %s (need ≥ %s)', $key, self::fmt( $value ), self::fmt( $bound ) ),
				);
			}
			if ( '<=' === $op && $value > $bound ) {
				return array(
					'ok'     => false,
					'reason' => sprintf( '%s %s (need ≤ %s)', $key, self::fmt( $value ), self::fmt( $bound ) ),
				);
			}
		}

		$class = isset( $row['shipping_class'] ) ? (string) $row['shipping_class'] : '';
		if ( '' !== $class ) {
			if ( ! $pro_ok ) {
				return array(
					'ok'     => false,
					'reason' => 'shipping class needs Pro',
				);
			}
			if ( ! in_array( $class, $facts['classes'], true ) ) {
				return array(
					'ok'     => false,
					'reason' => sprintf( 'shipping class “%s” not in cart', $class ),
				);
			}
		}

		return array(
			'ok'     => true,
			'reason' => 'matched',
		);
	}

	/**
	 * @param array<string,mixed> $row Rule.
	 * @param array{weight:float,subtotal:float,qty:float,classes:array<int,string>} $facts Package facts.
	 * @return float
	 */
	public static function cost( array $row, array $facts ) {
		$cost = (float) $row['cost'];
		if ( '' !== $row['cost_per_item'] ) {
			$cost += (float) $row['cost_per_item'] * $facts['qty'];
		}
		if ( '' !== $row['cost_per_weight'] ) {
			$cost += (float) $row['cost_per_weight'] * $facts['weight'];
		}
		return max( 0, $cost );
	}

	/**
	 * @param float $n Number.
	 */
	private static function fmt( $n ) {
		return rtrim( rtrim( number_format( (float) $n, 4, '.', '' ), '0' ), '.' );
	}
}
