<?php
/**
 * WooCommerce shipping method: instance per shipping zone, table of rules.
 *
 * @package RebelStudios\ShippingRates
 */

namespace RebelStudios\ShippingRates;

use RebelStudios\ShippingRates\Engine\Rules;

defined( 'ABSPATH' ) || exit;

class Shipping_Method extends \WC_Shipping_Method {

	/**
	 * Last evaluation trace for the cart simulator / debug.
	 *
	 * @var array<int,array<string,mixed>>
	 */
	public static $last_trace = array();

	/**
	 * @param int $instance_id Zone instance id.
	 */
	public function __construct( $instance_id = 0 ) {
		$this->id                 = 'rs_shipping_rates';
		$this->instance_id        = absint( $instance_id );
		$this->method_title       = __( 'Rebel Shipping Rates', 'rebel-studios-shipping-rates' );
		$this->method_description = __( 'Charge shipping from a table of rules you own — weight, cart total, quantity. No Jetpack, no carrier login.', 'rebel-studios-shipping-rates' );
		$this->supports           = array(
			'shipping-zones',
			'instance-settings',
			'instance-settings-modal',
		);

		$this->init();
	}

	public function init() {
		$this->instance_form_fields = $this->instance_fields();
		$this->title                = $this->get_option( 'title', __( 'Shipping', 'rebel-studios-shipping-rates' ) );
		$this->enabled              = $this->get_option( 'enabled', 'yes' );

		add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
	}

	/**
	 * @return array<string,array<string,mixed>>
	 */
	private function instance_fields() {
		return array(
			'title'    => array(
				'title'       => __( 'Method title', 'rebel-studios-shipping-rates' ),
				'type'        => 'text',
				'description' => __( 'Fallback label when a rule leaves its own label blank.', 'rebel-studios-shipping-rates' ),
				'default'     => __( 'Shipping', 'rebel-studios-shipping-rates' ),
				'desc_tip'    => true,
			),
			'tax_status' => array(
				'title'   => __( 'Tax status', 'rebel-studios-shipping-rates' ),
				'type'    => 'select',
				'default' => 'taxable',
				'options' => array(
					'taxable' => __( 'Taxable', 'rebel-studios-shipping-rates' ),
					'none'    => __( 'None', 'rebel-studios-shipping-rates' ),
				),
			),
			'rules'    => array(
				'title' => __( 'Rate table', 'rebel-studios-shipping-rates' ),
				'type'  => 'rsshp_rules',
			),
		);
	}

	/**
	 * Custom admin field: editable rate rows.
	 *
	 * @param string               $key Field key.
	 * @param array<string,mixed>  $data Field config.
	 */
	public function generate_rsshp_rules_html( $key, $data ) {
		$field_key = $this->get_field_key( $key );
		$rules     = Rules::normalize( $this->get_option( $key, array() ) );
		if ( empty( $rules ) ) {
			$rules = array( Rules::blank_row() );
		}
		$pro = (bool) apply_filters( 'rsshp_is_pro', false );

		ob_start();
		?>
		<tr valign="top">
			<th scope="row" class="titledesc">
				<label><?php echo esc_html( $data['title'] ); ?></label>
			</th>
			<td class="forminp">
				<p class="description" style="margin-bottom:8px;">
					<?php esc_html_e( 'First matching enabled row wins. Leave a min/max blank to skip that condition. Cost can be a flat fee plus optional per-item and per-weight amounts.', 'rebel-studios-shipping-rates' ); ?>
				</p>
				<table class="widefat rsshp-rules" id="<?php echo esc_attr( $field_key ); ?>_table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'On', 'rebel-studios-shipping-rates' ); ?></th>
							<th><?php esc_html_e( 'Label at checkout', 'rebel-studios-shipping-rates' ); ?></th>
							<th><?php esc_html_e( 'Cost', 'rebel-studios-shipping-rates' ); ?></th>
							<th><?php esc_html_e( '/ item', 'rebel-studios-shipping-rates' ); ?></th>
							<th><?php esc_html_e( '/ weight', 'rebel-studios-shipping-rates' ); ?></th>
							<th><?php esc_html_e( 'Weight', 'rebel-studios-shipping-rates' ); ?></th>
							<th><?php esc_html_e( 'Cart total', 'rebel-studios-shipping-rates' ); ?></th>
							<th><?php esc_html_e( 'Qty', 'rebel-studios-shipping-rates' ); ?></th>
							<?php if ( $pro ) : ?>
								<th><?php esc_html_e( 'Class', 'rebel-studios-shipping-rates' ); ?></th>
								<th><?php esc_html_e( 'Stop', 'rebel-studios-shipping-rates' ); ?></th>
								<th><?php esc_html_e( 'Only this', 'rebel-studios-shipping-rates' ); ?></th>
							<?php endif; ?>
							<th></th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $rules as $i => $row ) : ?>
						<?php $this->render_rule_row( $field_key, $i, $row, $pro ); ?>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p>
					<button type="button" class="button rsshp-add-row" data-table="<?php echo esc_attr( $field_key ); ?>_table" data-key="<?php echo esc_attr( $field_key ); ?>" data-pro="<?php echo $pro ? '1' : '0'; ?>">
						<?php esc_html_e( 'Add rate', 'rebel-studios-shipping-rates' ); ?>
					</button>
				</p>
				<?php if ( ! $pro ) : ?>
					<p class="description">
						<?php esc_html_e( 'Pro unlocks shipping-class conditions, “stop after match”, “hide other methods”, CSV import/export, and a cart simulator that shows which rule fired.', 'rebel-studios-shipping-rates' ); ?>
					</p>
				<?php endif; ?>
				<script>
				(function(){
					function rowHtml(key, i, pro){
						var html = '<tr>'+
							'<td><input type="checkbox" name="'+key+'['+i+'][enabled]" value="yes" checked></td>'+
							'<td><input type="text" name="'+key+'['+i+'][label]" value="" placeholder="Standard" style="width:110px"></td>'+
							'<td><input type="text" name="'+key+'['+i+'][cost]" value="0" style="width:60px"></td>'+
							'<td><input type="text" name="'+key+'['+i+'][cost_per_item]" value="" style="width:55px"></td>'+
							'<td><input type="text" name="'+key+'['+i+'][cost_per_weight]" value="" style="width:55px"></td>'+
							'<td><input type="text" name="'+key+'['+i+'][min_weight]" value="" placeholder="min" style="width:45px"> – <input type="text" name="'+key+'['+i+'][max_weight]" value="" placeholder="max" style="width:45px"></td>'+
							'<td><input type="text" name="'+key+'['+i+'][min_subtotal]" value="" placeholder="min" style="width:45px"> – <input type="text" name="'+key+'['+i+'][max_subtotal]" value="" placeholder="max" style="width:45px"></td>'+
							'<td><input type="text" name="'+key+'['+i+'][min_qty]" value="" placeholder="min" style="width:40px"> – <input type="text" name="'+key+'['+i+'][max_qty]" value="" placeholder="max" style="width:40px"></td>';
						if (pro === '1') {
							html += '<td><input type="text" name="'+key+'['+i+'][shipping_class]" value="" placeholder="slug" style="width:70px"></td>'+
								'<td><input type="checkbox" name="'+key+'['+i+'][abort]" value="yes"></td>'+
								'<td><input type="checkbox" name="'+key+'['+i+'][hide_others]" value="yes"></td>';
						}
						html += '<td><button type="button" class="button-link-delete rsshp-remove">&times;</button></td></tr>';
						return html;
					}
					document.addEventListener('click', function(e){
						if (e.target.classList.contains('rsshp-add-row')) {
							var table = document.getElementById(e.target.getAttribute('data-table'));
							var key = e.target.getAttribute('data-key');
							var pro = e.target.getAttribute('data-pro');
							var i = table.tBodies[0].rows.length;
							table.tBodies[0].insertAdjacentHTML('beforeend', rowHtml(key, i, pro));
						}
						if (e.target.classList.contains('rsshp-remove')) {
							var tr = e.target.closest('tr');
							if (tr && tr.parentNode.rows.length > 1) tr.remove();
						}
					});
				})();
				</script>
			</td>
		</tr>
		<?php
		return ob_get_clean();
	}

	/**
	 * @param string               $field_key Settings key prefix.
	 * @param int                  $i Row index.
	 * @param array<string,mixed>  $row Rule.
	 * @param bool                 $pro Pro unlocked.
	 */
	private function render_rule_row( $field_key, $i, array $row, $pro ) {
		?>
		<tr>
			<td><input type="checkbox" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][enabled]" value="yes" <?php checked( $row['enabled'], 'yes' ); ?>></td>
			<td><input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][label]" value="<?php echo esc_attr( $row['label'] ); ?>" style="width:110px"></td>
			<td><input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][cost]" value="<?php echo esc_attr( $row['cost'] ); ?>" style="width:60px"></td>
			<td><input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][cost_per_item]" value="<?php echo esc_attr( $row['cost_per_item'] ); ?>" style="width:55px"></td>
			<td><input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][cost_per_weight]" value="<?php echo esc_attr( $row['cost_per_weight'] ); ?>" style="width:55px"></td>
			<td>
				<input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][min_weight]" value="<?php echo esc_attr( $row['min_weight'] ); ?>" placeholder="min" style="width:45px">
				–
				<input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][max_weight]" value="<?php echo esc_attr( $row['max_weight'] ); ?>" placeholder="max" style="width:45px">
			</td>
			<td>
				<input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][min_subtotal]" value="<?php echo esc_attr( $row['min_subtotal'] ); ?>" placeholder="min" style="width:45px">
				–
				<input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][max_subtotal]" value="<?php echo esc_attr( $row['max_subtotal'] ); ?>" placeholder="max" style="width:45px">
			</td>
			<td>
				<input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][min_qty]" value="<?php echo esc_attr( $row['min_qty'] ); ?>" placeholder="min" style="width:40px">
				–
				<input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][max_qty]" value="<?php echo esc_attr( $row['max_qty'] ); ?>" placeholder="max" style="width:40px">
			</td>
			<?php if ( $pro ) : ?>
				<td><input type="text" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][shipping_class]" value="<?php echo esc_attr( $row['shipping_class'] ); ?>" placeholder="slug" style="width:70px"></td>
				<td><input type="checkbox" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][abort]" value="yes" <?php checked( $row['abort'], 'yes' ); ?>></td>
				<td><input type="checkbox" name="<?php echo esc_attr( $field_key ); ?>[<?php echo (int) $i; ?>][hide_others]" value="yes" <?php checked( $row['hide_others'], 'yes' ); ?> title="<?php esc_attr_e( 'Hide other shipping methods when this rate matches', 'rebel-studios-shipping-rates' ); ?>"></td>
			<?php endif; ?>
			<td><button type="button" class="button-link-delete rsshp-remove">&times;</button></td>
		</tr>
		<?php
	}

	public function validate_rsshp_rules_field( $key ) {
		$field_key = $this->get_field_key( $key );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WC settings nonce already checked.
		$raw = isset( $_POST[ $field_key ] ) ? wp_unslash( $_POST[ $field_key ] ) : array();
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$clean = array();
		foreach ( $raw as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$base              = Rules::blank_row();
			$base['enabled']   = ! empty( $row['enabled'] ) ? 'yes' : 'no';
			$base['label']     = isset( $row['label'] ) ? sanitize_text_field( $row['label'] ) : '';
			$base['cost']      = isset( $row['cost'] ) ? wc_format_decimal( $row['cost'] ) : '0';
			$base['cost_per_item']   = isset( $row['cost_per_item'] ) ? $this->optional_decimal( $row['cost_per_item'] ) : '';
			$base['cost_per_weight'] = isset( $row['cost_per_weight'] ) ? $this->optional_decimal( $row['cost_per_weight'] ) : '';
			foreach ( array( 'min_weight', 'max_weight', 'min_subtotal', 'max_subtotal', 'min_qty', 'max_qty' ) as $bound ) {
				$base[ $bound ] = isset( $row[ $bound ] ) ? $this->optional_decimal( $row[ $bound ] ) : '';
			}
			$base['shipping_class'] = isset( $row['shipping_class'] ) ? sanitize_title( $row['shipping_class'] ) : '';
			$base['abort']          = ! empty( $row['abort'] ) ? 'yes' : 'no';
			$base['hide_others']    = ! empty( $row['hide_others'] ) ? 'yes' : 'no';
			if ( '' === $base['label'] ) {
				continue;
			}
			$clean[] = $base;
		}
		return $clean;
	}

	/**
	 * @param mixed $value Raw.
	 * @return string
	 */
	private function optional_decimal( $value ) {
		$value = is_string( $value ) ? trim( $value ) : $value;
		if ( '' === $value || null === $value ) {
			return '';
		}
		return wc_format_decimal( $value );
	}

	/**
	 * @param array<string,mixed> $package Package.
	 */
	public function calculate_shipping( $package = array() ) {
		$rules  = Rules::normalize( $this->get_option( 'rules', array() ) );
		$facts  = Rules::package_facts( $package );
		$pro_ok = (bool) apply_filters( 'rsshp_is_pro', false );
		$trace  = array();
		$hide   = false;

		foreach ( $rules as $index => $row ) {
			$match = Rules::matches( $row, $facts, $pro_ok );
			$trace[] = array(
				'index'  => $index,
				'label'  => $row['label'],
				'ok'     => $match['ok'],
				'reason' => $match['reason'],
			);
			if ( ! $match['ok'] ) {
				continue;
			}

			$cost = Rules::cost( $row, $facts );
			$this->add_rate(
				array(
					'id'        => $this->get_rate_id( (string) $index ),
					'label'     => $row['label'],
					'cost'      => $cost,
					'package'   => $package,
					'meta_data' => array(
						'rsshp_rule'   => $index,
						'rsshp_reason' => $match['reason'],
					),
				)
			);

			if ( $pro_ok && 'yes' === $row['hide_others'] ) {
				$hide = true;
			}
			// Free always stops on the first match (matches the admin copy).
			// Pro may emit further matching rows unless this row has Stop checked.
			if ( ! $pro_ok || 'yes' === $row['abort'] ) {
				break;
			}
		}

		self::$last_trace = $trace;

		if ( $hide ) {
			add_filter( 'woocommerce_package_rates', array( $this, 'hide_other_rates' ), 100, 2 );
		}
	}

	/**
	 * When a rule asks for exclusivity, keep only our rates on the package.
	 *
	 * @param array<string,\WC_Shipping_Rate> $rates Rates.
	 * @param array<string,mixed>             $package Package.
	 * @return array<string,\WC_Shipping_Rate>
	 */
	public function hide_other_rates( $rates, $package ) {
		$keep = array();
		foreach ( $rates as $id => $rate ) {
			if ( 0 === strpos( (string) $id, $this->id . ':' ) ) {
				$keep[ $id ] = $rate;
			}
		}
		return $keep ? $keep : $rates;
	}
}
