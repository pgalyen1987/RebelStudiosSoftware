=== Rebel Studios Shipping Rates for WooCommerce ===
Contributors: rebelstudios
Tags: woocommerce shipping, table rate shipping, shipping rates, weight based shipping, flat rate
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Table-rate shipping you control — by zone, weight, cart total and quantity. No Jetpack, no carrier account, no monthly cut.

== Description ==

WooCommerce Shipping and Jetpack-backed live rates keep changing the deal: carrier accounts, credit cards, rates that jump overnight. This plugin does the opposite.

You write a **table of rates** on each shipping zone. A row matches on weight, cart total and quantity. The first match wins. The customer sees the label you wrote. Nothing phones home.

= What it does =

* **Table rates per shipping zone** — flat cost, optional per-item and per-weight add-ons.
* **Conditions** — min/max weight, cart subtotal, quantity. Leave a bound blank to skip it.
* **Your labels** — "Ground", "2-day", "Free over $75" — whatever you charge.
* **HPOS and block checkout** — declared compatible with current WooCommerce.
* **No Jetpack, no carrier login, no monthly fee** — rates live in your WordPress options.

= Pro =

[Rebel Studios Shipping Rates Pro](https://rebelstudiossoftware.com/wc-shipping-rates-pro) adds shipping-class conditions, stop-after-match, hide other methods when a rate matches, CSV import/export (no $49 add-on), and a cart simulator that shows **which rule fired and why**.

= Privacy =

Rate tables are stored on your site. The plugin makes no external requests.

== Installation ==

1. Upload the plugin and activate it (WooCommerce must be active).
2. WooCommerce → Settings → Shipping → open a zone → Add shipping method → **Rebel Shipping Rates**.
3. Edit the method, fill the rate table, save.
4. Place a test order (or use Pro’s simulator) and confirm the label and cost.

== Frequently Asked Questions ==

= Does this replace WooCommerce Shipping / live USPS rates? =
It replaces the *checkout* rate decision with rates you set. It does not buy postage labels from a carrier. If you need a printable label, use your carrier’s site or a label tool after the order is paid.

= How does it compare to Flexible Shipping? =
Same job: merchant-owned table rates. This one keeps the free tier useful (weight + total + qty) and puts CSV import/export and a “why did this rate match” simulator in Pro instead of a separate paid add-on.

= Will it work with block checkout? =
Yes. It is a normal WooCommerce shipping method; block checkout reads the same rates.

== Screenshots ==

1. Rate table on a shipping zone instance.
2. Checkout showing a matched label and cost.

== Changelog ==

= 1.0.0 =
* Initial release: zone table rates, weight/subtotal/qty conditions, HPOS + block checkout declarations.

== Upgrade Notice ==

= 1.0.0 =
First release.
