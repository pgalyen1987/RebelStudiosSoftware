<?php
/**
 * Remove instance settings left by the shipping method.
 *
 * @package RebelStudios\ShippingRates
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

// Instance settings are stored as options named woocommerce_rs_shipping_rates_<id>_settings.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
$wpdb->query(
	"DELETE FROM {$wpdb->options} WHERE option_name LIKE 'woocommerce_rs_shipping_rates_%_settings'"
);

delete_option( 'rsshp_version' );
