<?php
/**
 * Plugin Name:       Rebel Studios Shipping Rates for WooCommerce
 * Plugin URI:        https://rebelstudiossoftware.com/wc-shipping-rates
 * Description:       Table-rate shipping you control — by zone, weight, cart total and quantity. No Jetpack, no carrier account, no monthly cut. HPOS and block checkout ready.
 * Version:           1.0.0
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Author:            Rebel Studios Software
 * Author URI:        https://rebelstudiossoftware.com/
 * License:           GPL-3.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       rebel-studios-shipping-rates
 * WC requires at least: 8.2
 * WC tested up to:   11.0
 *
 * @package RebelStudios\ShippingRates
 */

defined( 'ABSPATH' ) || exit;

define( 'RSSHP_VERSION', '1.0.0' );
define( 'RSSHP_FILE', __FILE__ );
define( 'RSSHP_PATH', plugin_dir_path( __FILE__ ) );
define( 'RSSHP_URL', plugin_dir_url( __FILE__ ) );
define( 'RSSHP_BASENAME', plugin_basename( __FILE__ ) );

spl_autoload_register(
	function ( $class ) {
		$prefix = 'RebelStudios\\ShippingRates\\';
		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}
		$path = RSSHP_PATH . 'includes/' . str_replace( '\\', '/', substr( $class, strlen( $prefix ) ) ) . '.php';
		if ( is_readable( $path ) ) {
			require $path;
		}
	}
);

add_action(
	'before_woocommerce_init',
	function () {
		if ( ! class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			return;
		}
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', RSSHP_FILE, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', RSSHP_FILE, true );
	}
);

add_action(
	'plugins_loaded',
	function () {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					if ( ! current_user_can( 'activate_plugins' ) ) {
						return;
					}
					echo '<div class="notice notice-error"><p>';
					esc_html_e( 'Shipping Rates for WooCommerce needs WooCommerce active.', 'rebel-studios-shipping-rates' );
					echo '</p></div>';
				}
			);
			return;
		}

		\RebelStudios\ShippingRates\Plugin::instance()->boot();
	}
);
