<?php
namespace RebelStudios\Restaurant;

use RebelStudios\Restaurant\Engine\Admin;

defined( 'ABSPATH' ) || exit;

class Plugin {
	private static $instance;
	public static function instance() { return self::$instance ?: ( self::$instance = new self() ); }
	public function boot() {
		Menu_CPT::init();
		Reservation::instance()->hooks();
		Shortcodes::hooks();
		( new Settings_Page() )->hooks();
		Admin::enqueue();
	}
}
