<?php
/**
 * Menu items (a post type) grouped into menu sections (a taxonomy). Each item
 * has a price, description and photo. Rendered by the [rsres_menu] shortcode.
 *
 * @package RebelStudios\Restaurant
 */

namespace RebelStudios\Restaurant;

defined( 'ABSPATH' ) || exit;

class Menu_CPT {

	const TYPE = 'rsres_menu_item';
	const TAX  = 'rsres_menu_section';
	const M_PRICE    = '_rsres_price';
	const M_FEATURED = '_rsres_featured';
	const M_DIET     = '_rsres_diet';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'metabox' ) );
		add_action( 'save_post_' . self::TYPE, array( __CLASS__, 'save' ), 10, 2 );
	}

	public static function register() {
		register_taxonomy(
			self::TAX,
			self::TYPE,
			array(
				'labels'       => array(
					'name'          => __( 'Menu Sections', 'rebel-studios-restaurant-menu-reservations' ),
					'singular_name' => __( 'Section', 'rebel-studios-restaurant-menu-reservations' ),
				),
				'public'       => true,
				'hierarchical' => true,
				'show_admin_column' => true,
				'show_in_rest' => true,
				'rewrite'      => array( 'slug' => 'menu-section' ),
			)
		);
		register_post_type(
			self::TYPE,
			array(
				'labels'      => array(
					'name'          => __( 'Menu Items', 'rebel-studios-restaurant-menu-reservations' ),
					'singular_name' => __( 'Menu Item', 'rebel-studios-restaurant-menu-reservations' ),
					'add_new_item'  => __( 'Add Menu Item', 'rebel-studios-restaurant-menu-reservations' ),
					'menu_name'     => __( 'Restaurant', 'rebel-studios-restaurant-menu-reservations' ),
				),
				'public'      => true,
				'menu_icon'   => 'dashicons-food',
				'supports'    => array( 'title', 'editor', 'thumbnail' ),
				'taxonomies'  => array( self::TAX ),
				'has_archive' => false,
				'rewrite'     => array( 'slug' => 'menu-item' ),
				'show_in_rest'=> true,
			)
		);
	}

	public static function metabox() {
		add_meta_box( 'rsres-item', __( 'Item details', 'rebel-studios-restaurant-menu-reservations' ), array( __CLASS__, 'render' ), self::TYPE, 'side' );
	}

	public static function render( $post ) {
		wp_nonce_field( 'rsres_save_item', 'rsres_item_nonce' );
		$price = get_post_meta( $post->ID, self::M_PRICE, true );
		$feat  = get_post_meta( $post->ID, self::M_FEATURED, true );
		$diet  = get_post_meta( $post->ID, self::M_DIET, true );
		?>
		<p><label><strong><?php esc_html_e( 'Price', 'rebel-studios-restaurant-menu-reservations' ); ?></strong><br>
			<input type="number" step="0.01" min="0" name="rsres_price" value="<?php echo esc_attr( $price ); ?>" style="width:100%"></label></p>
		<p><label><input type="checkbox" name="rsres_featured" value="1" <?php checked( $feat, '1' ); ?>> <?php esc_html_e( 'Featured / chef’s pick', 'rebel-studios-restaurant-menu-reservations' ); ?></label></p>
		<p><label><strong><?php esc_html_e( 'Dietary tags', 'rebel-studios-restaurant-menu-reservations' ); ?></strong><br>
			<input type="text" name="rsres_diet" value="<?php echo esc_attr( $diet ); ?>" style="width:100%" placeholder="<?php esc_attr_e( 'e.g. V, VG, GF', 'rebel-studios-restaurant-menu-reservations' ); ?>"></label></p>
		<?php
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['rsres_item_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['rsres_item_nonce'] ) ), 'rsres_save_item' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		update_post_meta( $post_id, self::M_PRICE, isset( $_POST['rsres_price'] ) ? (float) $_POST['rsres_price'] : 0 );
		update_post_meta( $post_id, self::M_FEATURED, isset( $_POST['rsres_featured'] ) ? '1' : '' );
		update_post_meta( $post_id, self::M_DIET, isset( $_POST['rsres_diet'] ) ? sanitize_text_field( wp_unslash( $_POST['rsres_diet'] ) ) : '' );
	}
}
