<?php
/**
 * Table reservations: a form (date, time, party size, contact), stored as a
 * reservation post, with an email confirmation to the guest and a notification
 * to the restaurant. Admin can confirm or cancel. Free tier; online ordering
 * and payments are Pro.
 *
 * @package RebelStudios\Restaurant
 */

namespace RebelStudios\Restaurant;

use RebelStudios\Restaurant\Engine\Admin;
use RebelStudios\Restaurant\Engine\Settings;

defined( 'ABSPATH' ) || exit;

class Reservation {

	const TYPE   = 'rsres_reservation';
	const ACTION = 'rsres_reserve';
	const STATUS = 'rsres_set_status';

	const M_DATE  = '_rsres_date';
	const M_TIME  = '_rsres_time';
	const M_PARTY = '_rsres_party';
	const M_NAME  = '_rsres_name';
	const M_EMAIL = '_rsres_email';
	const M_PHONE = '_rsres_phone';
	const M_NOTES = '_rsres_notes';
	const M_STAT  = '_rsres_status'; // pending|confirmed|cancelled

	private static $instance;
	public static function instance() { return self::$instance ?: ( self::$instance = new self() ); }

	public function hooks() {
		add_action( 'init', array( __CLASS__, 'register_type' ) );
		add_action( 'admin_post_nopriv_' . self::ACTION, array( $this, 'handle' ) );
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle' ) );
		add_action( 'admin_post_' . self::STATUS, array( $this, 'set_status' ) );
		add_action( 'admin_menu', array( $this, 'menu' ) );
	}

	public static function register_type() {
		register_post_type(
			self::TYPE,
			array(
				'public'   => false,
				'show_ui'  => false,
				'supports' => array( 'title' ),
				'rewrite'  => false,
			)
		);
	}

	/* ---------- Front-end form ---------- */

	public static function form() {
		$notice = '';
		if ( isset( $_GET['rsres'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			$f = sanitize_key( wp_unslash( $_GET['rsres'] ) );
			if ( 'ok' === $f ) {
				$notice = '<div class="rsres-note rsres-ok">' . esc_html__( 'Thanks! Your reservation request was received — we’ll confirm by email.', 'rebel-studios-restaurant-menu-reservations' ) . '</div>';
			} elseif ( 'err' === $f ) {
				$notice = '<div class="rsres-note rsres-err">' . esc_html__( 'Please fill in the date, time, party size, name and a valid email.', 'rebel-studios-restaurant-menu-reservations' ) . '</div>';
			} elseif ( 'past' === $f ) {
				$notice = '<div class="rsres-note rsres-err">' . esc_html__( 'That date has already passed — please choose today or a later date.', 'rebel-studios-restaurant-menu-reservations' ) . '</div>';
			}
		}
		$max = max( 1, (int) Settings::get( 'party_max', 12 ) );
		ob_start();
		echo '<div class="rsres-reserve">';
		echo wp_kses_post( $notice );
		?>
		<h3><?php esc_html_e( 'Reserve a table', 'rebel-studios-restaurant-menu-reservations' ); ?></h3>
		<?php if ( $hours = Settings::get( 'hours_note' ) ) : // phpcs:ignore ?>
			<p class="rsres-hours"><?php echo nl2br( esc_html( $hours ) ); ?></p>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rsres-form">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
			<?php wp_nonce_field( self::ACTION ); ?>
			<div class="rsres-row">
				<label><?php esc_html_e( 'Date', 'rebel-studios-restaurant-menu-reservations' ); ?><input type="date" name="rsres_date" min="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>" required></label>
				<label><?php esc_html_e( 'Time', 'rebel-studios-restaurant-menu-reservations' ); ?><input type="time" name="rsres_time" required></label>
				<label><?php esc_html_e( 'Party', 'rebel-studios-restaurant-menu-reservations' ); ?>
					<select name="rsres_party"><?php for ( $i = 1; $i <= $max; $i++ ) { echo '<option>' . (int) $i . '</option>'; } ?></select>
				</label>
			</div>
			<label><?php esc_html_e( 'Name', 'rebel-studios-restaurant-menu-reservations' ); ?><input type="text" name="rsres_name" required></label>
			<div class="rsres-row">
				<label><?php esc_html_e( 'Email', 'rebel-studios-restaurant-menu-reservations' ); ?><input type="email" name="rsres_email" required></label>
				<label><?php esc_html_e( 'Phone', 'rebel-studios-restaurant-menu-reservations' ); ?><input type="tel" name="rsres_phone"></label>
			</div>
			<label><?php esc_html_e( 'Notes', 'rebel-studios-restaurant-menu-reservations' ); ?><textarea name="rsres_notes" rows="2" placeholder="<?php esc_attr_e( 'Allergies, high chair, occasion…', 'rebel-studios-restaurant-menu-reservations' ); ?>"></textarea></label>
			<button type="submit" class="rsres-btn"><?php esc_html_e( 'Request reservation', 'rebel-studios-restaurant-menu-reservations' ); ?></button>
		</form>
		<?php
		echo '</div>';
		return ob_get_clean();
	}

	public function handle() {
		$back  = wp_get_referer() ? wp_get_referer() : home_url();
		$nonce = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::ACTION ) ) {
			wp_safe_redirect( add_query_arg( 'rsres', 'err', $back ) );
			exit;
		}
		$date  = isset( $_POST['rsres_date'] ) ? sanitize_text_field( wp_unslash( $_POST['rsres_date'] ) ) : '';
		$time  = isset( $_POST['rsres_time'] ) ? sanitize_text_field( wp_unslash( $_POST['rsres_time'] ) ) : '';
		$party = isset( $_POST['rsres_party'] ) ? absint( $_POST['rsres_party'] ) : 0;
		$name  = isset( $_POST['rsres_name'] ) ? sanitize_text_field( wp_unslash( $_POST['rsres_name'] ) ) : '';
		$email = isset( $_POST['rsres_email'] ) ? sanitize_email( wp_unslash( $_POST['rsres_email'] ) ) : '';
		$phone = isset( $_POST['rsres_phone'] ) ? sanitize_text_field( wp_unslash( $_POST['rsres_phone'] ) ) : '';
		$notes = isset( $_POST['rsres_notes'] ) ? sanitize_textarea_field( wp_unslash( $_POST['rsres_notes'] ) ) : '';

		if ( ! $date || ! $time || $party < 1 || '' === $name || ! is_email( $email ) ) {
			wp_safe_redirect( add_query_arg( 'rsres', 'err', $back ) );
			exit;
		}
		// The date picker's min only stops the calendar; a typed or replayed request can still
		// ask for last week. "Today" is the restaurant's today, in the site's timezone.
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || $date < current_time( 'Y-m-d' ) ) {
			wp_safe_redirect( add_query_arg( 'rsres', 'past', $back ) );
			exit;
		}

		/**
		 * Take over the booking before the reservation is created.
		 *
		 * An add-on returns a URL to send the guest elsewhere -- taking a deposit
		 * through checkout, for example, and creating the reservation only once
		 * that is paid, so an abandoned checkout never holds a table. Returning
		 * anything but a non-empty string leaves the free flow below untouched.
		 *
		 * @param false|string $takeover Redirect URL, or false to continue.
		 * @param array        $booking  date, time, party, name, email, phone, notes.
		 */
		$takeover = apply_filters(
			'rsres_pre_reserve',
			false,
			compact( 'date', 'time', 'party', 'name', 'email', 'phone', 'notes' )
		);
		if ( is_string( $takeover ) && '' !== $takeover ) {
			wp_safe_redirect( $takeover );
			exit;
		}

		self::create( compact( 'date', 'time', 'party', 'name', 'email', 'phone', 'notes' ) );

		wp_safe_redirect( add_query_arg( 'rsres', 'ok', $back ) );
		exit;
	}

	/**
	 * Create a reservation and send both confirmation emails.
	 *
	 * Public so an add-on can create the booking at a different moment -- after a
	 * deposit is paid, for instance -- and still get the same record and emails.
	 *
	 * @param array  $b      date, time, party, name, email, phone, notes.
	 * @param string $status pending|confirmed|cancelled.
	 * @return int Reservation post ID, or 0 on failure.
	 */
	public static function create( array $b, $status = 'pending' ) {
		$date  = isset( $b['date'] ) ? $b['date'] : '';
		$time  = isset( $b['time'] ) ? $b['time'] : '';
		$party = isset( $b['party'] ) ? (int) $b['party'] : 0;
		$name  = isset( $b['name'] ) ? $b['name'] : '';

		$id = wp_insert_post(
			array(
				'post_type'   => self::TYPE,
				'post_status' => 'publish',
				'post_title'  => sprintf( '%s — %s %s (%d)', $name, $date, $time, $party ),
			)
		);
		if ( is_wp_error( $id ) || ! $id ) {
			return 0;
		}
		update_post_meta( $id, self::M_DATE, $date );
		update_post_meta( $id, self::M_TIME, $time );
		update_post_meta( $id, self::M_PARTY, $party );
		update_post_meta( $id, self::M_NAME, $name );
		update_post_meta( $id, self::M_EMAIL, isset( $b['email'] ) ? $b['email'] : '' );
		update_post_meta( $id, self::M_PHONE, isset( $b['phone'] ) ? $b['phone'] : '' );
		update_post_meta( $id, self::M_NOTES, isset( $b['notes'] ) ? $b['notes'] : '' );
		update_post_meta( $id, self::M_STAT, $status );
		self::notify( $id );
		return (int) $id;
	}

	private static function notify( $id ) {
		$rest  = Settings::get( 'restaurant_name' );
		$name  = get_post_meta( $id, self::M_NAME, true );
		$email = get_post_meta( $id, self::M_EMAIL, true );
		$when  = get_post_meta( $id, self::M_DATE, true ) . ' ' . get_post_meta( $id, self::M_TIME, true );
		$party = get_post_meta( $id, self::M_PARTY, true );
		$notes = get_post_meta( $id, self::M_NOTES, true );
		$phone = get_post_meta( $id, self::M_PHONE, true );
		$hdr   = array( 'Content-Type: text/plain; charset=UTF-8' );

		// Guest. A booking can arrive already confirmed (an add-on took a deposit first), and
		// "we will confirm shortly" would then tell a guest who has paid that nothing is settled.
		$confirmed = 'confirmed' === get_post_meta( $id, self::M_STAT, true );
		$confirm   = Settings::get( 'confirm_note' );
		$body      = array(
			sprintf( /* translators: %s: guest name */ __( 'Hi %s,', 'rebel-studios-restaurant-menu-reservations' ), $name ), '',
			$confirmed
				/* translators: %s: restaurant name */
				? sprintf( __( 'Your table at %s is confirmed:', 'rebel-studios-restaurant-menu-reservations' ), $rest )
				/* translators: %s: restaurant name */
				: sprintf( __( 'We received your reservation request at %s:', 'rebel-studios-restaurant-menu-reservations' ), $rest ),
			sprintf( /* translators: %s: dynamic value */ __( 'When: %s', 'rebel-studios-restaurant-menu-reservations' ), $when ),
			sprintf( /* translators: %s: dynamic value */ __( 'Party of %d', 'rebel-studios-restaurant-menu-reservations' ), $party ), '',
			$confirmed ? __( 'See you then!', 'rebel-studios-restaurant-menu-reservations' ) : __( 'We will confirm shortly.', 'rebel-studios-restaurant-menu-reservations' ),
		);
		if ( $confirm ) { $body[] = ''; $body[] = $confirm; }
		$subject = $confirmed
			/* translators: %s: restaurant name */
			? sprintf( __( 'Reservation confirmed — %s', 'rebel-studios-restaurant-menu-reservations' ), $rest )
			/* translators: %s: restaurant name */
			: sprintf( __( 'Your reservation at %s', 'rebel-studios-restaurant-menu-reservations' ), $rest );
		wp_mail( $email, $subject, implode( "\n", $body ), self::guest_headers() );

		// Restaurant.
		$to  = Settings::get( 'reservation_email' );
		$rbody = array(
			__( 'New reservation request:', 'rebel-studios-restaurant-menu-reservations' ), '',
			sprintf( /* translators: %s: dynamic value */ __( 'Name: %s', 'rebel-studios-restaurant-menu-reservations' ), $name ),
			sprintf( /* translators: %s: dynamic value */ __( 'When: %s', 'rebel-studios-restaurant-menu-reservations' ), $when ),
			sprintf( /* translators: %s: dynamic value */ __( 'Party: %d', 'rebel-studios-restaurant-menu-reservations' ), $party ),
			sprintf( /* translators: %s: dynamic value */ __( 'Email: %s', 'rebel-studios-restaurant-menu-reservations' ), $email ),
			sprintf( /* translators: %s: dynamic value */ __( 'Phone: %s', 'rebel-studios-restaurant-menu-reservations' ), $phone ),
			sprintf( /* translators: %s: dynamic value */ __( 'Notes: %s', 'rebel-studios-restaurant-menu-reservations' ), $notes ),
		);
		if ( is_email( $to ) ) {
			wp_mail( $to, sprintf( /* translators: %s: dynamic value */ __( 'New reservation — %1$s, %2$s', 'rebel-studios-restaurant-menu-reservations' ), $name, $when ), implode( "\n", $rbody ), $hdr );
		}
	}

	/* ---------- Admin ---------- */

	/**
	 * Who may see bookings and confirm or cancel them. Guests' names, emails, phone numbers and
	 * notes are personal data, and each change emails the guest, so this is edit_others_posts
	 * (Editors and Administrators), not edit_posts, which every Contributor has. A site whose
	 * floor staff hold another role can change it with the rsres_staff_capability filter.
	 */
	public static function staff_cap() {
		return (string) apply_filters( 'rsres_staff_capability', 'edit_others_posts' );
	}

	public function menu() {
		add_submenu_page(
			'edit.php?post_type=' . Menu_CPT::TYPE,
			__( 'Reservations', 'rebel-studios-restaurant-menu-reservations' ),
			__( 'Reservations', 'rebel-studios-restaurant-menu-reservations' ),
			self::staff_cap(),
			'rsres-reservations',
			array( $this, 'render_list' )
		);
	}

	public static function all( $status = '' ) {
		$args = array( 'post_type' => self::TYPE, 'post_status' => 'publish', 'numberposts' => 200, 'orderby' => 'date', 'order' => 'DESC' );
		if ( $status ) {
			$args['meta_key']   = self::M_STAT;
			$args['meta_value'] = $status;
		}
		return get_posts( $args );
	}

	public function render_list() {
		$filter = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- read-only view filter.
		$labels = array(
			'pending'   => __( 'Pending', 'rebel-studios-restaurant-menu-reservations' ),
			'confirmed' => __( 'Confirmed', 'rebel-studios-restaurant-menu-reservations' ),
			'cancelled' => __( 'Cancelled', 'rebel-studios-restaurant-menu-reservations' ),
		);
		if ( ! isset( $labels[ $filter ] ) ) {
			$filter = '';
		}
		$all = self::all();
		// Upcoming tables first, soonest at the top; past ones after, most recent first.
		$at    = function ( $r ) { return strtotime( get_post_meta( $r->ID, self::M_DATE, true ) . ' ' . get_post_meta( $r->ID, self::M_TIME, true ) ); };
		$today = strtotime( current_time( 'Y-m-d' ) );
		usort( $all, function ( $a, $b ) use ( $at, $today ) {
			$x = $at( $a );
			$y = $at( $b );
			if ( ( $x >= $today ) !== ( $y >= $today ) ) {
				return $x >= $today ? -1 : 1;
			}
			return $x >= $today ? $x <=> $y : $y <=> $x;
		} );
		$counts = array_fill_keys( array_keys( $labels ), 0 );
		foreach ( $all as $r ) {
			$st = get_post_meta( $r->ID, self::M_STAT, true );
			++$counts[ isset( $labels[ $st ] ) ? $st : 'pending' ];
		}
		$rows = $filter ? array_values( array_filter( $all, function ( $r ) use ( $filter ) {
			$st = get_post_meta( $r->ID, self::M_STAT, true );
			return ( $st ? $st : 'pending' ) === $filter;
		} ) ) : $all;

		echo '<div class="wrap rsres-admin">';
		Admin::header( __( 'Reservations', 'rebel-studios-restaurant-menu-reservations' ) );

		// WordPress's own view-filter row: All | Pending | Confirmed | Cancelled, with counts.
		$base  = add_query_arg( array( 'post_type' => Menu_CPT::TYPE, 'page' => 'rsres-reservations' ), admin_url( 'edit.php' ) );
		$views = array( '' => __( 'All', 'rebel-studios-restaurant-menu-reservations' ) ) + $labels;
		echo '<ul class="subsubsub">';
		$i = 0;
		foreach ( $views as $key => $label ) {
			$n = '' === $key ? count( $all ) : $counts[ $key ];
			printf(
				'<li><a href="%s"%s>%s <span class="count">(%d)</span></a>%s</li>',
				esc_url( $key ? add_query_arg( 'status', $key, $base ) : $base ),
				$filter === $key ? ' class="current" aria-current="page"' : '',
				esc_html( $label ),
				(int) $n,
				++$i < count( $views ) ? ' |' : ''
			);
		}
		echo '</ul>';

		echo '<table class="widefat striped rsres-list"><thead><tr>';
		foreach ( array( __( 'When', 'rebel-studios-restaurant-menu-reservations' ), __( 'Party', 'rebel-studios-restaurant-menu-reservations' ), __( 'Guest', 'rebel-studios-restaurant-menu-reservations' ), __( 'Contact', 'rebel-studios-restaurant-menu-reservations' ), __( 'Notes', 'rebel-studios-restaurant-menu-reservations' ), __( 'Status', 'rebel-studios-restaurant-menu-reservations' ), '' ) as $h ) {
			echo '<th>' . esc_html( $h ) . '</th>';
		}
		echo '</tr></thead><tbody>';
		if ( ! $rows ) {
			echo '<tr><td colspan="7" class="rsres-empty">' . esc_html( $filter ? __( 'Nothing here.', 'rebel-studios-restaurant-menu-reservations' ) : __( 'No reservations yet. Bookings from your [rsres_reservation] page land here.', 'rebel-studios-restaurant-menu-reservations' ) ) . '</td></tr>';
		}
		foreach ( $rows as $r ) {
			$id   = $r->ID;
			$stat = get_post_meta( $id, self::M_STAT, true );
			$stat = isset( $labels[ $stat ] ) ? $stat : 'pending';
			$btn  = function ( $to, $label, $primary = false ) use ( $id ) {
				return sprintf(
					'<a class="button button-small%s" href="%s">%s</a> ',
					$primary ? ' button-primary' : '',
					esc_url( wp_nonce_url( add_query_arg( array( 'action' => self::STATUS, 'id' => $id, 'to' => $to ), admin_url( 'admin-post.php' ) ), self::STATUS . '_' . $id ) ),
					esc_html( $label )
				);
			};
			// Only the changes that make sense from where the booking is now.
			$actions = array(
				'pending'   => $btn( 'confirmed', __( 'Confirm', 'rebel-studios-restaurant-menu-reservations' ), true ) . $btn( 'cancelled', __( 'Cancel', 'rebel-studios-restaurant-menu-reservations' ) ),
				'confirmed' => $btn( 'cancelled', __( 'Cancel', 'rebel-studios-restaurant-menu-reservations' ) ),
				'cancelled' => $btn( 'confirmed', __( 'Reinstate', 'rebel-studios-restaurant-menu-reservations' ) ),
			);
			$date  = get_post_meta( $id, self::M_DATE, true );
			$time  = get_post_meta( $id, self::M_TIME, true );
			$party = (int) get_post_meta( $id, self::M_PARTY, true );
			$email = (string) get_post_meta( $id, self::M_EMAIL, true );
			$phone = (string) get_post_meta( $id, self::M_PHONE, true );
			printf(
				'<tr><td><strong>%1$s</strong><br><span class="rsres-muted">%2$s</span></td><td>%3$s</td><td>%4$s</td><td>%5$s%6$s</td><td>%7$s</td><td><span class="rsres-badge rsres-%8$s">%9$s</span></td><td class="rsres-actions">%10$s</td></tr>',
				esc_html( $date ? date_i18n( 'D, M j', strtotime( $date ) ) : '—' ),
				esc_html( $time ? date_i18n( get_option( 'time_format' ), strtotime( $time ) ) : '' ),
				esc_html( sprintf( /* translators: %d: number of guests */ _n( '%d guest', '%d guests', $party, 'rebel-studios-restaurant-menu-reservations' ), $party ) ),
				esc_html( get_post_meta( $id, self::M_NAME, true ) ),
				$email ? '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' : '',
				$phone ? '<br><a href="tel:' . esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ) . '">' . esc_html( $phone ) . '</a>' : '',
				esc_html( get_post_meta( $id, self::M_NOTES, true ) ),
				esc_attr( $stat ),
				esc_html( $labels[ $stat ] ),
				wp_kses_post( $actions[ $stat ] )
			);
		}
		echo '</tbody></table>';
		echo '</div>';
	}

	public function set_status() {
		$id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		$to = isset( $_GET['to'] ) ? sanitize_key( wp_unslash( $_GET['to'] ) ) : '';
		if ( ! current_user_can( self::staff_cap() ) ) {
			wp_die( esc_html__( 'Not allowed.', 'rebel-studios-restaurant-menu-reservations' ), 403 );
		}
		check_admin_referer( self::STATUS . '_' . $id );
		if ( $id && in_array( $to, array( 'pending', 'confirmed', 'cancelled' ), true ) ) {
			$from = get_post_meta( $id, self::M_STAT, true );
			update_post_meta( $id, self::M_STAT, $to );
			// Only on an actual change, so a double click does not email the guest twice.
			if ( $from !== $to && 'confirmed' === $to ) {
				$this->email_confirmed( $id );
			} elseif ( $from !== $to && 'cancelled' === $to ) {
				$this->email_cancelled( $id );
			}
		}
		wp_safe_redirect( add_query_arg( array( 'post_type' => Menu_CPT::TYPE, 'page' => 'rsres-reservations' ), admin_url( 'edit.php' ) ) );
		exit;
	}

	private function email_confirmed( $id ) {
		$email = get_post_meta( $id, self::M_EMAIL, true );
		if ( ! is_email( $email ) ) {
			return;
		}
		$rest = Settings::get( 'restaurant_name' );
		$when = get_post_meta( $id, self::M_DATE, true ) . ' ' . get_post_meta( $id, self::M_TIME, true );
		$body = sprintf( /* translators: %s: dynamic value */ __( "Your table at %1\$s is confirmed for %2\$s. See you then!", 'rebel-studios-restaurant-menu-reservations' ), $rest, $when );
		wp_mail( $email, sprintf( /* translators: %s: dynamic value */ __( 'Reservation confirmed — %s', 'rebel-studios-restaurant-menu-reservations' ), $rest ), $body, self::guest_headers() );
	}

	/** A guest whose booking is cancelled has to hear about it, or they turn up for a table that is gone. */
	private function email_cancelled( $id ) {
		$email = get_post_meta( $id, self::M_EMAIL, true );
		if ( ! is_email( $email ) ) {
			return;
		}
		$rest = Settings::get( 'restaurant_name' );
		$when = get_post_meta( $id, self::M_DATE, true ) . ' ' . get_post_meta( $id, self::M_TIME, true );
		/* translators: 1: restaurant name, 2: date and time */
		$body = sprintf( __( "Your reservation at %1\$s for %2\$s has been cancelled.\n\nIf this is unexpected, reply to this email and we will sort it out.", 'rebel-studios-restaurant-menu-reservations' ), $rest, $when );
		/* translators: %s: restaurant name */
		wp_mail( $email, sprintf( __( 'Reservation cancelled — %s', 'rebel-studios-restaurant-menu-reservations' ), $rest ), $body, self::guest_headers() );
	}

	/** Guest emails: replies go to the restaurant's reservation address, not the site's no-reply sender. */
	private static function guest_headers() {
		$hdr   = array( 'Content-Type: text/plain; charset=UTF-8' );
		$reply = Settings::get( 'reservation_email' );
		if ( is_email( $reply ) ) {
			$hdr[] = 'Reply-To: ' . $reply;
		}
		return $hdr;
	}
}
