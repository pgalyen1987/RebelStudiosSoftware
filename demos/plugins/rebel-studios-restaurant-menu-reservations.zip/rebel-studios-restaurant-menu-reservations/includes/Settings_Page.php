<?php
namespace RebelStudios\Restaurant;

use RebelStudios\Restaurant\Engine\Admin;
use RebelStudios\Restaurant\Engine\Freemium;
use RebelStudios\Restaurant\Engine\Settings;

defined( 'ABSPATH' ) || exit;

class Settings_Page {

	const SAVE = 'rsres_save_settings';

	public function hooks() {
		add_action(
			'admin_menu',
			function () {
				add_submenu_page(
					'edit.php?post_type=' . Menu_CPT::TYPE,
					__( 'Restaurant Settings', 'rebel-studios-restaurant-menu-reservations' ),
					__( 'Settings', 'rebel-studios-restaurant-menu-reservations' ),
					'manage_options',
					Admin::MENU_SLUG,
					array( $this, 'render' )
				);
			}
		);
		add_action( 'admin_post_' . self::SAVE, array( $this, 'save' ) );
	}

	public function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'rebel-studios-restaurant-menu-reservations' ), 403 );
		}
		check_admin_referer( self::SAVE );
		$in = wp_unslash( $_POST );
		Settings::update(
			array(
				'restaurant_name'   => $in['restaurant_name'] ?? '',
				'reservation_email' => $in['reservation_email'] ?? '',
				'currency_symbol'   => $in['currency_symbol'] ?? '',
				'accent_color'      => $in['accent_color'] ?? '#c2410c',
				'logo_id'           => $in['logo_id'] ?? 0,
				'menu_page_id'      => $in['menu_page_id'] ?? 0,
				'party_max'         => $in['party_max'] ?? 12,
				'hours_note'        => $in['hours_note'] ?? '',
				'confirm_note'      => $in['confirm_note'] ?? '',
			)
		);
		wp_safe_redirect( add_query_arg( array( 'post_type' => Menu_CPT::TYPE, 'page' => Admin::MENU_SLUG, 'updated' => 1 ), admin_url( 'edit.php' ) ) );
		exit;
	}

	public function render() {
		$s = Settings::all();
		?>
		<div class="wrap">
			<?php Admin::header( __( 'Restaurant Settings', 'rebel-studios-restaurant-menu-reservations' ) ); ?>
			<?php if ( isset( $_GET['updated'] ) ) { echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'rebel-studios-restaurant-menu-reservations' ) . '</p></div>'; } ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
				<?php wp_nonce_field( self::SAVE ); ?>
				<table class="form-table" role="presentation">
					<tr><th><label for="restaurant_name"><?php esc_html_e( 'Restaurant name', 'rebel-studios-restaurant-menu-reservations' ); ?></label></th>
						<td><input name="restaurant_name" id="restaurant_name" class="regular-text" value="<?php echo esc_attr( $s['restaurant_name'] ); ?>"></td></tr>
					<tr><th><label for="reservation_email"><?php esc_html_e( 'Reservation notifications to', 'rebel-studios-restaurant-menu-reservations' ); ?></label></th>
						<td><input name="reservation_email" id="reservation_email" type="email" class="regular-text" value="<?php echo esc_attr( $s['reservation_email'] ); ?>"></td></tr>
					<tr><th><label for="currency_symbol"><?php esc_html_e( 'Currency symbol', 'rebel-studios-restaurant-menu-reservations' ); ?></label></th>
						<td><input name="currency_symbol" id="currency_symbol" value="<?php echo esc_attr( $s['currency_symbol'] ); ?>" placeholder="<?php echo esc_attr( Shortcodes::currency() ); ?>" style="width:70px">
							<p class="description"><?php esc_html_e( 'Leave empty to use your store’s currency.', 'rebel-studios-restaurant-menu-reservations' ); ?></p></td></tr>
					<tr><th><label for="accent_color"><?php esc_html_e( 'Accent color', 'rebel-studios-restaurant-menu-reservations' ); ?></label></th>
						<td><input name="accent_color" id="accent_color" value="<?php echo esc_attr( $s['accent_color'] ); ?>" placeholder="#c2410c"></td></tr>
					<tr><th><?php esc_html_e( 'Logo', 'rebel-studios-restaurant-menu-reservations' ); ?></th>
						<td>
							<input type="hidden" name="logo_id" id="wcinv_logo_id" value="<?php echo esc_attr( $s['logo_id'] ); ?>">
							<div id="wcinv_logo_preview" style="margin-bottom:6px"><?php if ( $s['logo_id'] ) { echo wp_get_attachment_image( (int) $s['logo_id'], array( 160, 80 ) ); } ?></div>
							<button type="button" class="button" id="wcinv_logo_pick"><?php esc_html_e( 'Choose logo', 'rebel-studios-restaurant-menu-reservations' ); ?></button>
							<button type="button" class="button" id="wcinv_logo_clear"><?php esc_html_e( 'Remove', 'rebel-studios-restaurant-menu-reservations' ); ?></button>
						</td></tr>
					<tr><th><label for="menu_page_id"><?php esc_html_e( 'Menu page', 'rebel-studios-restaurant-menu-reservations' ); ?></label></th>
						<td><?php wp_dropdown_pages( array( 'name' => 'menu_page_id', 'id' => 'menu_page_id', 'selected' => (int) $s['menu_page_id'], 'show_option_none' => esc_html__( '— select —', 'rebel-studios-restaurant-menu-reservations' ) ) ); ?>
							<p class="description"><?php esc_html_e( 'The page that contains your [rsres_menu] shortcode. Used for the QR menu below.', 'rebel-studios-restaurant-menu-reservations' ); ?></p></td></tr>
					<tr><th><label for="party_max"><?php esc_html_e( 'Max party size', 'rebel-studios-restaurant-menu-reservations' ); ?></label></th>
						<td><input name="party_max" id="party_max" type="number" min="1" value="<?php echo esc_attr( $s['party_max'] ); ?>" style="width:80px"></td></tr>
					<tr><th><label for="hours_note"><?php esc_html_e( 'Hours / note on form', 'rebel-studios-restaurant-menu-reservations' ); ?></label></th>
						<td><textarea name="hours_note" id="hours_note" class="large-text" rows="2"><?php echo esc_textarea( $s['hours_note'] ); ?></textarea></td></tr>
					<tr><th><label for="confirm_note"><?php esc_html_e( 'Confirmation email note', 'rebel-studios-restaurant-menu-reservations' ); ?></label></th>
						<td><textarea name="confirm_note" id="confirm_note" class="large-text" rows="2"><?php echo esc_textarea( $s['confirm_note'] ); ?></textarea></td></tr>
				</table>
				<h2><?php esc_html_e( 'Online ordering', 'rebel-studios-restaurant-menu-reservations' ); ?> <?php echo wp_kses_post( Freemium::is_pro() ? '' : Freemium::badge( 'ordering' ) ); ?></h2>
				<p class="description"><?php esc_html_e( 'Online ordering for pickup or delivery, and reservation deposits, are available in a separate Pro add-on. The free plugin handles your menu, reservations and QR menu.', 'rebel-studios-restaurant-menu-reservations' ); ?></p>
				<?php submit_button( __( 'Save settings', 'rebel-studios-restaurant-menu-reservations' ) ); ?>
			</form>

			<hr>
			<h2><?php esc_html_e( 'QR menu', 'rebel-studios-restaurant-menu-reservations' ); ?></h2>
			<?php
			$page = (int) $s['menu_page_id'];
			if ( $page ) {
				$url = get_permalink( $page );
				$qr  = QR::data_uri( $url );
				if ( $qr ) {
					echo '<p>' . esc_html__( 'Print this and put it on your tables — it opens your menu.', 'rebel-studios-restaurant-menu-reservations' ) . '</p>';
					echo '<img src="' . esc_attr( $qr ) . '" style="width:200px;height:200px;border:1px solid #eee;border-radius:10px;padding:8px;background:#fff" alt="QR menu">';
					echo '<p><a class="button" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open menu page', 'rebel-studios-restaurant-menu-reservations' ) . '</a></p>';
				}
			} else {
				echo '<p class="description">' . esc_html__( 'Select a Menu page above and save to generate a QR code for your tables.', 'rebel-studios-restaurant-menu-reservations' ) . '</p>';
			}
			?>
			<hr>
			<h2><?php esc_html_e( 'Shortcodes', 'rebel-studios-restaurant-menu-reservations' ); ?></h2>
			<p><code>[rsres_menu]</code> — <?php esc_html_e( 'your full menu, grouped by section.', 'rebel-studios-restaurant-menu-reservations' ); ?><br>
			<code>[rsres_reservation]</code> — <?php esc_html_e( 'the table reservation form.', 'rebel-studios-restaurant-menu-reservations' ); ?></p>
		</div>
		<?php
	}
}
