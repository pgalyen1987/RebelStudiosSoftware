<?php
/**
 * Options wrapper. One serialized option row, typed defaults, sanitized writes.
 * Engine class -- shared verbatim across Rebel Studios plugins; the only
 * per-plugin coupling is the OPTION_KEY and the $defaults map.
 *
 * @package RebelStudios\Restaurant\Engine
 */

namespace RebelStudios\Restaurant\Engine;

defined( 'ABSPATH' ) || exit;

class Settings {

	const OPTION_KEY = 'rsres_settings';

	/**
	 * Field key => default value. Also the allow-list: a key absent here is
	 * never read or written, so a crafted POST cannot smuggle options in.
	 */
	public static function defaults() {
		return array(
			'restaurant_name'   => get_bloginfo( 'name' ),
			'reservation_email' => get_bloginfo( 'admin_email' ),
			// Empty follows the store's currency at display time (Shortcodes::currency()). Saving the
			// symbol here froze whatever WooCommerce had at activation -- "$" on a fresh install --
			// so a store switched to R$ afterwards still showed "$" beside its prices.
			'currency_symbol'   => '',
			'accent_color'      => '#c2410c',
			'logo_id'           => 0,
			'menu_page_id'      => 0,
			'party_max'         => 12,
			'hours_note'        => '',
			'confirm_note'      => '',
				);
	}

	public static function all() {
		$saved = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	public static function get( $key, $fallback = null ) {
		$all = self::all();
		if ( array_key_exists( $key, $all ) ) {
			return $all[ $key ];
		}
		return $fallback;
	}

	public static function update( array $values ) {
		$current = self::all();
		$clean   = array();
		foreach ( self::defaults() as $key => $default ) {
			if ( ! array_key_exists( $key, $values ) ) {
				$clean[ $key ] = $current[ $key ];
				continue;
			}
			$clean[ $key ] = self::sanitize_field( $key, $values[ $key ], $default );
		}
		update_option( self::OPTION_KEY, $clean );
		return $clean;
	}

	public static function seed_defaults() {
		if ( false === get_option( self::OPTION_KEY, false ) ) {
			add_option( self::OPTION_KEY, self::defaults() );
		}
	}

	private static function sanitize_field( $key, $value, $default ) {
		switch ( $key ) {
			case 'hours_note':
			case 'confirm_note':
				return sanitize_textarea_field( wp_unslash( $value ) );
			case 'reservation_email':
				return sanitize_email( wp_unslash( $value ) );
			case 'accent_color':
				$c = sanitize_hex_color( wp_unslash( $value ) );
				return $c ? $c : $default;
			case 'logo_id':
			case 'menu_page_id':
				return max( 0, absint( $value ) );
			case 'party_max':
				return max( 1, absint( $value ) );
			default:
				return sanitize_text_field( wp_unslash( $value ) );
				}
	}
}
