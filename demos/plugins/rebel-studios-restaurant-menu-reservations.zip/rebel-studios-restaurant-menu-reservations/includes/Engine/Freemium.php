<?php
/**
 * Free / Pro gate.
 *
 * wp.org rule: the free plugin ships NO paid code. The Pro tier is a separate
 * add-on plugin sold off-site; when active and licensed it answers the
 * `rsres_is_pro` filter true and may register its own features on the hooks the
 * free plugin exposes. So `is_pro()` is false for the free plugin alone, and
 * every gated call degrades to the free behaviour -- never to a broken screen.
 *
 * Engine class -- lifts to other plugins by changing the three constants.
 *
 * @package RebelStudios\Restaurant\Engine
 */

namespace RebelStudios\Restaurant\Engine;

defined( 'ABSPATH' ) || exit;

class Freemium {

	const IS_PRO_FILTER = 'rsres_is_pro';
	const UPGRADE_URL   = 'https://rebelstudiossoftware.com/wc-restaurant';
	const PRODUCT       = 'rebel-studios-restaurant-menu-reservations';

	/** Features the free tier includes. Anything not listed is Pro-only. */
	private static function free_features() {
		return array(
			'menu',          // display the menu
			'reservations',  // table reservations
			'qr_menu',       // QR code to the menu
				);
	}

	public static function is_pro() {
		return (bool) apply_filters( self::IS_PRO_FILTER, false );
	}

	/** True if the current tier may use $feature. */
	public static function allows( $feature ) {
		if ( self::is_pro() ) {
			return true;
		}
		return in_array( $feature, self::free_features(), true );
	}

	public static function upgrade_url( $utm_content = 'generic' ) {
		return add_query_arg(
			array(
				'utm_source'  => 'plugin',
				'utm_medium'  => 'admin',
				'utm_campaign'=> self::PRODUCT,
				'utm_content' => sanitize_key( $utm_content ),
			),
			self::UPGRADE_URL
		);
	}

	/** A small inline "Pro" pill for gated controls. */
	public static function badge( $utm_content = 'badge' ) {
		return sprintf(
			' <a class="wcinv-pro-pill" target="_blank" rel="noopener" href="%s">%s</a>',
			esc_url( self::upgrade_url( $utm_content ) ),
			esc_html__( 'Pro', 'rebel-studios-restaurant-menu-reservations' )
		);
	}
}
