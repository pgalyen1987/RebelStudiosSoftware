<?php
namespace RebelStudios\Restaurant;

use RebelStudios\Restaurant\Engine\Settings;

defined( 'ABSPATH' ) || exit;

class Shortcodes {

	public static function hooks() {
		add_shortcode( 'rsres_menu', array( __CLASS__, 'menu' ) );
		add_shortcode( 'rsres_reservation', array( __CLASS__, 'reservation' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	/**
	 * Styles load only where the plugin's markup appears, not on every page of the site. Pages we
	 * can predict get them in <head>; enqueue() is also called from each shortcode, which covers
	 * one rendered somewhere unpredictable (a widget, a page builder) at the cost of a late print.
	 */
	public static function assets() {
		if ( self::content_has( array( 'rsres_menu', 'rsres_reservation' ) ) ) {
			self::enqueue();
		}
	}

	public static function enqueue() {
		static $done = false; // the inline accent rule must not be appended twice
		if ( $done ) {
			return;
		}
		$done = true;
		wp_enqueue_style( 'rebel-studios-restaurant-menu-reservations', RSRES_URL . 'assets/public/restaurant.css', array(), RSRES_VERSION );
		$accent = Settings::get( 'accent_color', '#c2410c' );
		wp_add_inline_style( 'rebel-studios-restaurant-menu-reservations', ':root{--rsres-accent:' . ( preg_match( '/^#[0-9a-fA-F]{3,6}$/', $accent ) ? $accent : '#c2410c' ) . '}' );
	}

	/** True when the singular post being viewed contains any of these shortcodes. */
	private static function content_has( array $tags ) {
		$post = is_singular() ? get_post() : null;
		if ( ! $post ) {
			return false;
		}
		foreach ( $tags as $tag ) {
			if ( has_shortcode( $post->post_content, $tag ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * The symbol printed beside menu prices: the one set in Restaurant settings, or when that is
	 * left empty, the store's current WooCommerce currency.
	 */
	public static function currency() {
		$symbol = (string) Settings::get( 'currency_symbol', '' );
		if ( '' !== $symbol ) {
			return $symbol;
		}
		return function_exists( 'get_woocommerce_currency_symbol' ) ? html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ) : '$';
	}

	public static function reservation() {
		self::enqueue();
		return Reservation::form();
	}

	public static function menu( $atts ) {
		self::enqueue();
		$sections = get_terms( array( 'taxonomy' => Menu_CPT::TAX, 'hide_empty' => true, 'orderby' => 'term_id', 'order' => 'ASC' ) );
		$cur      = self::currency();
		ob_start();
		echo '<div class="rsres-menu">';

		if ( is_wp_error( $sections ) || ! $sections ) {
			// No sections: list all items flat.
			self::render_items( new \WP_Query( array( 'post_type' => Menu_CPT::TYPE, 'posts_per_page' => -1, 'orderby' => 'menu_order title', 'order' => 'ASC' ) ), $cur );
		} else {
			foreach ( $sections as $section ) {
				$q = new \WP_Query(
					array(
						'post_type'      => Menu_CPT::TYPE,
						'posts_per_page' => -1,
						'orderby'        => 'menu_order title',
						'order'          => 'ASC',
						'tax_query'      => array( array( 'taxonomy' => Menu_CPT::TAX, 'field' => 'term_id', 'terms' => $section->term_id ) ),
					)
				);
				if ( ! $q->have_posts() ) {
					continue;
				}
				echo '<h2 class="rsres-section">' . esc_html( $section->name ) . '</h2>';
				if ( $section->description ) {
					echo '<p class="rsres-section-desc">' . esc_html( $section->description ) . '</p>';
				}
				self::render_items( $q, $cur );
			}
		}
		echo '</div>';
		wp_reset_postdata();
		return ob_get_clean();
	}

	private static function render_items( \WP_Query $q, $cur ) {
		echo '<div class="rsres-items">';
		while ( $q->have_posts() ) {
			$q->the_post();
			$id    = get_the_ID();
			$price = get_post_meta( $id, Menu_CPT::M_PRICE, true );
			$diet  = get_post_meta( $id, Menu_CPT::M_DIET, true );
			$feat  = get_post_meta( $id, Menu_CPT::M_FEATURED, true );
			echo '<div class="rsres-item">';
			if ( has_post_thumbnail( $id ) ) {
				echo '<div class="rsres-thumb">' . get_the_post_thumbnail( $id, 'thumbnail' ) . '</div>';
			}
			echo '<div class="rsres-item-body">';
			echo '<div class="rsres-item-head"><span class="rsres-name">' . esc_html( get_the_title() );
			if ( $feat ) { echo ' <span class="rsres-star">' . esc_html__( 'Chef’s pick', 'rebel-studios-restaurant-menu-reservations' ) . '</span>'; }
			// No price (market price, ask your server) shows no price -- not "$0.00" or a bare "$".
			$shown = (float) $price > 0 ? $cur . number_format_i18n( (float) $price, 2 ) : '';
			echo '</span>';
			if ( '' !== $shown ) {
				echo '<span class="rsres-dots"></span><span class="rsres-price">' . esc_html( $shown ) . '</span>';
			}
			echo '</div>';
			$desc = wp_strip_all_tags( get_the_content() );
			if ( $desc ) { echo '<div class="rsres-desc">' . esc_html( $desc ) . '</div>'; }
			// "V, GF" is typed as one field; each label gets its own tag.
			$tags = array_filter( array_map( 'trim', preg_split( '/[,\/|]+/', (string) $diet ) ) );
			if ( $tags ) {
				echo '<div class="rsres-diet"><span>' . implode( '</span><span>', array_map( 'esc_html', $tags ) ) . '</span></div>';
			}
			echo '</div></div>';
		}
		echo '</div>';
	}
}
