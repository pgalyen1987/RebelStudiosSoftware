<?php
/**
 * Plugin Name:       Rebel Studios Restaurant Menu & Reservations
 * Plugin URI:        https://rebelstudiossoftware.com/wc-restaurant
 * Description:       A beautiful restaurant menu, table reservations with email confirmation, and a printable QR code that opens your menu. Online ordering & payments in Pro.
 * Version:           1.1.2
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Rebel Studios Software
 * Author URI:        https://rebelstudiossoftware.com/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       rebel-studios-restaurant-menu-reservations
 *
 * @package RebelStudios\Restaurant
 */

defined( 'ABSPATH' ) || exit;

define( 'RSRES_VERSION', '1.1.1' );
define( 'RSRES_FILE', __FILE__ );
define( 'RSRES_PATH', plugin_dir_path( __FILE__ ) );
define( 'RSRES_URL', plugin_dir_url( __FILE__ ) );
define( 'RSRES_BASENAME', plugin_basename( __FILE__ ) );

spl_autoload_register(
	function ( $class ) {
		$prefix = 'RebelStudios\\Restaurant\\';
		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}
		$path = RSRES_PATH . 'includes/' . str_replace( '\\', '/', substr( $class, strlen( $prefix ) ) ) . '.php';
		if ( is_readable( $path ) ) {
			require $path;
		}
	}
);

add_action(
	'plugins_loaded',
	function () {
		\RebelStudios\Restaurant\Plugin::instance()->boot();
	}
);

register_activation_hook(
	__FILE__,
	function () {
		\RebelStudios\Restaurant\Engine\Settings::seed_defaults();
		\RebelStudios\Restaurant\Menu_CPT::register();
		\RebelStudios\Restaurant\Reservation::register_type();
		flush_rewrite_rules();
	}
);
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
