#!/usr/bin/env bash
# Publish Rebel Studios Restaurant Menu & Reservations to the wp.org plugin directory.
#
#   bash wporg-publish.sh [version]        # default 1.1.1
#
# APPROVAL IS NOT PUBLICATION. An approved plugin stays invisible until the first SVN commit --
# the Brazilian plugin was approved 09-29 and only appeared on 10-12. This is that commit.
#
# SVN takes WPORG_PASSWORD and needs no web 2FA (the website login does; SVN does not). The
# password is piped in, never passed as an argument, so it cannot appear in ps or in a log.
set -euo pipefail

VER="${1:-1.1.1}"
SLUG="rebel-studios-restaurant-menu-reservations"
SRC="/home/me/SAAS/wc-restaurant"
ZIP="$SRC/$SLUG-$VER.zip"
WORK="$(mktemp -d /tmp/claude-1000/wporg-XXXXXX)"
SVN_URL="https://plugins.svn.wordpress.org/$SLUG"

echo "== $SLUG $VER -> $SVN_URL"
[ -f "$ZIP" ] || { echo "no zip: $ZIP"; exit 1; }

# The readme's Stable tag is what wp.org serves to users. If it disagrees with the version we
# are tagging, the directory offers a version that does not exist and every install breaks.
STABLE=$(unzip -p "$ZIP" "*/readme.txt" | grep -i '^Stable tag:' | tr -d '\r' | awk '{print $3}')
[ "$STABLE" = "$VER" ] || { echo "readme Stable tag '$STABLE' != '$VER' -- refusing"; exit 1; }
echo "   readme Stable tag $STABLE matches"

set -a; . /home/me/.config/rebel-studios/creds.env; set +a
[ -n "${WPORG_PASSWORD:-}" ] || { echo "WPORG_PASSWORD not set"; exit 1; }
pw() { printf '%s' "$WPORG_PASSWORD"; }
SVNOPT=(--username rebelstudios --password-from-stdin --no-auth-cache --non-interactive)

echo "== checkout"
svn checkout "$SVN_URL" "$WORK/svn" -q
cd "$WORK/svn"
mkdir -p trunk assets tags

echo "== stage trunk from the built zip"
rm -rf "$WORK/x"; mkdir -p "$WORK/x"
unzip -q "$ZIP" -d "$WORK/x"
rsync -a --delete "$WORK/x/$SLUG/" trunk/
echo "   trunk: $(find trunk -type f | wc -l) files"

echo "== stage listing assets"
for f in "$SRC"/.wporg-assets/*.png; do cp "$f" assets/; done
echo "   assets: $(ls assets | tr '\n' ' ')"

echo "== svn add"
svn add --force trunk assets tags -q 2>/dev/null || true
# wp.org serves these straight to browsers; without the mime-type they download instead of render.
find assets -name '*.png' -exec svn propset svn:mime-type image/png {} \; -q >/dev/null 2>&1 || true
find trunk -name '*.png' -exec svn propset svn:mime-type image/png {} \; -q >/dev/null 2>&1 || true

echo "== commit trunk + assets"
pw | svn commit "${SVNOPT[@]}" -m "Release $VER: menu, reservations and the listing assets"

echo "== tag $VER (server-side copy, so the tag is the committed trunk exactly)"
pw | svn copy "${SVNOPT[@]}" "$SVN_URL/trunk" "$SVN_URL/tags/$VER" \
     -m "Tag $VER" 2>&1 | tail -2

echo "== verify on the live directory (may take a few minutes to appear)"
for i in $(seq 1 10); do
  J=$(curl -sg "https://api.wordpress.org/plugins/info/1.2/?action=plugin_information&request[slug]=$SLUG" || true)
  V=$(printf '%s' "$J" | python3 -c 'import json,sys;d=json.load(sys.stdin);print(d.get("version","-"))' 2>/dev/null || echo "-")
  if [ "$V" = "$VER" ]; then
    echo "   LIVE: version $V at https://wordpress.org/plugins/$SLUG/"
    printf '%s' "$J" | python3 -c 'import json,sys;d=json.load(sys.stdin);print("   downloaded:",d.get("downloaded"),"| rating:",d.get("rating"),"| dl link:",d.get("download_link"))' 2>/dev/null || true
    exit 0
  fi
  echo "   api says '$V' (attempt $i/10), waiting 30s"
  sleep 30
done
echo "   NOT yet served by the API -- the commit succeeded, the directory can lag. Re-check:"
echo "   curl -sg 'https://api.wordpress.org/plugins/info/1.2/?action=plugin_information&request[slug]=$SLUG'"
