<?php
/**
 * Plugin Name:       Rebel Studios Event Tickets & QR Check-in
 * Plugin URI:        https://rebelstudiossoftware.com/wc-events
 * Description:       Create events, take free RSVP registrations, and email each attendee a PDF ticket with a QR code. Scan the QR to check people in at the door, or check them in from the attendee list. Paid tickets in Pro.
 * Version:           1.1.4
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * Author:            Rebel Studios Software
 * Author URI:        https://rebelstudiossoftware.com/
 * License:           GPL-3.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       rebel-studios-event-tickets
 *
 * @package RebelStudios\Events
 */

defined( 'ABSPATH' ) || exit;

define( 'RSEV_VERSION', '1.1.3' );
define( 'RSEV_FILE', __FILE__ );
define( 'RSEV_PATH', plugin_dir_path( __FILE__ ) );
define( 'RSEV_URL', plugin_dir_url( __FILE__ ) );
define( 'RSEV_BASENAME', plugin_basename( __FILE__ ) );

spl_autoload_register(
	function ( $class ) {
		$prefix = 'RebelStudios\\Events\\';
		if ( 0 !== strpos( $class, $prefix ) ) {
			return;
		}
		$path = RSEV_PATH . 'includes/' . str_replace( '\\', '/', substr( $class, strlen( $prefix ) ) ) . '.php';
		if ( is_readable( $path ) ) {
			require $path;
		}
	}
);

add_action(
	'plugins_loaded',
	function () {
		\RebelStudios\Events\Plugin::instance()->boot();
	}
);

register_activation_hook(
	__FILE__,
	function () {
		\RebelStudios\Events\Engine\Settings::seed_defaults();
		\RebelStudios\Events\Event_CPT::register(); // so rewrite rules exist
		\RebelStudios\Events\Registration::register_ticket_type();
		flush_rewrite_rules();
	}
);
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
