=== Rebel Studios Event Tickets & QR Check-in ===
Contributors: rebelstudios
Tags: events, tickets, registration, rsvp, qr code
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.4
License: GPLv3 or later
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Create events, take free RSVP registrations, and email every attendee a PDF ticket with a QR code you scan to check them in at the door.

== Description ==

A focused events plugin that does the job end to end: publish an event, let people register, and send each one a **PDF ticket with a QR code**. At the door, scan the QR with any phone (while logged in) to **check them in** — no separate app, no monthly fee.

= Free =

* **Unlimited events** with date, time, venue, capacity and description.
* **RSVP registration** form on every event page (name, email, quantity), with automatic **capacity / seats-left** handling.
* **PDF ticket with a QR code**, emailed to each attendee automatically.
* **QR check-in** — scan a ticket with a logged-in phone to mark the attendee present; the public only ever sees a "valid ticket" confirmation. Someone without their ticket can be checked in from the attendee list.
* **Attendee list + CSV export** per event.
* `[rsev_events]` upcoming-events list and `[rsev_event_register]` form shortcodes.
* Never phones home; QR codes and tickets are generated on your own server.

= Pro =

[Pro](https://rebelstudiossoftware.com/wc-events-pro) adds:

* **Paid tickets** — set a price on any event and take payment through your own WooCommerce checkout, with QR tickets issued and emailed once the order is paid.
* **Multiple ticket types** — General, VIP, Early bird and so on, each with its own price and its own capacity. The type is printed on the ticket and appears in the attendee list and CSV export.

Pro is a separate download and is not required — everything described above works on its own.

== Installation ==

1. Install and activate. An **Events** menu appears.
2. Add an event (date, venue, capacity).
3. Under **Events → Settings**, set your organizer name and logo, and turn on emailed PDF tickets.
4. Publish the event — the registration form appears on its page. Attendees get a QR ticket by email; scan it at the door to check them in.

For PDF tickets, the host needs the standard PHP `dom`/`mbstring` extensions (on virtually all hosts). Without them, the ticket email links to each ticket's page, which shows the same ticket and QR code, instead of attaching a PDF. Every ticket email carries that link, for showing the ticket on a phone.

== Frequently Asked Questions ==

= Can I sell paid tickets? =
Paid ticketing is available in the separate Pro add-on, which takes payment through your own WooCommerce checkout. The free plugin handles unlimited free RSVP events with QR tickets and check-in.

= How does check-in work? =
Each ticket's QR encodes a link back to your site. An Editor or Administrator who scans it while logged in checks that attendee in. Anyone else, including Authors and Contributors, only sees that the ticket is valid. For someone without their ticket, the Attendees screen has a Check in button on each row (and Undo, for a mistake).

= When does registration close? =
At the end of the event's day, in your site's timezone, or when the event is full. For an event that runs over several days, keep it open with the `rsev_registration_open` filter (return true for that event).

= Can one person or a bot take every seat? =
One registration takes at most 10 tickets, and one network address can take at most 20 free tickets for an event in an hour, so a script cannot fill an event or send ticket emails to any address it likes. A hidden form field also drops registrations from form-filling bots.

The limit counts everyone on one network together: an office or a school, a venue's wifi, and every visitor at once if your site sits behind a proxy or CDN that hides visitors' addresses. When many attendees register from one place, bookings past the limit are refused, and the visitor is told why. Raise the limit under Events → Settings → Tickets per connection, or set it to 0 to turn it off (developers can also use the `rsev_tickets_per_ip` filter). Anyone who can edit the event is never limited, so you can enter walk-ins at the door.

The limit is a speed bump, not a guarantee: requests sent at the same instant can get a little past it, and an attacker with many addresses can still register made-up people. The plugin does not ask attendees to confirm their email first.

= Does it work with page caching? =
Yes, with one limit: the registration form carries a WordPress security token that expires after 12 to 24 hours. If a cache keeps serving an event page for longer than that, registering fails with "The form had expired". Exclude event pages from the cache, or keep their cache lifetime under 12 hours.

= Who can see the attendee list? =
Editors and Administrators. The same rule covers the CSV export and check-in, because the list holds names and email addresses. If your door staff use another role, give it the capability you want with the `rsev_staff_capability` filter (it returns `edit_others_posts` by default).

= How do I remove an attendee, or answer a data request? =
Use Tools → Erase Personal Data with their email address: it deletes their tickets, so their seats are free again and their QR codes stop working. Tools → Export Personal Data gives you everything stored about them. The plugin also suggests text for your privacy policy under Settings → Privacy.

= What happens to attendee data when I delete the plugin? =
Its settings are removed. Tickets (attendee names and emails) stay unless you tick "When this plugin is deleted, delete every ticket too" under Events → Settings first, so deleting and reinstalling the plugin does not lose an attendee list. Events are your own posts and always stay.

= Can I have different ticket prices for the same event? =
Yes, with the Pro add-on. Define as many ticket types as you need — each has its own price and its own capacity, and a type sells out independently of the others. A type priced at zero stays on the free RSVP flow instead of going to checkout.

= What happens to a paid event if Pro is switched off? =
An event with a ticket price, or with a paid ticket type, shows its price and takes no registrations until Pro and its licence are active again, so nobody gets a paid ticket free. To run it as a free event instead, tick "Make it a free event instead" in its Event details box.

= Do I need WooCommerce? =
No. The free plugin is standalone. WooCommerce is only used by Pro for paid tickets.

== Screenshots ==

1. A PDF ticket with its QR code.
2. An event page: date, venue and price above the description, then the registration form.
3. Attendees and check-in: who is registered and who is through the door.
4. Upcoming events, from the [rsev_events] shortcode.

== Other plugins by Rebel Studios ==

Focused WooCommerce plugins that each do one job well:

* **[Rebel Studios Membership & Content Restriction](https://rebelstudiossoftware.com/membership-content-restriction)** — restrict content to members, with front-end registration and a directory.
* **[Invoice Documents for WooCommerce](https://wordpress.org/plugins/rebel-studios-invoice-documents-woocommerce/)** — automatic PDF invoices, packing slips and delivery notes.
* **[Brazilian Checkout Fields for WooCommerce](https://rebelstudiossoftware.com/checkout-brasil.html)** — CPF/CNPJ validation and CEP autofill for Brazilian stores.
* **[Restaurant Menu & Reservations](https://rebelstudiossoftware.com/wc-restaurant.html)** — a menu, table reservations and QR ordering.

== Changelog ==

= 1.1.4 =
* Changed: QR codes are now generated with bacon/bacon-qr-code (BSD-2-Clause) instead of chillerlan/php-qrcode. The previous library carries ZXing-derived files under Apache-2.0, which is not compatible with GPLv2. No change to the codes themselves.

= 1.1.3 =
* Changed: the Ticket price field is no longer in this plugin. It was switched off unless Event Tickets Pro was active; Pro now adds it to the Event details box itself. No feature in this plugin depends on Pro.
* Changed: an event whose tickets cost money, on a site that cannot take payment for them, has one way back to a free event: "Make it a free event instead" in its Event details box. It replaces clearing the price and "Remove its ticket types".
* Developer: the `rsev_event_details_fields` action adds rows to the Event details box, and the `rsev_takes_payment` filter lets an add-on say it takes payment for an event.
* Paid tickets with this version need Event Tickets Pro 1.1.5 or newer.

= 1.1.2 =
* Security: a password-protected event showed its date, venue, address, price and registration form to visitors without the password, and took their registrations. It now shows only the password form until the password is entered. Draft, scheduled and private events no longer take registrations, and the registration shortcode shows nothing for them.
* Fix: an event with a ticket price or paid Pro ticket types, on a site where nothing could take payment (Event Tickets Pro inactive, or its licence off), issued its tickets free. It now shows its price and says tickets are not on sale. Without Pro you can clear the price, or remove the ticket types, to make it a free event.
* Fix: the confirmation said the ticket had been emailed even when ticket emails were off or the email could not be sent. It now says what happened.
* Fix: on a host without PDF support the ticket email promised an attachment that was not there, and the "printable page" this readme promised did not exist. Every ticket email now links to each ticket's page, which shows the ticket and its QR code on a phone.
* New: a Check in button, and Undo, on each row of the Attendees screen, for someone without their ticket.
* Fix: registration closes after the event's day. Past events kept taking registrations and emailing tickets.
* Fix: after registering, the page opens at the confirmation instead of at the top, where on a phone it was out of sight.
* Security: one network address can take at most 20 free tickets for an event in an hour (Settings → Tickets per connection; 0 turns it off), and a hidden field drops form-filling bots. One client could fill an event in seconds and mail tickets to any address. Anyone who can edit the event is not limited.
* New: WordPress's privacy tools export and erase an attendee's tickets by email, and the plugin suggests privacy-policy text. A new setting deletes every ticket when the plugin is deleted (off by default).
* Fix: the upcoming-events list used UTC's date, so evening events left it early in the Americas and yesterday's lingered in Asia and Australia.
* Fix: the Organizer email setting was never used. Ticket emails now carry it as Reply-To.
* Fix: an expired form said "check your name and email". It now says the form expired.
* Fix: a backslash typed into the organizer name or ticket footer was deleted on save.
* Fix: asking for more tickets than were left gave fewer without saying so. The confirmation now says how many you have.
* Fix: a ticket cancelled by Pro (its order refunded) scanned as "not found"; it now says "Ticket cancelled".
* Improvement: check-in and ticket pages ask search engines not to index them.

= 1.1.1 =
* Security: the Attendees screen, the CSV export and QR check-in now need an Editor or Administrator. Before, any Contributor could read and export attendee names and emails and check people in.
* Security: the CSV export writes a name that starts with =, +, - or @ as plain text, so it cannot run as a formula when the file is opened in Excel or Google Sheets.
* Developer: `rsev_staff_capability` filter.

= 1.1.0 =
* Improvement: event pages show the date, time, venue (with a map link) and ticket price above the description.
* Improvement: a Single Event template for block themes, so event pages no longer show a blog byline or a "More posts" list.
* Improvement: redesigned registration card and upcoming-events list (date badges, clear labels, focus states, phone layout). Form fields no longer overflow their card on some themes.
* Improvement: the Attendees screen shows registered, checked in, seats left and the event date at a glance, with a check-in badge and time on each row.
* Fix: the Attendees screen now loads the plugin's admin styles (the Get Pro button sat under the title).
* Fix: the settings screen described Pro as having Stripe and reserved seating. It has neither: Pro sells paid tickets and ticket types through your WooCommerce checkout.
* Developer: `rsev_show_event_details`, `rsev_event_price_label` and `rsev_block_template` filters.

= 1.0.1 =
* Improvement: the plugin's stylesheet now loads only on pages that show events or a registration form, not on every page of the site.
* Improvement: a clear message when a ticket type (from an add-on) has fewer tickets left than requested.

= 1.0.0 =
* Initial release: events, RSVP registration, QR PDF tickets, QR check-in, attendee CSV export.
