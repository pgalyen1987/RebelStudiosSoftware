<?php
/**
 * Deleting the plugin removes its settings. Attendee tickets (names, emails, check-ins) go too
 * when "When this plugin is deleted, delete every ticket too" is ticked under Events → Settings;
 * otherwise they stay, so deleting and reinstalling the plugin does not lose an attendee list.
 * Events are the site's own posts and always stay.
 *
 * @package RebelStudios\Events
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$rsev_settings = get_option( 'rsev_settings' );
if ( is_array( $rsev_settings ) && isset( $rsev_settings['delete_on_uninstall'] ) && 'yes' === $rsev_settings['delete_on_uninstall'] ) {
	global $wpdb;
	// The plugin is not loaded during uninstall, so its post type is not registered: ask the table.
	$rsev_tickets = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = %s", 'rsev_ticket' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $rsev_tickets as $rsev_ticket ) {
		wp_delete_post( (int) $rsev_ticket, true );
	}
}
delete_option( 'rsev_settings' );
