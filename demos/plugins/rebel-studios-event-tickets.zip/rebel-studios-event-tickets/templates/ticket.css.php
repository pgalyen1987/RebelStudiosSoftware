<?php
defined( 'ABSPATH' ) || exit;
$accent = \RebelStudios\Events\Engine\Settings::get( 'accent_color', '#7c3aed' );
$accent = preg_match( '/^#[0-9a-fA-F]{3,6}$/', (string) $accent ) ? $accent : '#7c3aed';
?>
* { box-sizing: border-box; }
body { font-family: "DejaVu Sans", Arial, sans-serif; color: #1f2330; margin: 0; }
.ticket { margin: 40px; border: 2px solid <?php echo esc_html( $accent ); ?>; border-radius: 14px; overflow: hidden; }
.ticket { display: table; width: 100%; }
.stub, .body { display: table-cell; vertical-align: top; }
.stub { width: 210px; background: <?php echo esc_html( $accent ); ?>; color: #fff; padding: 22px 18px; text-align: center; }
.stub .org { font-size: 12px; opacity: .85; }
.stub .label { text-transform: uppercase; letter-spacing: 2px; font-size: 12px; margin-top: 8px; }
.stub .tno { font-size: 20px; font-weight: 700; margin: 6px 0 14px; }
.stub .qr { width: 150px; height: 150px; background: #fff; padding: 8px; border-radius: 8px; }
.stub .scan { font-size: 11px; margin-top: 10px; opacity: .9; }
.body { padding: 28px 30px; }
.body .logo { max-height: 46px; margin-bottom: 10px; }
.body h1 { font-size: 24px; margin: 0 0 16px; color: <?php echo esc_html( $accent ); ?>; }
.meta { width: 100%; border-collapse: collapse; }
.meta th { text-align: left; color: #8a90a2; font-weight: 500; width: 110px; padding: 6px 8px 6px 0; vertical-align: top; }
.meta td { padding: 6px 0; font-weight: 600; }
.foot { margin-top: 22px; padding-top: 12px; border-top: 1px solid #eee; color: #667; font-size: 12px; }
