<?php
/**
 * PDF ticket body.
 *
 * @var string $event_title @var string $when @var string $venue @var string $address
 * @var string $attendee @var string $ticket_no @var string $qr (data URI)
 * @var string $ticket_label optional ticket-type name, empty on a plain RSVP
 * @var string $organizer @var string $logo @var string $footer @var string $accent
 */
defined( 'ABSPATH' ) || exit;
?>
<div class="ticket">
	<div class="stub">
		<div class="org"><?php echo esc_html( $organizer ); ?></div>
		<div class="label"><?php esc_html_e( 'Admit one', 'rebel-studios-event-tickets' ); ?></div>
		<div class="tno">#<?php echo esc_html( $ticket_no ); ?></div>
		<?php if ( ! empty( $qr ) ) : ?><img class="qr" src="<?php echo esc_attr( $qr ); ?>" alt=""><?php endif; ?>
		<div class="scan"><?php esc_html_e( 'Scan at the door', 'rebel-studios-event-tickets' ); ?></div>
	</div>
	<div class="body">
		<?php if ( ! empty( $logo ) ) : ?><img class="logo" src="<?php echo esc_attr( $logo ); ?>" alt=""><?php endif; ?>
		<h1><?php echo esc_html( $event_title ); ?></h1>
		<table class="meta">
			<tr><th><?php esc_html_e( 'When', 'rebel-studios-event-tickets' ); ?></th><td><?php echo esc_html( $when ); ?></td></tr>
			<?php if ( ! empty( $venue ) ) : ?><tr><th><?php esc_html_e( 'Where', 'rebel-studios-event-tickets' ); ?></th><td><?php echo esc_html( $venue ); ?><?php echo $address ? '<br>' . esc_html( $address ) : ''; ?></td></tr><?php endif; ?>
			<tr><th><?php esc_html_e( 'Attendee', 'rebel-studios-event-tickets' ); ?></th><td><?php echo esc_html( $attendee ); ?></td></tr>
			<?php if ( ! empty( $ticket_label ) ) : ?><tr><th><?php esc_html_e( 'Type', 'rebel-studios-event-tickets' ); ?></th><td><?php echo esc_html( $ticket_label ); ?></td></tr><?php endif; ?>
			<tr><th><?php esc_html_e( 'Ticket', 'rebel-studios-event-tickets' ); ?></th><td>#<?php echo esc_html( $ticket_no ); ?></td></tr>
		</table>
		<?php if ( ! empty( $footer ) ) : ?><div class="foot"><?php echo nl2br( esc_html( $footer ) ); ?></div><?php endif; ?>
	</div>
</div>
