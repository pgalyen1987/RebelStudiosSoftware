<?php
namespace RebelStudios\Events;

defined( 'ABSPATH' ) || exit;

class Shortcodes {

	public static function hooks() {
		add_shortcode( 'rsev_events', array( __CLASS__, 'events_list' ) );
		add_shortcode( 'rsev_event_register', array( __CLASS__, 'register_form' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	/**
	 * Styles load only where the plugin's markup appears, not on every page of the site. Pages we
	 * can predict get them in <head>; enqueue() is also called from each output point, which covers
	 * markup rendered somewhere unpredictable (a widget, a page builder) at the cost of a late print.
	 */
	public static function assets() {
		if ( is_singular( Event_CPT::TYPE ) || self::content_has( array( 'rsev_events', 'rsev_event_register' ) ) ) {
			self::enqueue();
		}
	}

	public static function enqueue() {
		wp_enqueue_style( 'rebel-studios-event-tickets', RSEV_URL . 'assets/public/events.css', array(), RSEV_VERSION );
	}

	/** True when the singular post being viewed contains any of these shortcodes. */
	private static function content_has( array $tags ) {
		$post = is_singular() ? get_post() : null;
		if ( ! $post ) {
			return false;
		}
		foreach ( $tags as $tag ) {
			if ( has_shortcode( $post->post_content, $tag ) ) {
				return true;
			}
		}
		return false;
	}

	public static function events_list( $atts ) {
		self::enqueue();
		$atts   = shortcode_atts( array( 'limit' => 10 ), $atts, 'rsev_events' );
		$events = get_posts(
			array(
				'post_type'      => Event_CPT::TYPE,
				'posts_per_page' => (int) $atts['limit'],
				'meta_key'       => Event_CPT::M_DATE,
				'orderby'        => 'meta_value',
				'order'          => 'ASC',
				'meta_query'     => array(
					array(
						'key'     => Event_CPT::M_DATE,
						// Today in the site's timezone. gmdate() is UTC, which dropped tonight's event
						// from the list from 8pm in New York and kept yesterday's in Sydney.
						'value'   => wp_date( 'Y-m-d' ),
						'compare' => '>=',
						'type'    => 'DATE',
					),
				),
			)
		);
		if ( ! $events ) {
			return '<p class="rsev-empty">' . esc_html__( 'No upcoming events.', 'rebel-studios-event-tickets' ) . '</p>';
		}
		ob_start();
		echo '<ul class="rsev-list">';
		foreach ( $events as $e ) {
			$date  = get_post_meta( $e->ID, Event_CPT::M_DATE, true );
			$ts    = $date ? strtotime( $date ) : 0;
			$time  = get_post_meta( $e->ID, Event_CPT::M_TIME, true );
			$venue = get_post_meta( $e->ID, Event_CPT::M_VENUE, true );
			$meta  = array_filter( array( $time ? date_i18n( get_option( 'time_format' ), strtotime( $time ) ) : '', $venue ) );
			if ( post_password_required( $e ) ) {
				$meta = array(); // Its time and venue are behind its password, like the rest of its page.
			}
			// The calendar badge is decoration; the full date is in the text for screen readers.
			printf(
				'<li class="rsev-item"><a href="%1$s">%2$s<span class="rsev-info"><span class="rsev-title">%3$s</span><span class="rsev-meta"><span class="rsev-when">%4$s</span>%5$s</span></span><span class="rsev-arrow" aria-hidden="true">&rarr;</span></a></li>',
				esc_url( get_permalink( $e ) ),
				$ts ? '<span class="rsev-cal" aria-hidden="true"><span class="rsev-cal-m">' . esc_html( date_i18n( 'M', $ts ) ) . '</span><span class="rsev-cal-d">' . esc_html( date_i18n( 'j', $ts ) ) . '</span></span>' : '',
				esc_html( get_the_title( $e ) ),
				esc_html( $ts ? date_i18n( get_option( 'date_format' ), $ts ) : '' ),
				esc_html( $meta ? ' · ' . implode( ' · ', $meta ) : '' )
			);
		}
		echo '</ul>';
		return ob_get_clean();
	}

	/**
	 * When, where and what it costs, above the description on an event's page. The event post
	 * type has no template of its own, so without this a theme shows only the title and text.
	 * Return false from `rsev_show_event_details` for a theme that prints these itself.
	 */
	public static function details( $event_id ) {
		$event_id = (int) $event_id;
		if ( ! apply_filters( 'rsev_show_event_details', true, $event_id ) ) {
			return '';
		}
		self::enqueue();
		$date    = Event_CPT::get( $event_id, Event_CPT::M_DATE );
		$time    = Event_CPT::get( $event_id, Event_CPT::M_TIME );
		$venue   = Event_CPT::get( $event_id, Event_CPT::M_VENUE );
		$address = Event_CPT::get( $event_id, Event_CPT::M_ADDRESS );
		$label   = self::price_label( $event_id );

		$icon = array(
			'when'  => '<path d="M7 3v3M17 3v3M4 9h16M5 5h14a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1z"/>',
			'where' => '<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
			'price' => '<path d="M4 8a2 2 0 0 0 2-2h12a2 2 0 0 0 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 0-2 2H6a2 2 0 0 0-2-2v-2a2 2 0 0 0 0-4z"/><path d="M14 6v12" stroke-dasharray="2 2"/>',
		);
		$rows = array();
		if ( $date ) {
			$ts           = strtotime( $date );
			$sub          = date_i18n( 'l', $ts ) . ( $time ? ' · ' . date_i18n( get_option( 'time_format' ), strtotime( $time ) ) : '' );
			$rows['when'] = array( __( 'When', 'rebel-studios-event-tickets' ), esc_html( date_i18n( get_option( 'date_format' ), $ts ) ), esc_html( $sub ) );
		}
		if ( $venue || $address ) {
			$map          = $address ? sprintf( '<a href="%s" target="_blank" rel="noopener">%s</a>', esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( trim( $venue . ' ' . $address ) ) ), esc_html( $address ) ) : '';
			$rows['where'] = array( __( 'Where', 'rebel-studios-event-tickets' ), esc_html( $venue ? $venue : $address ), $venue ? $map : '' );
		}
		$rows['price'] = array( __( 'Tickets', 'rebel-studios-event-tickets' ), esc_html( $label ), '' );

		$out = '<div class="rsev-details">';
		foreach ( $rows as $key => $r ) {
			$out .= '<div class="rsev-detail"><svg class="rsev-ico" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $icon[ $key ] . '</svg>'
				. '<div><span class="rsev-k">' . esc_html( $r[0] ) . '</span><span class="rsev-v">' . $r[1] . '</span>'
				. ( $r[2] ? '<span class="rsev-sub">' . $r[2] . '</span>' : '' ) . '</div></div>';
		}
		return $out . '</div>';
	}

	/**
	 * What the event's tickets cost, as shown on its page: the single price, or the range of its
	 * ticket types ("Free – $50.00"), or "Free". Read from the event, so a type event does not read
	 * "Free" while the add-on that sells it is off.
	 *
	 * @param int $event_id Event.
	 * @return string
	 */
	public static function price_label( $event_id ) {
		$prices = Event_CPT::prices( $event_id );
		$low    = min( $prices );
		$high   = max( $prices );
		$label  = $low === $high ? self::money( $low ) : self::money( $low ) . ' – ' . self::money( $high );
		/**
		 * The price line on an event's page.
		 *
		 * @param string $label    Formatted price, a range such as "Free – $50.00" for ticket types, or "Free".
		 * @param int    $event_id Event.
		 */
		return (string) apply_filters( 'rsev_event_price_label', $label, (int) $event_id );
	}

	/** A ticket price as text: "Free" for 0, the store's own format when WooCommerce is active. */
	private static function money( $price ) {
		if ( $price <= 0 ) {
			return __( 'Free', 'rebel-studios-event-tickets' );
		}
		return function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $price ) ) : number_format_i18n( $price, 2 );
	}

	public static function register_form( $atts ) {
		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'rsev_event_register' );
		$id   = (int) $atts['id'];
		// The shortcode can sit on any public page, so only for a published event with no password.
		if ( ! $id || get_post_type( $id ) !== Event_CPT::TYPE || 'publish' !== get_post_status( $id ) || post_password_required( $id ) ) {
			return '';
		}
		return Registration::form( $id );
	}
}
