<?php
/**
 * The Event post type and its details metabox. An event is a normal post with
 * a date, venue and capacity. Kept deliberately simple: the value is in
 * registration + tickets + check-in, not in a heavy calendar. Ticket prices are
 * set by an add-on (Event Tickets Pro) through the rsev_event_details_fields
 * action; this plugin only reads them.
 *
 * @package RebelStudios\Events
 */

namespace RebelStudios\Events;

defined( 'ABSPATH' ) || exit;

class Event_CPT {

	const TYPE = 'rsev_event';

	const M_DATE     = '_rsev_date';
	const M_TIME     = '_rsev_time';
	const M_VENUE    = '_rsev_venue';
	const M_ADDRESS  = '_rsev_address';
	const M_CAPACITY = '_rsev_capacity';
	const M_PRICE    = '_rsev_price';
	// Event Tickets Pro's ticket types (General, VIP...), each with its own price. Read here, never
	// written except to remove them ("Make it a free event"), so an event that sells types counts as
	// priced even while Pro is off: before, deactivating Pro or losing its licence turned a $20/$50
	// event into a free one.
	const M_TYPES    = '_rsevp_types';

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'metabox' ) );
		add_action( 'save_post_' . self::TYPE, array( __CLASS__, 'save' ), 10, 2 );
		add_action( 'init', array( __CLASS__, 'block_template' ) );
	}

	/**
	 * An event page template for block themes. Without one a block theme falls back to its blog
	 * post template, which prints "Written by … in …" and a "More posts" list above and below an
	 * event. The theme's own header and footer parts frame it; it shows in the Site Editor under
	 * Templates, where it can be edited like any other. WordPress 6.7+.
	 */
	public static function block_template() {
		if ( ! function_exists( 'register_block_template' ) || ! wp_is_block_theme() || ! apply_filters( 'rsev_block_template', true ) ) {
			return;
		}
		register_block_template(
			'rebel-studios-event-tickets//single-' . self::TYPE,
			array(
				'title'       => __( 'Single Event', 'rebel-studios-event-tickets' ),
				'description' => __( 'An event page: title, image, details, description and the registration form.', 'rebel-studios-event-tickets' ),
				'post_types'  => array( self::TYPE ),
				'content'     => '<!-- wp:template-part {"slug":"header","area":"header"} /-->'
					. '<!-- wp:group {"tagName":"main","style":{"spacing":{"margin":{"top":"var:preset|spacing|60"},"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"constrained"}} -->'
					. '<main class="wp-block-group" style="margin-top:var(--wp--preset--spacing--60);padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--50)">'
					. '<!-- wp:post-title {"level":1} /-->'
					. '<!-- wp:post-featured-image {"aspectRatio":"16/9","style":{"border":{"radius":"14px"}}} /-->'
					. '<!-- wp:post-content {"layout":{"type":"constrained"}} /-->'
					. '</main><!-- /wp:group -->'
					. '<!-- wp:template-part {"slug":"footer","area":"footer"} /-->',
			)
		);
	}

	public static function register() {
		register_post_type(
			self::TYPE,
			array(
				'labels'       => array(
					'name'          => __( 'Events', 'rebel-studios-event-tickets' ),
					'singular_name' => __( 'Event', 'rebel-studios-event-tickets' ),
					'add_new_item'  => __( 'Add Event', 'rebel-studios-event-tickets' ),
					'edit_item'     => __( 'Edit Event', 'rebel-studios-event-tickets' ),
					'menu_name'     => __( 'Events', 'rebel-studios-event-tickets' ),
				),
				'public'       => true,
				'has_archive'  => true,
				'menu_icon'    => 'dashicons-tickets-alt',
				'rewrite'      => array( 'slug' => 'events' ),
				'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
				'show_in_rest' => true,
			)
		);
	}

	public static function metabox() {
		add_meta_box( 'rsev-details', __( 'Event details', 'rebel-studios-event-tickets' ), array( __CLASS__, 'render' ), self::TYPE, 'normal', 'high' );
	}

	public static function render( $post ) {
		wp_nonce_field( 'rsev_save_event', 'rsev_event_nonce' );
		$g = function ( $k ) use ( $post ) { return get_post_meta( $post->ID, $k, true ); };
		?>
		<style>.rsev-grid{display:grid;grid-template-columns:160px 1fr;gap:10px 14px;max-width:640px;align-items:center}.rsev-grid label{font-weight:600}.rsev-grid span label{font-weight:400}</style>
		<div class="rsev-grid">
			<label for="rsev_date"><?php esc_html_e( 'Date', 'rebel-studios-event-tickets' ); ?></label>
			<input type="date" id="rsev_date" name="rsev_date" value="<?php echo esc_attr( $g( self::M_DATE ) ); ?>">
			<label for="rsev_time"><?php esc_html_e( 'Start time', 'rebel-studios-event-tickets' ); ?></label>
			<input type="time" id="rsev_time" name="rsev_time" value="<?php echo esc_attr( $g( self::M_TIME ) ); ?>">
			<label for="rsev_venue"><?php esc_html_e( 'Venue', 'rebel-studios-event-tickets' ); ?></label>
			<input type="text" id="rsev_venue" name="rsev_venue" class="regular-text" value="<?php echo esc_attr( $g( self::M_VENUE ) ); ?>">
			<label for="rsev_address"><?php esc_html_e( 'Address', 'rebel-studios-event-tickets' ); ?></label>
			<input type="text" id="rsev_address" name="rsev_address" class="regular-text" value="<?php echo esc_attr( $g( self::M_ADDRESS ) ); ?>">
			<label for="rsev_capacity"><?php esc_html_e( 'Capacity', 'rebel-studios-event-tickets' ); ?></label>
			<input type="number" min="0" id="rsev_capacity" name="rsev_capacity" value="<?php echo esc_attr( $g( self::M_CAPACITY ) ); ?>" placeholder="<?php esc_attr_e( '0 = unlimited', 'rebel-studios-event-tickets' ); ?>">
			<?php
			/**
			 * More rows in the Event details box, each a label and a field like the rows above.
			 * Event Tickets Pro adds the ticket price here. An add-on saves its own fields, on
			 * `save_post_rsev_event`.
			 *
			 * @param \WP_Post $post Event being edited.
			 */
			do_action( 'rsev_event_details_fields', $post );

			// Tickets that cost money, and nothing on the site to take the payment: the event takes no
			// registrations (Registration::on_sale()). Say so, and offer the way back to a free event.
			if ( self::is_priced( $post->ID ) && ! Registration::takes_payment( $post->ID ) ) :
				?>
				<strong><?php esc_html_e( 'Tickets', 'rebel-studios-event-tickets' ); ?></strong>
				<span>
					<?php
					/* translators: %s: what the tickets cost, e.g. "$25.00" or "$20.00 – $50.00" */
					echo esc_html( sprintf( __( 'Tickets cost %s. They are sold through Event Tickets Pro, which is off or has no active licence, so this event takes no registrations.', 'rebel-studios-event-tickets' ), Shortcodes::price_label( $post->ID ) ) );
					?>
					<br><label><input type="checkbox" name="rsev_make_free" value="1"> <?php esc_html_e( 'Make it a free event instead: remove its ticket prices and take free RSVPs', 'rebel-studios-event-tickets' ); ?></label>
				</span>
				<?php
			endif;
			?>
		</div>
		<?php
	}

	public static function save( $post_id, $post ) {
		if ( ! isset( $_POST['rsev_event_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['rsev_event_nonce'] ) ), 'rsev_save_event' ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		$map = array(
			self::M_DATE     => isset( $_POST['rsev_date'] ) ? sanitize_text_field( wp_unslash( $_POST['rsev_date'] ) ) : '',
			self::M_TIME     => isset( $_POST['rsev_time'] ) ? sanitize_text_field( wp_unslash( $_POST['rsev_time'] ) ) : '',
			self::M_VENUE    => isset( $_POST['rsev_venue'] ) ? sanitize_text_field( wp_unslash( $_POST['rsev_venue'] ) ) : '',
			self::M_ADDRESS  => isset( $_POST['rsev_address'] ) ? sanitize_text_field( wp_unslash( $_POST['rsev_address'] ) ) : '',
			self::M_CAPACITY => isset( $_POST['rsev_capacity'] ) ? absint( $_POST['rsev_capacity'] ) : 0,
		);
		// "Make it a free event", offered while the event's tickets cost money and nothing takes payment.
		if ( ! empty( $_POST['rsev_make_free'] ) ) {
			delete_post_meta( $post_id, self::M_TYPES );
			$map[ self::M_PRICE ] = 0;
		}
		foreach ( $map as $k => $v ) {
			update_post_meta( $post_id, $k, $v );
		}
	}

	public static function get( $event_id, $key ) {
		return get_post_meta( $event_id, $key, true );
	}

	/**
	 * What a ticket costs: one price per Pro ticket type when the event has types (they replace the
	 * single price, as Pro sells them), otherwise the single ticket price. 0 is free.
	 *
	 * @param int $event_id Event.
	 * @return float[] Never empty.
	 */
	public static function prices( $event_id ) {
		$prices = self::type_prices( $event_id );
		return $prices ? $prices : array( max( 0.0, (float) get_post_meta( (int) $event_id, self::M_PRICE, true ) ) );
	}

	/** True when any ticket for the event costs money, so only a working checkout may issue it. */
	public static function is_priced( $event_id ) {
		return max( self::prices( $event_id ) ) > 0;
	}

	/** One price per Pro ticket type (rows without a label do not count, as in Pro), or none. */
	private static function type_prices( $event_id ) {
		$prices = array();
		$types  = get_post_meta( (int) $event_id, self::M_TYPES, true );
		foreach ( is_array( $types ) ? $types : array() as $row ) {
			if ( is_array( $row ) && ! empty( $row['label'] ) ) {
				$prices[] = isset( $row['price'] ) ? max( 0.0, (float) $row['price'] ) : 0.0;
			}
		}
		return $prices;
	}

	/** Seats left, or null for unlimited. */
	public static function seats_left( $event_id ) {
		$cap = (int) get_post_meta( $event_id, self::M_CAPACITY, true );
		if ( $cap <= 0 ) {
			return null;
		}
		return max( 0, $cap - Registration::count_attendees( $event_id ) );
	}
}
