<?php
/**
 * Check-in. A ticket's QR encodes a URL back to the site; a logged-in staff
 * member who opens it (by scanning with a phone) checks that attendee in. The
 * public sees only a "valid ticket" confirmation, never a way to self-check-in.
 * Also provides the admin attendee list + CSV export.
 *
 * @package RebelStudios\Events
 */

namespace RebelStudios\Events;

use RebelStudios\Events\Engine\Admin;

defined( 'ABSPATH' ) || exit;

class Checkin {

	const QUERY  = 'rsev_checkin';
	const VIEW   = 'rsev_ticket';
	const EXPORT = 'rsev_export';
	const MANUAL = 'rsev_manual_checkin';

	private static $instance;
	public static function instance() {
		return self::$instance ?: ( self::$instance = new self() );
	}

	public function hooks() {
		add_action( 'template_redirect', array( $this, 'maybe_handle_scan' ) );
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_post_' . self::EXPORT, array( $this, 'export_csv' ) );
		add_action( 'admin_post_' . self::MANUAL, array( $this, 'manual_checkin' ) );
	}

	/**
	 * Who may see attendees, export them and check people in. Names and emails are personal
	 * data, so this is edit_others_posts (Editors and Administrators), not edit_posts, which
	 * every Contributor has. A site whose door staff hold another role can change it with the
	 * rsev_staff_capability filter.
	 */
	public static function staff_cap() {
		return (string) apply_filters( 'rsev_staff_capability', 'edit_others_posts' );
	}

	public static function url( $token ) {
		return add_query_arg( self::QUERY, rawurlencode( $token ), home_url( '/' ) );
	}

	/** The attendee's own link to their ticket, sent in the ticket email. Opening it never checks anyone in. */
	public static function view_url( $token ) {
		return add_query_arg( self::VIEW, rawurlencode( $token ), home_url( '/' ) );
	}

	/** A scanned QR, or an attendee opening their ticket link, lands here. */
	public function maybe_handle_scan() {
		if ( ! empty( $_GET[ self::VIEW ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- token IS the credential.
			self::show_ticket( sanitize_text_field( wp_unslash( $_GET[ self::VIEW ] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}
		if ( empty( $_GET[ self::QUERY ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- token IS the credential.
			return;
		}
		$token  = sanitize_text_field( wp_unslash( $_GET[ self::QUERY ] ) );
		$ticket = self::find_by_token( $token );

		status_header( 200 );
		nocache_headers();
		if ( ! $ticket ) {
			self::page( __( 'Ticket not found', 'rebel-studios-event-tickets' ), '<p>' . esc_html__( 'This code does not match any ticket.', 'rebel-studios-event-tickets' ) . '</p>', '#b91c1c' );
		}
		if ( 'trash' === $ticket->post_status ) {
			// Cancelled, e.g. by Pro when its order was refunded. Say so, so the door knows why.
			self::page( __( 'Ticket cancelled', 'rebel-studios-event-tickets' ), '<p>' . esc_html__( 'This ticket was cancelled and does not admit anyone.', 'rebel-studios-event-tickets' ) . '</p>', '#b91c1c' );
		}

		$name  = get_post_meta( $ticket->ID, Registration::M_NAME, true );
		$event = (int) get_post_meta( $ticket->ID, Registration::M_EVENT, true );
		$title = get_the_title( $event );
		$done  = (int) get_post_meta( $ticket->ID, Registration::M_CHECKED, true );

		// Only staff can actually check someone in.
		if ( current_user_can( self::staff_cap() ) ) {
			if ( $done ) {
				$when = get_post_meta( $ticket->ID, Registration::M_CHECKTS, true );
				self::page( __( 'Already checked in', 'rebel-studios-event-tickets' ), '<p><strong>' . esc_html( $name ) . '</strong><br>' . esc_html( $title ) . '</p><p>' . esc_html( sprintf( /* translators: %s: check-in time */ __( 'Checked in at %s', 'rebel-studios-event-tickets' ), $when ) ) . '</p>', '#b45309' );
			}
			update_post_meta( $ticket->ID, Registration::M_CHECKED, 1 );
			update_post_meta( $ticket->ID, Registration::M_CHECKTS, current_time( 'mysql' ) );
			self::page( __( 'Checked in', 'rebel-studios-event-tickets' ), '<p style="font-size:22px"><strong>' . esc_html( $name ) . '</strong></p><p>' . esc_html( $title ) . '</p><p>' . esc_html__( 'Ticket', 'rebel-studios-event-tickets' ) . ' #' . (int) $ticket->ID . '</p>', '#15803d' );
		}

		// Public view: confirm validity only.
		self::page( __( 'Valid ticket', 'rebel-studios-event-tickets' ), '<p><strong>' . esc_html( $name ) . '</strong><br>' . esc_html( $title ) . '</p><p>' . esc_html__( 'Please have staff scan this ticket at the door.', 'rebel-studios-event-tickets' ) . '</p>', '#4338ca' );
	}

	/**
	 * The ticket as a page: the same ticket as the PDF, QR included, for showing on a phone at the
	 * door, and the ticket itself on a host that cannot make PDFs. It only displays: its QR carries
	 * the check-in link, which checks someone in only when staff scan it. A link scanner opening
	 * the email's links therefore checks no one in.
	 *
	 * @param string $token Ticket token from the link.
	 */
	private static function show_ticket( $token ) {
		$ticket = self::find_by_token( $token );
		status_header( 200 );
		nocache_headers();
		if ( ! $ticket ) {
			self::page( __( 'Ticket not found', 'rebel-studios-event-tickets' ), '<p>' . esc_html__( 'This link does not match any ticket.', 'rebel-studios-event-tickets' ) . '</p>', '#b91c1c' );
		}
		if ( 'trash' === $ticket->post_status ) {
			self::page( __( 'Ticket cancelled', 'rebel-studios-event-tickets' ), '<p>' . esc_html__( 'This ticket was cancelled and does not admit anyone.', 'rebel-studios-event-tickets' ) . '</p>', '#b91c1c' );
		}
		header( 'X-Robots-Tag: noindex, nofollow' );
		echo Renderer::html( Registration::ticket_context( $ticket->ID ), true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the ticket template escapes every field.
		exit;
	}

	/** The ticket with this token: a live one, or a cancelled one in the trash. */
	private static function find_by_token( $token ) {
		$q = new \WP_Query(
			array(
				'post_type'     => Registration::TICKET_TYPE,
				'post_status'   => array( 'publish', 'trash' ),
				'posts_per_page'=> 1,
				'meta_key'      => Registration::M_TOKEN,
				'meta_value'    => $token,
				'no_found_rows' => true,
			)
		);
		return $q->posts ? $q->posts[0] : null;
	}

	private static function page( $title, $body_html, $color ) {
		// A check-in page shows an attendee's name; it is reached only through a ticket's secret link,
		// and should never be indexed should one be posted somewhere.
		header( 'X-Robots-Tag: noindex, nofollow' );
		?>
<!DOCTYPE html><html <?php language_attributes(); ?>><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title><?php echo esc_html( $title ); ?></title>
<style>body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;background:#f3f4f6;margin:0;padding:0;color:#111}
.card{max-width:420px;margin:12vh auto;background:#fff;border-radius:16px;box-shadow:0 12px 40px rgba(0,0,0,.1);overflow:hidden;text-align:center}
.bar{background:<?php echo esc_attr( $color ); ?>;color:#fff;padding:22px;font-size:22px;font-weight:700}
.inner{padding:26px 24px;line-height:1.5}</style></head>
<body><div class="card"><div class="bar"><?php echo esc_html( $title ); ?></div><div class="inner"><?php echo wp_kses_post( $body_html ); ?></div></div></body></html>
		<?php
		exit;
	}

	/* ---------- Admin attendee list ---------- */

	public function menu() {
		add_submenu_page(
			'edit.php?post_type=' . Event_CPT::TYPE,
			__( 'Attendees & Check-in', 'rebel-studios-event-tickets' ),
			__( 'Attendees', 'rebel-studios-event-tickets' ),
			self::staff_cap(),
			'rsev-attendees',
			array( $this, 'render_attendees' )
		);
	}

	public function render_attendees() {
		$events   = get_posts( array( 'post_type' => Event_CPT::TYPE, 'numberposts' => -1, 'orderby' => 'date', 'order' => 'DESC' ) );
		$event_id = isset( $_GET['event'] ) ? absint( $_GET['event'] ) : ( $events ? $events[0]->ID : 0 ); // phpcs:ignore WordPress.Security.NonceVerification
		echo '<div class="wrap rsev-admin">';
		Admin::header( __( 'Attendees & Check-in', 'rebel-studios-event-tickets' ) );

		if ( ! $event_id ) {
			echo '<div class="rsev-empty-state"><p>' . esc_html__( 'Create an event first.', 'rebel-studios-event-tickets' ) . '</p>';
			printf( '<a class="button button-primary" href="%s">%s</a></div>', esc_url( admin_url( 'post-new.php?post_type=' . Event_CPT::TYPE ) ), esc_html__( 'Add Event', 'rebel-studios-event-tickets' ) );
			echo '</div>';
			return;
		}

		$tickets = Registration::tickets_for_event( $event_id );
		$in      = 0;
		foreach ( $tickets as $t ) { $in += (int) get_post_meta( $t->ID, Registration::M_CHECKED, true ) ? 1 : 0; }
		$left = Event_CPT::seats_left( $event_id );
		$date = Event_CPT::get( $event_id, Event_CPT::M_DATE );
		$time = Event_CPT::get( $event_id, Event_CPT::M_TIME );

		echo '<div class="rsev-toolbar">';
		echo '<form method="get"><input type="hidden" name="post_type" value="' . esc_attr( Event_CPT::TYPE ) . '"><input type="hidden" name="page" value="rsev-attendees">';
		echo '<label class="screen-reader-text" for="rsev-event">' . esc_html__( 'Event', 'rebel-studios-event-tickets' ) . '</label>';
		echo '<select id="rsev-event" name="event" onchange="this.form.submit()">';
		foreach ( $events as $e ) {
			printf( '<option value="%d" %s>%s</option>', (int) $e->ID, selected( $event_id, $e->ID, false ), esc_html( get_the_title( $e ) ) );
		}
		echo '</select> <button class="button">' . esc_html__( 'View', 'rebel-studios-event-tickets' ) . '</button>';
		echo '</form>';
		printf(
			'<a class="button" href="%s">%s</a>',
			esc_url( wp_nonce_url( add_query_arg( array( 'action' => self::EXPORT, 'event' => $event_id ), admin_url( 'admin-post.php' ) ), self::EXPORT ) ),
			esc_html__( 'Export CSV', 'rebel-studios-event-tickets' )
		);
		echo '</div>';

		// At a glance: the four numbers someone on the door asks for.
		$pct   = $tickets ? (int) round( 100 * $in / count( $tickets ) ) : 0;
		$stats = array(
			array( number_format_i18n( count( $tickets ) ), __( 'Registered', 'rebel-studios-event-tickets' ), '' ),
			array( number_format_i18n( $in ), __( 'Checked in', 'rebel-studios-event-tickets' ), $tickets ? sprintf( /* translators: %d: percent of attendees checked in */ __( '%d%% of attendees', 'rebel-studios-event-tickets' ), $pct ) : '' ),
			array( null === $left ? '∞' : number_format_i18n( $left ), __( 'Seats left', 'rebel-studios-event-tickets' ), null === $left ? __( 'No capacity set', 'rebel-studios-event-tickets' ) : '' ),
			array( $date ? date_i18n( 'M j', strtotime( $date ) ) : '—', __( 'Event date', 'rebel-studios-event-tickets' ), trim( ( $date ? date_i18n( 'l', strtotime( $date ) ) : '' ) . ( $time ? ' · ' . date_i18n( get_option( 'time_format' ), strtotime( $time ) ) : '' ), ' ·' ) ),
		);
		echo '<div class="rsev-stats">';
		foreach ( $stats as $st ) {
			echo '<div class="rsev-stat"><span class="rsev-stat-n">' . esc_html( $st[0] ) . '</span><span class="rsev-stat-l">' . esc_html( $st[1] ) . '</span>' . ( $st[2] ? '<span class="rsev-stat-sub">' . esc_html( $st[2] ) . '</span>' : '' ) . '</div>';
		}
		echo '</div>';
		if ( $tickets ) {
			echo '<div class="rsev-progress" role="presentation"><span style="width:' . (int) $pct . '%"></span></div>';
		}

		if ( ! $tickets ) {
			echo '<div class="rsev-empty-state"><p>' . esc_html__( 'Nobody has registered yet. Registrations appear here as they come in.', 'rebel-studios-event-tickets' ) . '</p></div>';
			echo '</div>';
			return;
		}

		// Only show the Type column when an add-on has actually labelled tickets,
		// so a plain RSVP event never grows an empty column.
		$labels = array();
		foreach ( $tickets as $t ) {
			$labels[ $t->ID ] = (string) get_post_meta( $t->ID, Registration::M_LABEL, true );
		}
		$has_labels = (bool) array_filter( $labels );

		echo '<table class="widefat striped rsev-attendees"><thead><tr>';
		echo '<th class="rsev-col-no">' . esc_html__( 'Ticket', 'rebel-studios-event-tickets' ) . '</th><th>' . esc_html__( 'Name', 'rebel-studios-event-tickets' ) . '</th><th>' . esc_html__( 'Email', 'rebel-studios-event-tickets' ) . '</th>';
		if ( $has_labels ) {
			echo '<th>' . esc_html__( 'Type', 'rebel-studios-event-tickets' ) . '</th>';
		}
		echo '<th>' . esc_html__( 'Checked in', 'rebel-studios-event-tickets' ) . '</th></tr></thead><tbody>';
		$nonce = wp_create_nonce( self::MANUAL );
		foreach ( $tickets as $t ) {
			$checked = (int) get_post_meta( $t->ID, Registration::M_CHECKED, true );
			$email   = (string) get_post_meta( $t->ID, Registration::M_EMAIL, true );
			// Check someone in without their QR (a dead phone, a ticket email that never arrived),
			// and undo a mistake.
			$button = sprintf(
				'<form method="post" action="%1$s" class="rsev-inline"><input type="hidden" name="action" value="%2$s"><input type="hidden" name="ticket" value="%3$d"><input type="hidden" name="_wpnonce" value="%4$s">%5$s<button type="submit" class="button button-small">%6$s</button></form>',
				esc_url( admin_url( 'admin-post.php' ) ),
				esc_attr( self::MANUAL ),
				(int) $t->ID,
				esc_attr( $nonce ),
				$checked ? '<input type="hidden" name="undo" value="1">' : '',
				$checked ? esc_html__( 'Undo', 'rebel-studios-event-tickets' ) : esc_html__( 'Check in', 'rebel-studios-event-tickets' )
			);
			echo '<tr id="rsev-t' . (int) $t->ID . '">';
			printf(
				'<td class="rsev-col-no">#%1$d</td><td><strong>%2$s</strong></td><td><a href="mailto:%3$s">%4$s</a></td>',
				(int) $t->ID,
				esc_html( get_post_meta( $t->ID, Registration::M_NAME, true ) ),
				esc_attr( $email ),
				esc_html( $email )
			);
			if ( $has_labels ) {
				echo '<td>' . ( $labels[ $t->ID ] ? '<span class="rsev-tag">' . esc_html( $labels[ $t->ID ] ) . '</span>' : '—' ) . '</td>';
			}
			if ( $checked ) {
				$ts = (string) get_post_meta( $t->ID, Registration::M_CHECKTS, true );
				echo '<td><span class="rsev-badge rsev-badge-in">' . esc_html__( 'In', 'rebel-studios-event-tickets' ) . '</span> ' . ( $ts ? '<span class="rsev-when">' . esc_html( mysql2date( get_option( 'time_format' ), $ts ) ) . '</span>' : '' ) . $button . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $button is escaped where it is built.
			} else {
				echo '<td><span class="rsev-badge">' . esc_html__( 'Not yet', 'rebel-studios-event-tickets' ) . '</span>' . $button . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $button is escaped where it is built.
			}
			echo '</tr>';
		}
		echo '</tbody></table>';
		echo '<p class="description">' . esc_html__( 'Check people in by scanning their ticket QR with a phone while logged in, or with the Check in button for someone without their ticket.', 'rebel-studios-event-tickets' ) . '</p>';
		echo '</div>';
	}

	/** The Check in / Undo button on the Attendees screen. Same capability as a QR scan. */
	public function manual_checkin() {
		if ( ! current_user_can( self::staff_cap() ) ) {
			wp_die( esc_html__( 'Not allowed.', 'rebel-studios-event-tickets' ), 403 );
		}
		check_admin_referer( self::MANUAL );
		$ticket_id = isset( $_POST['ticket'] ) ? absint( $_POST['ticket'] ) : 0;
		if ( ! $ticket_id || Registration::TICKET_TYPE !== get_post_type( $ticket_id ) || 'publish' !== get_post_status( $ticket_id ) ) {
			wp_die( esc_html__( 'Ticket not found.', 'rebel-studios-event-tickets' ), 404 );
		}
		if ( empty( $_POST['undo'] ) ) {
			update_post_meta( $ticket_id, Registration::M_CHECKED, 1 );
			update_post_meta( $ticket_id, Registration::M_CHECKTS, current_time( 'mysql' ) );
		} else {
			update_post_meta( $ticket_id, Registration::M_CHECKED, 0 );
			delete_post_meta( $ticket_id, Registration::M_CHECKTS );
		}
		$event = (int) get_post_meta( $ticket_id, Registration::M_EVENT, true );
		wp_safe_redirect( add_query_arg( array( 'post_type' => Event_CPT::TYPE, 'page' => 'rsev-attendees', 'event' => $event ), admin_url( 'edit.php' ) ) . '#rsev-t' . $ticket_id );
		exit;
	}

	public function export_csv() {
		if ( ! current_user_can( self::staff_cap() ) ) {
			wp_die( esc_html__( 'Not allowed.', 'rebel-studios-event-tickets' ), 403 );
		}
		check_admin_referer( self::EXPORT );
		$event_id = isset( $_GET['event'] ) ? absint( $_GET['event'] ) : 0;
		$tickets  = $event_id ? Registration::tickets_for_event( $event_id ) : array();

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="attendees-' . $event_id . '.csv"' );
		$rows = array( array( 'Ticket', 'Name', 'Email', 'Type', 'Checked in', 'Time' ) );
		foreach ( $tickets as $t ) {
			$rows[] = array(
				$t->ID,
				get_post_meta( $t->ID, Registration::M_NAME, true ),
				get_post_meta( $t->ID, Registration::M_EMAIL, true ),
				get_post_meta( $t->ID, Registration::M_LABEL, true ),
				get_post_meta( $t->ID, Registration::M_CHECKED, true ) ? 'yes' : 'no',
				get_post_meta( $t->ID, Registration::M_CHECKTS, true ),
			);
		}
		$lines = array();
		foreach ( $rows as $r ) {
			$lines[] = implode( ',', array_map( function ( $v ) {
				$v = (string) $v;
				// Names come from a public form, and a cell opening with = + - @ (or tab/CR) runs
				// as a formula in Excel and Sheets. A leading apostrophe keeps it plain text.
				if ( '' !== $v && false !== strpos( "=+-@\t\r", $v[0] ) ) {
					$v = "'" . $v;
				}
				return ( false !== strpos( $v, ',' ) || false !== strpos( $v, '"' ) || false !== strpos( $v, "\n" ) ) ? '"' . str_replace( '"', '""', $v ) . '"' : $v;
			}, $r ) );
		}
		echo implode( "\n", $lines ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- CSV download body.
		exit;
	}
}
