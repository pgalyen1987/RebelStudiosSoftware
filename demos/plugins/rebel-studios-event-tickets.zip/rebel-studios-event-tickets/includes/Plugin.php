<?php
namespace RebelStudios\Events;

use RebelStudios\Events\Engine\Admin;

defined( 'ABSPATH' ) || exit;

class Plugin {

	private static $instance;

	public static function instance() {
		return self::$instance ?: ( self::$instance = new self() );
	}

	public function boot() {
		Event_CPT::init();
		Registration::instance()->hooks();
		Checkin::instance()->hooks();
		( new Settings_Page() )->hooks();
		Shortcodes::hooks();
		Privacy::hooks();
		Admin::enqueue();
	}
}
