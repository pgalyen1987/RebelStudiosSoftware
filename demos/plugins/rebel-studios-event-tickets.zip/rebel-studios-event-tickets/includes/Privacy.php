<?php
/**
 * WordPress's privacy tools for attendees: Tools → Export Personal Data and Erase Personal Data
 * find the tickets registered to an email address. A ticket stores the name and email typed into
 * the registration form, and tickets have no screen of their own, so without this a site could not
 * answer an access or erasure request for an attendee. Also suggests privacy-policy text.
 *
 * @package RebelStudios\Events
 */

namespace RebelStudios\Events;

defined( 'ABSPATH' ) || exit;

class Privacy {

	const KEY      = 'rebel-studios-event-tickets';
	const PER_PAGE = 100;

	public static function hooks() {
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'add_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'add_eraser' ) );
		add_action( 'admin_init', array( __CLASS__, 'policy_text' ) );
	}

	public static function add_exporter( $exporters ) {
		$exporters[ self::KEY ] = array(
			'exporter_friendly_name' => __( 'Event tickets', 'rebel-studios-event-tickets' ),
			'callback'               => array( __CLASS__, 'export' ),
		);
		return $exporters;
	}

	public static function add_eraser( $erasers ) {
		$erasers[ self::KEY ] = array(
			'eraser_friendly_name' => __( 'Event tickets', 'rebel-studios-event-tickets' ),
			'callback'             => array( __CLASS__, 'erase' ),
		);
		return $erasers;
	}

	/**
	 * Tickets registered to an email address. Trashed ones count too: a ticket an add-on cancelled
	 * still holds the name until the trash is emptied.
	 */
	private static function tickets( $email, $page ) {
		return get_posts(
			array(
				'post_type'      => Registration::TICKET_TYPE,
				'post_status'    => array( 'publish', 'trash' ),
				'posts_per_page' => self::PER_PAGE,
				'paged'          => max( 1, (int) $page ),
				'orderby'        => 'ID',
				'order'          => 'ASC',
				'meta_key'       => Registration::M_EMAIL, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => (string) $email, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			)
		);
	}

	public static function export( $email, $page = 1 ) {
		$items   = array();
		$tickets = self::tickets( $email, $page );
		foreach ( $tickets as $t ) {
			$event   = (int) get_post_meta( $t->ID, Registration::M_EVENT, true );
			$checked = (int) get_post_meta( $t->ID, Registration::M_CHECKED, true );
			$data    = array(
				array( 'name' => __( 'Event', 'rebel-studios-event-tickets' ), 'value' => get_the_title( $event ) ),
				array( 'name' => __( 'Event date', 'rebel-studios-event-tickets' ), 'value' => (string) Event_CPT::get( $event, Event_CPT::M_DATE ) ),
				array( 'name' => __( 'Name', 'rebel-studios-event-tickets' ), 'value' => (string) get_post_meta( $t->ID, Registration::M_NAME, true ) ),
				array( 'name' => __( 'Email', 'rebel-studios-event-tickets' ), 'value' => (string) get_post_meta( $t->ID, Registration::M_EMAIL, true ) ),
				array( 'name' => __( 'Ticket', 'rebel-studios-event-tickets' ), 'value' => '#' . $t->ID ),
				array( 'name' => __( 'Registered', 'rebel-studios-event-tickets' ), 'value' => $t->post_date ),
				array( 'name' => __( 'Checked in', 'rebel-studios-event-tickets' ), 'value' => $checked ? (string) get_post_meta( $t->ID, Registration::M_CHECKTS, true ) : __( 'No', 'rebel-studios-event-tickets' ) ),
			);
			$label = (string) get_post_meta( $t->ID, Registration::M_LABEL, true );
			if ( '' !== $label ) {
				$data[] = array( 'name' => __( 'Ticket type', 'rebel-studios-event-tickets' ), 'value' => $label );
			}
			$items[] = array(
				'group_id'    => 'rsev-tickets',
				'group_label' => __( 'Event tickets', 'rebel-studios-event-tickets' ),
				'item_id'     => 'rsev-ticket-' . $t->ID,
				'data'        => $data,
			);
		}
		return array(
			'data' => $items,
			'done' => count( $tickets ) < self::PER_PAGE,
		);
	}

	/** Deletes the tickets: the name and email go, the seat is freed and the QR stops checking in. */
	public static function erase( $email, $page = 1 ) {
		// Always the first page: each pass deletes what it found, so the next batch moves up.
		$tickets = self::tickets( $email, 1 );
		$removed = false;
		foreach ( $tickets as $t ) {
			$removed = (bool) wp_delete_post( $t->ID, true ) || $removed;
		}
		return array(
			'items_removed'  => $removed,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => count( $tickets ) < self::PER_PAGE,
		);
	}

	public static function policy_text() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}
		wp_add_privacy_policy_content(
			__( 'Rebel Studios Event Tickets & QR Check-in', 'rebel-studios-event-tickets' ),
			wp_kses_post( wpautop( __( 'When you register for an event, we store the name and email address you enter with your ticket, so we can email the ticket to you and check you in at the door. The ticket also records whether and when you were checked in. Editors and administrators of this site can see the attendee list and export it. Your ticket is emailed through this site\'s own email; the plugin does not send your details to its authors or to any other service. To stop one connection from booking a whole event, the site also keeps a scrambled form of your network address, which cannot be read back, for one hour after you register.', 'rebel-studios-event-tickets' ) ) )
		);
	}
}
