<?php
/**
 * Options wrapper. One serialized option row, typed defaults, sanitized writes.
 * Engine class -- shared verbatim across Rebel Studios plugins; the only
 * per-plugin coupling is the OPTION_KEY and the $defaults map.
 *
 * @package RebelStudios\Events\Engine
 */

namespace RebelStudios\Events\Engine;

defined( 'ABSPATH' ) || exit;

class Settings {

	const OPTION_KEY = 'rsev_settings';

	/**
	 * Field key => default value. Also the allow-list: a key absent here is
	 * never read or written, so a crafted POST cannot smuggle options in.
	 */
	public static function defaults() {
		return array(
			'organizer_name'  => get_bloginfo( 'name' ),
			'organizer_email' => get_bloginfo( 'admin_email' ),
			'logo_id'         => 0,
			'accent_color'    => '#7c3aed',
			'ticket_footer'   => '',
			'send_ticket'     => 'yes',   // email a PDF ticket on registration
			'paper'           => 'a4',    // a4|letter
			'delete_on_uninstall' => 'no', // yes: deleting the plugin also deletes every ticket (uninstall.php)
			'tickets_per_ip'  => 20,      // free tickets one network address may book per event per hour; 0 = no limit
				);
	}

	public static function all() {
		$saved = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}
		return array_merge( self::defaults(), $saved );
	}

	public static function get( $key, $fallback = null ) {
		$all = self::all();
		if ( array_key_exists( $key, $all ) ) {
			return $all[ $key ];
		}
		return $fallback;
	}

	public static function update( array $values ) {
		$current = self::all();
		$clean   = array();
		foreach ( self::defaults() as $key => $default ) {
			if ( ! array_key_exists( $key, $values ) ) {
				$clean[ $key ] = $current[ $key ];
				continue;
			}
			$clean[ $key ] = self::sanitize_field( $key, $values[ $key ], $default );
		}
		update_option( self::OPTION_KEY, $clean );
		return $clean;
	}

	public static function seed_defaults() {
		if ( false === get_option( self::OPTION_KEY, false ) ) {
			add_option( self::OPTION_KEY, self::defaults() );
		}
	}

	/**
	 * Values arrive unslashed (Settings_Page::save() unslashes $_POST, as update_option() callers
	 * should), so they are not unslashed again here: a second pass deleted every backslash typed
	 * into the organizer name or the ticket footer.
	 */
	private static function sanitize_field( $key, $value, $default ) {
		switch ( $key ) {
			case 'ticket_footer':
				return sanitize_textarea_field( $value );
			case 'organizer_email':
				return sanitize_email( $value );
			case 'accent_color':
				$c = sanitize_hex_color( $value );
				return $c ? $c : $default;
			case 'logo_id':
				return max( 0, absint( $value ) );
			case 'send_ticket':
				return 'yes' === $value ? 'yes' : 'no';
			case 'paper':
				return in_array( $value, array( 'a4', 'letter' ), true ) ? $value : $default;
			case 'tickets_per_ip':
				// An emptied field keeps the default; 0 is a deliberate "no limit".
				return '' === trim( (string) $value ) ? $default : min( 100000, absint( $value ) );
			default:
				return sanitize_text_field( $value );
				}
	}
}
