<?php
/**
 * The upgrade link and the "Pro" badge.
 *
 * Every feature in this plugin works without Pro, and none checks for it. Event
 * Tickets Pro is a separate plugin, sold off-site, that adds its own features
 * (paid tickets, ticket types) through this plugin's hooks. While it is active
 * and licensed it answers the `rsev_is_pro` filter true, and the only effect
 * here is that the "Get Pro" button and badges are hidden.
 *
 * Engine class -- lifts to other plugins by changing the three constants.
 *
 * @package RebelStudios\Events\Engine
 */

namespace RebelStudios\Events\Engine;

defined( 'ABSPATH' ) || exit;

class Freemium {

	const IS_PRO_FILTER = 'rsev_is_pro';
	const UPGRADE_URL   = 'https://rebelstudiossoftware.com/wc-events';
	const PRODUCT       = 'rebel-studios-event-tickets';

	/** True while Event Tickets Pro is active and licensed. Only hides the upgrade prompts. */
	public static function is_pro() {
		return (bool) apply_filters( self::IS_PRO_FILTER, false );
	}

	public static function upgrade_url( $utm_content = 'generic' ) {
		return add_query_arg(
			array(
				'utm_source'  => 'plugin',
				'utm_medium'  => 'admin',
				'utm_campaign'=> self::PRODUCT,
				'utm_content' => sanitize_key( $utm_content ),
			),
			self::UPGRADE_URL
		);
	}

	/** A small inline "Pro" pill linking to the Pro page, next to a description of what Pro adds. */
	public static function badge( $utm_content = 'badge' ) {
		return sprintf(
			' <a class="wcinv-pro-pill" target="_blank" rel="noopener" href="%s">%s</a>',
			esc_url( self::upgrade_url( $utm_content ) ),
			esc_html__( 'Pro', 'rebel-studios-event-tickets' )
		);
	}
}
