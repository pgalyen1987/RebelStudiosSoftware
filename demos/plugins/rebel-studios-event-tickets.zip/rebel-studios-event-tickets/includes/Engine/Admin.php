<?php
/**
 * Admin chrome: the settings submenu under WooCommerce, shared asset enqueue,
 * and a consistent page header carrying the upgrade button. Engine class.
 *
 * @package RebelStudios\Events\Engine
 */

namespace RebelStudios\Events\Engine;

defined( 'ABSPATH' ) || exit;

class Admin {

	const MENU_SLUG = 'rs-events';

	public static function register_page( $render_cb ) {
		add_action(
			'admin_menu',
			function () use ( $render_cb ) {
				add_submenu_page(
					'woocommerce',
					__( 'Invoices & Packing Slips', 'rebel-studios-event-tickets' ),
					__( 'Invoices', 'rebel-studios-event-tickets' ),
					'manage_woocommerce',
					self::MENU_SLUG,
					$render_cb
				);
			}
		);
	}

	public static function is_own_screen() {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}
		$screen = get_current_screen();
		// The settings page and the Attendees screen; the latter's id is rsev_event_page_rsev-attendees,
		// so matching the settings slug alone left it unstyled.
		foreach ( array( self::MENU_SLUG, 'rsev-attendees' ) as $slug ) {
			if ( $screen && false !== strpos( (string) $screen->id, $slug ) ) {
				return true;
			}
		}
		return false;
	}

	public static function enqueue() {
		add_action(
			'admin_enqueue_scripts',
			function () {
				if ( ! self::is_own_screen() ) {
					return;
				}
				wp_enqueue_media();
				wp_enqueue_style(
					'rsev-admin',
					RSEV_URL . 'assets/admin/admin.css',
					array(),
					RSEV_VERSION
				);
				wp_enqueue_script(
					'rsev-admin',
					RSEV_URL . 'assets/admin/admin.js',
					array( 'jquery' ),
					RSEV_VERSION,
					true
				);
			}
		);
	}

	/** Consistent page header with the (honest) upgrade call to action. */
	public static function header( $title ) {
		echo '<div class="wcinv-header">';
		echo '<h1>' . esc_html( $title ) . '</h1>';
		if ( ! Freemium::is_pro() ) {
			printf(
				'<a class="button button-primary wcinv-upgrade" target="_blank" rel="noopener" href="%s">%s</a>',
				esc_url( Freemium::upgrade_url( 'header' ) ),
				esc_html__( 'Get Pro', 'rebel-studios-event-tickets' )
			);
		}
		echo '</div>';
	}
}
