<?php
/**
 * Ticket HTML -> PDF. On a host with no PDF engine pdf() returns null, and the ticket email
 * relies on its links to each ticket's page (Checkin::view_url), which renders html() for a
 * screen. Remote fetching is disabled; the QR and logo are embedded as data: URIs, so no network
 * request is ever made while rendering.
 *
 * @package RebelStudios\Events
 */

namespace RebelStudios\Events;

use RebelStudios\Events\Engine\Settings;

defined( 'ABSPATH' ) || exit;

class Renderer {

	public static function is_pdf_available() {
		return extension_loaded( 'dom' ) && extension_loaded( 'mbstring' );
	}

	/**
	 * The ticket as HTML.
	 *
	 * @param array $context From Registration::ticket_context().
	 * @param bool  $screen  For a browser (the attendee's ticket link) rather than the PDF: adds a
	 *                       viewport, a title and noindex, centres the ticket at its natural width,
	 *                       and stacks it into one column on a phone. The PDF never sees these.
	 */
	public static function html( array $context, $screen = false ) {
		$body = self::capture( RSEV_PATH . 'templates/ticket.php', $context );
		$css  = self::capture( RSEV_PATH . 'templates/ticket.css.php', array() );
		$head = '';
		if ( $screen ) {
			// The PDF's .ticket is width:100% plus a 40px margin, which a browser draws 40-80px wider
			// than the window. On a screen it takes its natural width instead.
			$css .= 'body{background:#f3f4f6}.ticket{width:auto;max-width:760px;margin:32px auto;background:#fff}'
				. '@media (max-width:560px){.ticket{display:block;margin:12px}.stub,.body{display:block;width:auto}.body{padding:22px 20px}}';
			$head = '<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' . esc_html( isset( $context['event_title'] ) ? $context['event_title'] : '' ) . '</title>';
		}
		ob_start();
		?>
<!DOCTYPE html>
<html><head><meta charset="utf-8"><?php echo $head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts above. ?><style><?php echo $css; // phpcs:ignore ?></style></head>
<body><?php echo $body; // phpcs:ignore ?></body></html>
		<?php
		return (string) ob_get_clean();
	}

	public static function pdf( array $context ) {
		if ( ! self::is_pdf_available() ) {
			return null;
		}
		$autoload = RSEV_PATH . 'vendor/autoload.php';
		if ( is_readable( $autoload ) ) {
			require_once $autoload;
		}
		if ( ! class_exists( '\Dompdf\Dompdf' ) ) {
			return null;
		}
		$options = new \Dompdf\Options();
		$options->set( 'isRemoteEnabled', false );
		$options->set( 'isHtml5ParserEnabled', true );
		$options->set( 'defaultFont', 'DejaVu Sans' );
		$dompdf = new \Dompdf\Dompdf( $options );
		$dompdf->loadHtml( self::html( $context ), 'UTF-8' );
		$dompdf->setPaper( 'letter' === Settings::get( 'paper' ) ? 'letter' : 'a4', 'portrait' );
		$dompdf->render();
		return $dompdf->output();
	}

	public static function pdf_to_tmp( array $context, $filename ) {
		$bytes = self::pdf( $context );
		if ( null === $bytes ) {
			return null;
		}
		$path = trailingslashit( get_temp_dir() ) . sanitize_file_name( $filename );
		return ( false === file_put_contents( $path, $bytes ) ) ? null : $path; // phpcs:ignore
	}

	private static function capture( $__file, $context ) {
		if ( ! is_readable( $__file ) ) {
			return '';
		}
		// phpcs:ignore WordPress.PHP.DontExtract
		extract( $context, EXTR_SKIP );
		ob_start();
		include $__file;
		return (string) ob_get_clean();
	}
}
