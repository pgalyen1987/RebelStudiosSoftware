<?php
/**
 * The registration flow: render the RSVP form on an event, validate and store
 * attendees (one ticket post each, with a unique check-in token), and email each
 * a PDF ticket with a QR code. Registration here is free RSVP; an add-on that
 * sells tickets (Event Tickets Pro) takes over through `rsev_pre_register`.
 *
 * @package RebelStudios\Events
 */

namespace RebelStudios\Events;

use RebelStudios\Events\Engine\Settings;

defined( 'ABSPATH' ) || exit;

class Registration {

	const TICKET_TYPE = 'rsev_ticket';
	const ACTION      = 'rsev_register';
	const MAX_QTY     = 10;

	const M_EVENT    = '_rsev_event_id';
	const M_NAME     = '_rsev_name';
	const M_EMAIL    = '_rsev_email';
	const M_TOKEN    = '_rsev_token';
	const M_CHECKED  = '_rsev_checked_in'; // 0/1
	const M_CHECKTS  = '_rsev_checkin_time';
	const M_SEQ      = '_rsev_seq';        // n of qty in a registration
	const M_LABEL    = '_rsev_label';      // optional ticket-type label, set by an add-on

	private static $instance;
	public static function instance() {
		return self::$instance ?: ( self::$instance = new self() );
	}

	public function hooks() {
		add_action( 'init', array( __CLASS__, 'register_ticket_type' ) );
		add_action( 'admin_post_nopriv_' . self::ACTION, array( $this, 'handle' ) );
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle' ) );
		add_filter( 'the_content', array( $this, 'append_form' ) );
	}

	public static function register_ticket_type() {
		register_post_type(
			self::TICKET_TYPE,
			array(
				'public'       => false,
				'show_ui'      => false,
				'supports'     => array( 'title' ),
				'rewrite'      => false,
				'query_var'    => false,
			)
		);
	}

	/* ---------- Front-end form ---------- */

	public function append_form( $content ) {
		// A password-protected event's content is WordPress's password form, and the_content still runs
		// on it: without this check its date, venue, address, price and registration form showed to
		// anyone who had not entered the password.
		if ( is_singular( Event_CPT::TYPE ) && in_the_loop() && is_main_query() && ! post_password_required() ) {
			$content = Shortcodes::details( get_the_ID() ) . $content . self::form( get_the_ID() );
		}
		return $content;
	}

	public static function form( $event_id ) {
		Shortcodes::enqueue();
		$event_id = (int) $event_id;
		$left     = Event_CPT::seats_left( $event_id );
		$notice   = '';
		if ( isset( $_GET['rsev'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- read-only status flag.
			$flag = sanitize_key( wp_unslash( $_GET['rsev'] ) );
			// Fewer seats were left than the visitor asked for, so they hold fewer tickets: say so.
			$got  = isset( $_GET['rsev_got'] ) ? absint( $_GET['rsev_got'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only status flag.
			$less = $got
				/* translators: %d: number of tickets issued, which is all the seats that were left */
				? ' ' . sprintf( _n( 'Only %1$d seat was left, so you have %1$d ticket.', 'Only %1$d seats were left, so you have %1$d tickets.', $got, 'rebel-studios-event-tickets' ), $got )
				: '';
			if ( 'ok' === $flag ) {
				$notice = '<div class="rsev-note rsev-ok">' . esc_html__( 'You are registered — your ticket has been emailed to you.', 'rebel-studios-event-tickets' ) . esc_html( $less ) . '</div>';
			} elseif ( 'listed' === $flag ) {
				// The organiser has ticket emails turned off: there is no ticket to send.
				$notice = '<div class="rsev-note rsev-ok">' . esc_html__( 'You are registered. Give your name at the door.', 'rebel-studios-event-tickets' ) . esc_html( $less ) . '</div>';
			} elseif ( 'mailfail' === $flag ) {
				$notice = '<div class="rsev-note rsev-err">' . esc_html__( 'You are registered, but your ticket email could not be sent. Give your name at the door.', 'rebel-studios-event-tickets' ) . esc_html( $less ) . '</div>';
			} elseif ( 'full' === $flag ) {
				$notice = '<div class="rsev-note rsev-err">' . esc_html__( 'Sorry — this event is now full.', 'rebel-studios-event-tickets' ) . '</div>';
			} elseif ( 'closed' === $flag ) {
				$notice = '<div class="rsev-note rsev-err">' . esc_html__( 'Registration for this event has closed.', 'rebel-studios-event-tickets' ) . '</div>';
			} elseif ( 'busy' === $flag ) {
				$notice = '<div class="rsev-note rsev-err">' . esc_html__( 'Too many tickets for this event were booked from your connection in the last hour, so nothing was booked. Please try again later, or tell the organiser if many people share your network.', 'rebel-studios-event-tickets' ) . '</div>';
			} elseif ( 'nosale' === $flag ) {
				// An add-on could not take payment (its store is off, say), so nothing was booked.
				$notice = '<div class="rsev-note rsev-err">' . esc_html__( 'Tickets for this event are not on sale right now, so nothing was booked.', 'rebel-studios-event-tickets' ) . '</div>';
			} elseif ( 'expired' === $flag ) {
				$notice = '<div class="rsev-note rsev-err">' . esc_html__( 'The form had expired, so nothing was booked. Please try again.', 'rebel-studios-event-tickets' ) . '</div>';
			} elseif ( 'err' === $flag ) {
				$notice = '<div class="rsev-note rsev-err">' . esc_html__( 'Please check your name and a valid email address.', 'rebel-studios-event-tickets' ) . '</div>';
			} elseif ( 'limit' === $flag ) {
				// An add-on's per-type capacity: the event has room, the chosen type does not.
				$type_left = isset( $_GET['rsev_left'] ) ? absint( $_GET['rsev_left'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only status flag.
				$message   = $type_left
					/* translators: %d: tickets of the chosen type still available */
					? sprintf( _n( 'Only %d ticket of that type is left — choose a smaller quantity.', 'Only %d tickets of that type are left — choose a smaller quantity.', $type_left, 'rebel-studios-event-tickets' ), $type_left )
					: __( 'That ticket type is sold out — choose another.', 'rebel-studios-event-tickets' );
				$notice    = '<div class="rsev-note rsev-err">' . esc_html( $message ) . '</div>';
			}
		}

		ob_start();
		// The id is where a registration lands back, so the result is on screen, not below the description.
		echo '<div class="rsev-register" id="' . esc_attr( self::anchor( $event_id ) ) . '">';
		if ( ! self::on_sale( $event_id ) ) {
			echo '<p class="rsev-soldout">' . esc_html__( 'Tickets for this event are not on sale right now.', 'rebel-studios-event-tickets' ) . '</p></div>';
			return ob_get_clean();
		}
		echo wp_kses_post( $notice );
		if ( ! self::is_open( $event_id ) ) {
			echo '<p class="rsev-soldout">' . esc_html__( 'Registration for this event has closed.', 'rebel-studios-event-tickets' ) . '</p></div>';
			return ob_get_clean();
		}
		if ( null !== $left && $left <= 0 ) {
			echo '<p class="rsev-soldout">' . esc_html__( 'This event is full.', 'rebel-studios-event-tickets' ) . '</p></div>';
			return ob_get_clean();
		}
		?>
		<h3><?php esc_html_e( 'Register', 'rebel-studios-event-tickets' ); ?></h3>
		<?php if ( null !== $left ) : ?>
			<p class="rsev-left"><?php echo esc_html( sprintf( /* translators: %d: number of remaining seats */ _n( '%d seat left', '%d seats left', $left, 'rebel-studios-event-tickets' ), $left ) ); ?></p>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rsev-form">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
			<input type="hidden" name="event_id" value="<?php echo esc_attr( $event_id ); ?>">
			<?php wp_nonce_field( self::ACTION . '_' . $event_id ); ?>
			<?php // A field people never see. Form-filling bots fill it, and their registrations are dropped. ?>
			<p class="rsev-hp" aria-hidden="true" style="position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);clip-path:inset(50%);white-space:nowrap;border:0"><label><?php esc_html_e( 'Leave this empty', 'rebel-studios-event-tickets' ); ?><input type="text" name="rsev_hp" value="" tabindex="-1" autocomplete="off"></label></p>
			<p><label><?php esc_html_e( 'Your name', 'rebel-studios-event-tickets' ); ?><br><input type="text" name="rsev_name" required></label></p>
			<p><label><?php esc_html_e( 'Email', 'rebel-studios-event-tickets' ); ?><br><input type="email" name="rsev_email" required></label></p>
			<?php
			/**
			 * Extra fields between the email and quantity inputs.
			 *
			 * The form nonce above is verified before `rsev_pre_register` fires, so a
			 * handler may read its own `$_POST` fields without re-checking it.
			 *
			 * @param int $event_id Event being registered for.
			 */
			do_action( 'rsev_register_form_fields', $event_id );
			?>
			<p><label><?php esc_html_e( 'Tickets', 'rebel-studios-event-tickets' ); ?><br>
				<select name="rsev_qty">
					<?php
					$max = self::MAX_QTY;
					if ( null !== $left ) { $max = min( $max, $left ); }
					for ( $i = 1; $i <= max( 1, $max ); $i++ ) { echo '<option>' . (int) $i . '</option>'; }
					?>
				</select>
			</label></p>
			<p><button type="submit" class="rsev-btn"><?php esc_html_e( 'Get tickets', 'rebel-studios-event-tickets' ); ?></button></p>
		</form>
		<?php
		echo '</div>';
		return ob_get_clean();
	}

	/* ---------- Handler ---------- */

	public function handle() {
		$event_id = isset( $_POST['event_id'] ) ? absint( $_POST['event_id'] ) : 0;
		$nonce    = isset( $_POST['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_wpnonce'] ) ) : '';

		if ( ! $event_id || get_post_type( $event_id ) !== Event_CPT::TYPE ) {
			wp_safe_redirect( add_query_arg( 'rsev', 'err', home_url() ) );
			exit;
		}
		// A form older than the nonce's life (a page cache serving yesterday's copy, a tab left open
		// overnight) is not a typing mistake, so it gets its own message.
		if ( ! wp_verify_nonce( $nonce, self::ACTION . '_' . $event_id ) ) {
			self::back( $event_id, 'expired' );
		}
		// Only an event this visitor can see: not one behind a password they have not entered, and not
		// a draft, scheduled, private or trashed one, unless they can read it (an editor previewing).
		if ( ! self::is_open( $event_id ) || 'trash' === get_post_status( $event_id ) || post_password_required( $event_id )
			|| ( ! is_post_publicly_viewable( $event_id ) && ! current_user_can( 'read_post', $event_id ) ) ) {
			self::back( $event_id, 'closed' );
		}
		if ( ! empty( $_POST['rsev_hp'] ) ) {
			self::back( $event_id, 'err' ); // The hidden field is filled: a bot.
		}
		$name  = isset( $_POST['rsev_name'] ) ? sanitize_text_field( wp_unslash( $_POST['rsev_name'] ) ) : '';
		$email = isset( $_POST['rsev_email'] ) ? sanitize_email( wp_unslash( $_POST['rsev_email'] ) ) : '';
		$qty   = isset( $_POST['rsev_qty'] ) ? max( 1, min( self::MAX_QTY, absint( $_POST['rsev_qty'] ) ) ) : 1;

		if ( '' === $name || ! is_email( $email ) ) {
			self::back( $event_id, 'err' );
		}

		$asked = $qty;
		$left  = Event_CPT::seats_left( $event_id );
		if ( null !== $left ) {
			if ( $left <= 0 ) {
				self::back( $event_id, 'full' );
			}
			$qty = min( $qty, $left );
		}

		/**
		 * Take over the registration before any ticket is issued.
		 *
		 * An add-on (Pro) returns a URL to send the visitor somewhere else --
		 * a paid event sends them to checkout and issues tickets only once the
		 * order is paid. Returning anything but a non-empty string leaves the
		 * free RSVP flow below untouched.
		 *
		 * @param false|string $takeover Redirect URL, or false to continue.
		 * @param int          $event_id Event being registered for.
		 * @param array        $attendee name, email, qty.
		 */
		$takeover = apply_filters( 'rsev_pre_register', false, $event_id, compact( 'name', 'email', 'qty' ) );
		if ( is_string( $takeover ) && '' !== $takeover ) {
			wp_safe_redirect( $takeover );
			exit;
		}
		// Nothing took payment for a priced event (a single price or a paid ticket type). Its page shows
		// the price, so it must not be handed out free; before 1.1.2 it was, whenever Pro or its
		// licence was off.
		if ( ! self::on_sale( $event_id ) ) {
			self::back( $event_id, 'nosale' );
		}
		if ( ! self::take_ip_allowance( $event_id, $qty ) ) {
			self::back( $event_id, 'busy' );
		}

		$ticket_ids = array();
		for ( $i = 1; $i <= $qty; $i++ ) {
			$ticket_ids[] = self::create_ticket( $event_id, $name, $email, $i );
		}
		// Say "emailed" only when an email went out: the organiser can turn ticket emails off, and a
		// site's mailer can fail.
		if ( self::email_tickets( $email, $name, $event_id, $ticket_ids ) ) {
			$flag = 'ok';
		} else {
			$flag = 'yes' === Settings::get( 'send_ticket' ) ? 'mailfail' : 'listed';
		}
		self::back( $event_id, $flag, $qty < $asked ? array( 'rsev_got' => $qty ) : array() );
	}

	/**
	 * Registration stays open until the end of the event's day, in the site's timezone. An event with
	 * no date stays open. Return false from `rsev_registration_open` to close one sooner, or true to
	 * keep a multi-day event open.
	 *
	 * @param int $event_id Event.
	 */
	public static function is_open( $event_id ) {
		$date = (string) Event_CPT::get( $event_id, Event_CPT::M_DATE );
		$open = ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || $date >= wp_date( 'Y-m-d' );
		return (bool) apply_filters( 'rsev_registration_open', $open, (int) $event_id );
	}

	/**
	 * Count free tickets against the visitor's network address, and refuse past the limit: 20 tickets
	 * for one event in an hour by default, set under Events → Settings (0 turns it off; the
	 * `rsev_tickets_per_ip` filter overrides it). Enough for a family or a group on one connection,
	 * while one script can no longer fill an event (or send a ticket email to any address it likes)
	 * in a minute. Everyone on one network shares its address: an office, a school, a venue's wifi,
	 * and every visitor of a site behind a proxy or CDN that hides their addresses. Those sites raise
	 * the limit or turn it off. Anyone who can edit the event is never counted, so an organiser
	 * entering walk-ins at the door is not stopped. Only a keyed hash of the address is kept, for the
	 * hour.
	 *
	 * Best effort, not a lock: requests from one address that arrive at the same instant can each
	 * pass the check before either is counted, so a script sending in parallel gets a little past it.
	 *
	 * @param int $event_id Event.
	 * @param int $qty      Tickets about to be issued.
	 * @return bool False when this would go over the limit; nothing is counted then.
	 */
	private static function take_ip_allowance( $event_id, $qty ) {
		if ( current_user_can( Checkin::staff_cap() ) || current_user_can( 'edit_post', (int) $event_id ) ) {
			return true;
		}
		$limit = (int) apply_filters( 'rsev_tickets_per_ip', (int) Settings::get( 'tickets_per_ip', 20 ), (int) $event_id );
		$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		if ( $limit <= 0 || '' === $ip ) {
			return true;
		}
		$key  = 'rsev_ip_' . wp_hash( $ip . '|' . (int) $event_id );
		$seen = get_transient( $key );
		if ( ! is_array( $seen ) || ! isset( $seen['n'], $seen['until'] ) || $seen['until'] <= time() ) {
			$seen = array( 'n' => 0, 'until' => time() + HOUR_IN_SECONDS );
		}
		if ( $seen['n'] + $qty > $limit ) {
			return false;
		}
		$seen['n'] += $qty;
		set_transient( $key, $seen, max( 1, $seen['until'] - time() ) );
		return true;
	}

	/** The registration card's id on the event page, where a registration lands back. */
	public static function anchor( $event_id ) {
		return 'rsev-register-' . (int) $event_id;
	}

	/**
	 * Back to the event's registration card with a status flag for form() to show, and stop. The
	 * fragment matters on a phone: without it the page reopened at the top, the confirmation three
	 * screens down, which invited a second registration.
	 *
	 * @param int    $event_id Event.
	 * @param string $flag     Status flag.
	 * @param array  $extra    More query args for form().
	 */
	private static function back( $event_id, $flag, array $extra = array() ) {
		wp_safe_redirect( add_query_arg( array_merge( array( 'rsev' => $flag ), $extra ), get_permalink( $event_id ) ) . '#' . self::anchor( $event_id ) );
		exit;
	}

	/**
	 * Whether the event's tickets can be issued here: always for a free event. Tickets that cost money
	 * (a ticket price or a paid ticket type, both set by an add-on) only while something on the site
	 * takes the payment, because this plugin cannot charge and must not hand a paid ticket out free.
	 * The organiser can make the event free instead, in its Event details box.
	 *
	 * @param int $event_id Event.
	 */
	public static function on_sale( $event_id ) {
		return ! Event_CPT::is_priced( $event_id ) || self::takes_payment( $event_id );
	}

	/**
	 * Whether something on the site takes payment for this event's tickets. This plugin does not.
	 *
	 * @param int $event_id Event.
	 */
	public static function takes_payment( $event_id ) {
		/**
		 * An add-on that sells tickets returns true while it can take payment for the event. It then
		 * owns paid registrations, through `rsev_pre_register`.
		 *
		 * @param bool $takes    False: this plugin takes no payment.
		 * @param int  $event_id Event.
		 */
		return (bool) apply_filters( 'rsev_takes_payment', false, (int) $event_id );
	}

	/**
	 * Issue one ticket.
	 *
	 * @param int    $event_id Event.
	 * @param string $name     Attendee name.
	 * @param string $email    Attendee email.
	 * @param int    $seq      n of qty within one registration.
	 * @param string $label    Optional ticket-type label, shown on the ticket and the
	 *                         attendee list. Add-ons set this; free RSVP leaves it empty.
	 * @return int Ticket post ID, or 0 on failure.
	 */
	public static function create_ticket( $event_id, $name, $email, $seq, $label = '' ) {
		$id = wp_insert_post(
			array(
				'post_type'   => self::TICKET_TYPE,
				'post_status' => 'publish',
				'post_title'  => sprintf( '%s — %s', get_the_title( $event_id ), $name ),
			)
		);
		if ( is_wp_error( $id ) || ! $id ) {
			return 0;
		}
		update_post_meta( $id, self::M_EVENT, (int) $event_id );
		update_post_meta( $id, self::M_NAME, $name );
		update_post_meta( $id, self::M_EMAIL, $email );
		update_post_meta( $id, self::M_TOKEN, wp_generate_password( 24, false, false ) );
		update_post_meta( $id, self::M_CHECKED, 0 );
		update_post_meta( $id, self::M_SEQ, (int) $seq );
		if ( '' !== (string) $label ) {
			update_post_meta( $id, self::M_LABEL, sanitize_text_field( $label ) );
		}

		/**
		 * Fires after a ticket is created, on both the free and paid paths.
		 *
		 * Lets an add-on stamp its own meta on tickets the free RSVP flow issued.
		 * The paid flow knows the label up front and passes it as $label instead.
		 *
		 * @param int $id       New ticket post ID.
		 * @param int $event_id Event.
		 * @param int $seq      n of qty within this registration.
		 */
		do_action( 'rsev_ticket_created', $id, (int) $event_id, (int) $seq );

		return $id;
	}

	public static function count_attendees( $event_id ) {
		$q = new \WP_Query(
			array(
				'post_type'      => self::TICKET_TYPE,
				'post_status'    => 'publish',
				'fields'         => 'ids',
				'nopaging'       => true,
				'meta_key'       => self::M_EVENT,
				'meta_value'     => (int) $event_id,
				'no_found_rows'  => true,
			)
		);
		return count( $q->posts );
	}

	public static function tickets_for_event( $event_id ) {
		$q = new \WP_Query(
			array(
				'post_type'   => self::TICKET_TYPE,
				'post_status' => 'publish',
				'nopaging'    => true,
				'meta_key'    => self::M_EVENT,
				'meta_value'  => (int) $event_id,
				'orderby'     => 'ID',
				'order'       => 'ASC',
			)
		);
		return $q->posts;
	}

	/* ---------- Ticket document + email ---------- */

	public static function ticket_context( $ticket_id ) {
		$event_id = (int) get_post_meta( $ticket_id, self::M_EVENT, true );
		$token    = get_post_meta( $ticket_id, self::M_TOKEN, true );
		$date     = Event_CPT::get( $event_id, Event_CPT::M_DATE );
		$time     = Event_CPT::get( $event_id, Event_CPT::M_TIME );
		$when     = trim( ( $date ? date_i18n( get_option( 'date_format' ), strtotime( $date ) ) : '' ) . ( $time ? ' · ' . date_i18n( get_option( 'time_format' ), strtotime( $time ) ) : '' ) );

		$logo_uri = '';
		$logo_id  = (int) Settings::get( 'logo_id' );
		if ( $logo_id ) {
			$path = get_attached_file( $logo_id );
			if ( $path && is_readable( $path ) ) {
				$ft = wp_check_filetype( $path );
				if ( ! empty( $ft['type'] ) && 0 === strpos( $ft['type'], 'image/' ) ) {
					$logo_uri = 'data:' . $ft['type'] . ';base64,' . base64_encode( file_get_contents( $path ) ); // phpcs:ignore
				}
			}
		}

		return array(
			'event_title' => get_the_title( $event_id ),
			'when'        => $when ? $when : __( 'See event page', 'rebel-studios-event-tickets' ),
			'venue'       => Event_CPT::get( $event_id, Event_CPT::M_VENUE ),
			'address'     => Event_CPT::get( $event_id, Event_CPT::M_ADDRESS ),
			'attendee'    => get_post_meta( $ticket_id, self::M_NAME, true ),
			'ticket_label'=> (string) get_post_meta( $ticket_id, self::M_LABEL, true ),
			'ticket_no'   => (string) $ticket_id,
			'qr'          => QR::data_uri( Checkin::url( $token ) ),
			'organizer'   => Settings::get( 'organizer_name' ),
			'logo'        => $logo_uri,
			'footer'      => Settings::get( 'ticket_footer' ),
			'accent'      => Settings::get( 'accent_color' ),
		);
	}

	/**
	 * Email an attendee their tickets: a PDF of each, and a link to each ticket's page, which shows
	 * the same ticket and QR code on a phone. On a host that cannot make PDFs the links are the
	 * tickets, and the email says so instead of promising an attachment.
	 *
	 * @return bool True when the mailer accepted the email; false when ticket emails are turned off
	 *              or sending failed.
	 */
	public static function email_tickets( $email, $name, $event_id, array $ticket_ids ) {
		if ( 'yes' !== Settings::get( 'send_ticket' ) ) {
			return false;
		}
		$attachments = array();
		$links       = array();
		foreach ( $ticket_ids as $tid ) {
			if ( ! $tid ) {
				continue;
			}
			$path = Renderer::pdf_to_tmp( self::ticket_context( $tid ), 'ticket-' . $tid . '.pdf' );
			if ( $path ) {
				$attachments[] = $path;
			}
			$links[] = Checkin::view_url( get_post_meta( $tid, self::M_TOKEN, true ) );
		}
		$title   = get_the_title( $event_id );
		$subject = sprintf( /* translators: %s: event name */ __( 'Your ticket for %s', 'rebel-studios-event-tickets' ), $title );
		$lines   = array(
			sprintf( /* translators: %s: attendee name */ __( 'Hi %s,', 'rebel-studios-event-tickets' ), $name ),
			'',
			sprintf( /* translators: %s: event name */ __( 'You are registered for %s.', 'rebel-studios-event-tickets' ), $title ),
			$attachments
				? __( 'Your ticket(s) are attached as a PDF with a QR code — show it at the door. To show it on your phone instead, open:', 'rebel-studios-event-tickets' )
				: __( 'Open your ticket and show its QR code at the door:', 'rebel-studios-event-tickets' ),
		);
		$lines   = array_merge( $lines, $links, array( '', get_permalink( $event_id ) ) );
		$headers = array( 'Content-Type: text/plain; charset=UTF-8' );
		// A reply ("I can't come", "can I bring a friend?") goes to the Organizer email from Settings.
		// Reply-To rather than From, which would fail the site's SPF/DMARC and land in spam. The name
		// loses the characters that could break out of the header.
		$reply = sanitize_email( (string) Settings::get( 'organizer_email' ) );
		if ( is_email( $reply ) ) {
			$who       = trim( str_replace( array( '"', '<', '>', ',', ';', ':', '\\', "\r", "\n" ), '', (string) Settings::get( 'organizer_name' ) ) );
			$headers[] = 'Reply-To: ' . ( '' !== $who ? '"' . $who . '" <' . $reply . '>' : $reply );
		}
		$sent    = wp_mail( $email, $subject, implode( "\n", $lines ), $headers, $attachments );

		foreach ( $attachments as $p ) {
			@unlink( $p ); // phpcs:ignore -- temp file cleanup after send.
		}
		return (bool) $sent;
	}
}
