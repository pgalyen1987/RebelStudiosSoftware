<?php
/**
 * QR code -> data: URI, for embedding in the PDF ticket. Prefers a PNG (via GD,
 * present on nearly all hosts) and falls back to SVG so a host without GD still
 * gets a scannable code. Pure library, no external service is called.
 *
 * WHY THIS DRAWS THE CODE ITSELF.
 *
 * This used to call chillerlan/php-qrcode, which renders for you. wordpress.org pended the
 * plugin on 2026-10-15 for "Non-GPL Code Included": that library carries ZXing-derived files
 * under Apache-2.0, which is compatible with GPLv3 but NOT with the GPLv2-or-later the directory
 * requires. It is not only the decoder either - MaskPattern, GF256 and GenericGFPoly are Apache
 * and are the Reed-Solomon maths every encode needs, so there was nothing to prune.
 *
 * bacon/bacon-qr-code is BSD-2-Clause throughout, which is GPL-compatible. It has no GD renderer
 * though (SVG and Imagick only), and dompdf renders an SVG far less reliably than a PNG - so we
 * take only the MATRIX from it and paint the modules here. Fewer moving parts than a renderer
 * stack, the PNG path the tickets depend on is preserved, and the drawing code is ours.
 *
 * @package RebelStudios\Events
 */

namespace RebelStudios\Events;

use BaconQrCode\Common\ErrorCorrectionLevel;
use BaconQrCode\Encoder\Encoder;

defined( 'ABSPATH' ) || exit;

class QR {

	/** Pixels per QR module. 6 keeps a typical check-in code legible on a phone screen. */
	const SCALE = 6;

	/** Quiet zone in modules. The spec says 4; 2 is the smallest that still scans reliably
	 *  and keeps the image inside a ticket layout. */
	const QUIET = 2;

	public static function data_uri( $text ) {
		$autoload = RSEV_PATH . 'vendor/autoload.php';
		if ( is_readable( $autoload ) ) {
			require_once $autoload;
		}
		if ( ! class_exists( Encoder::class ) ) {
			return '';
		}

		try {
			// ISO-8859-1 is the byte mode the spec defaults to and what every scanner expects;
			// the payload here is a URL, so it is always in range.
			$matrix = Encoder::encode( $text, ErrorCorrectionLevel::M(), 'ISO-8859-1' )->getMatrix();

			return extension_loaded( 'gd' ) ? self::png( $matrix ) : self::svg( $matrix );
		} catch ( \Throwable $e ) {
			return '';
		}
	}

	/**
	 * Paint the matrix with GD. Returns a base64 data: URI, or '' if GD fails on this host.
	 */
	private static function png( $matrix ) {
		$modules = $matrix->getWidth();
		$side    = ( $modules + self::QUIET * 2 ) * self::SCALE;

		$img = imagecreatetruecolor( $side, $side );
		if ( ! $img ) {
			return self::svg( $matrix );
		}
		$white = imagecolorallocate( $img, 255, 255, 255 );
		$black = imagecolorallocate( $img, 0, 0, 0 );
		imagefilledrectangle( $img, 0, 0, $side, $side, $white );

		for ( $y = 0; $y < $matrix->getHeight(); $y++ ) {
			for ( $x = 0; $x < $modules; $x++ ) {
				if ( ! $matrix->get( $x, $y ) ) {
					continue;
				}
				$px = ( $x + self::QUIET ) * self::SCALE;
				$py = ( $y + self::QUIET ) * self::SCALE;
				imagefilledrectangle( $img, $px, $py, $px + self::SCALE - 1, $py + self::SCALE - 1, $black );
			}
		}

		ob_start();
		imagepng( $img );
		$raw = ob_get_clean();
		imagedestroy( $img );

		return $raw ? 'data:image/png;base64,' . base64_encode( $raw ) : '';
	}

	/**
	 * The no-GD fallback. One <rect> per dark module: larger than a PNG, but it scans, and a
	 * host without GD is rare enough that size is not worth a second code path to optimise.
	 */
	private static function svg( $matrix ) {
		$modules = $matrix->getWidth();
		$side    = $modules + self::QUIET * 2;

		$rects = '';
		for ( $y = 0; $y < $matrix->getHeight(); $y++ ) {
			for ( $x = 0; $x < $modules; $x++ ) {
				if ( $matrix->get( $x, $y ) ) {
					$rects .= sprintf( '<rect x="%d" y="%d" width="1" height="1"/>', $x + self::QUIET, $y + self::QUIET );
				}
			}
		}

		$svg = sprintf(
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %1$d %1$d" shape-rendering="crispEdges">'
				. '<rect width="%1$d" height="%1$d" fill="#fff"/><g fill="#000">%2$s</g></svg>',
			$side,
			$rects
		);

		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}
}
