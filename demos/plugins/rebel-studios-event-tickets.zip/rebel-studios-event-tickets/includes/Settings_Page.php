<?php
namespace RebelStudios\Events;

use RebelStudios\Events\Engine\Admin;
use RebelStudios\Events\Engine\Freemium;
use RebelStudios\Events\Engine\Settings;

defined( 'ABSPATH' ) || exit;

class Settings_Page {

	const SAVE = 'rsev_save_settings';

	public function hooks() {
		add_action(
			'admin_menu',
			function () {
				add_submenu_page(
					'edit.php?post_type=' . Event_CPT::TYPE,
					__( 'Ticket Settings', 'rebel-studios-event-tickets' ),
					__( 'Settings', 'rebel-studios-event-tickets' ),
					'manage_options',
					Admin::MENU_SLUG,
					array( $this, 'render' )
				);
			}
		);
		add_action( 'admin_post_' . self::SAVE, array( $this, 'save' ) );
	}

	public function save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'rebel-studios-event-tickets' ), 403 );
		}
		check_admin_referer( self::SAVE );
		$in     = wp_unslash( $_POST );
		$values = array(
			'organizer_name'  => $in['organizer_name'] ?? '',
			'organizer_email' => $in['organizer_email'] ?? '',
			'logo_id'         => $in['logo_id'] ?? 0,
			'accent_color'    => $in['accent_color'] ?? '#7c3aed',
			'ticket_footer'   => $in['ticket_footer'] ?? '',
			'send_ticket'     => $in['send_ticket'] ?? 'no',
			'paper'           => $in['paper'] ?? 'a4',
			'delete_on_uninstall' => 'yes' === ( $in['delete_on_uninstall'] ?? 'no' ) ? 'yes' : 'no',
		);
		if ( isset( $in['tickets_per_ip'] ) ) { // A number, not a checkbox: absent means unchanged.
			$values['tickets_per_ip'] = $in['tickets_per_ip'];
		}
		Settings::update( $values );
		wp_safe_redirect( add_query_arg( array( 'post_type' => Event_CPT::TYPE, 'page' => Admin::MENU_SLUG, 'updated' => 1 ), admin_url( 'edit.php' ) ) );
		exit;
	}

	public function render() {
		$s = Settings::all();
		?>
		<div class="wrap">
			<?php Admin::header( __( 'Event Ticket Settings', 'rebel-studios-event-tickets' ) ); ?>
			<?php if ( isset( $_GET['updated'] ) ) { echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'rebel-studios-event-tickets' ) . '</p></div>'; } ?>
			<?php if ( ! Renderer::is_pdf_available() ) { echo '<div class="notice notice-warning"><p>' . esc_html__( 'This host lacks the PHP DOM or mbstring extension, so tickets cannot be made as PDFs. Ticket emails link to each ticket\'s page instead, which shows its QR code.', 'rebel-studios-event-tickets' ) . '</p></div>'; } ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
				<?php wp_nonce_field( self::SAVE ); ?>
				<table class="form-table" role="presentation">
					<tr><th><label for="organizer_name"><?php esc_html_e( 'Organizer name', 'rebel-studios-event-tickets' ); ?></label></th>
						<td><input name="organizer_name" id="organizer_name" class="regular-text" value="<?php echo esc_attr( $s['organizer_name'] ); ?>"></td></tr>
					<tr><th><label for="organizer_email"><?php esc_html_e( 'Organizer email', 'rebel-studios-event-tickets' ); ?></label></th>
						<td><input name="organizer_email" id="organizer_email" type="email" class="regular-text" value="<?php echo esc_attr( $s['organizer_email'] ); ?>"></td></tr>
					<tr><th><?php esc_html_e( 'Logo', 'rebel-studios-event-tickets' ); ?></th>
						<td>
							<input type="hidden" name="logo_id" id="wcinv_logo_id" value="<?php echo esc_attr( $s['logo_id'] ); ?>">
							<div id="wcinv_logo_preview" style="margin-bottom:6px"><?php if ( $s['logo_id'] ) { echo wp_get_attachment_image( (int) $s['logo_id'], array( 160, 80 ) ); } ?></div>
							<button type="button" class="button" id="wcinv_logo_pick"><?php esc_html_e( 'Choose logo', 'rebel-studios-event-tickets' ); ?></button>
							<button type="button" class="button" id="wcinv_logo_clear"><?php esc_html_e( 'Remove', 'rebel-studios-event-tickets' ); ?></button>
						</td></tr>
					<tr><th><label for="accent_color"><?php esc_html_e( 'Accent color', 'rebel-studios-event-tickets' ); ?></label></th>
						<td><input name="accent_color" id="accent_color" value="<?php echo esc_attr( $s['accent_color'] ); ?>" placeholder="#7c3aed"></td></tr>
					<tr><th><label for="ticket_footer"><?php esc_html_e( 'Ticket footer', 'rebel-studios-event-tickets' ); ?></label></th>
						<td><textarea name="ticket_footer" id="ticket_footer" class="large-text" rows="2"><?php echo esc_textarea( $s['ticket_footer'] ); ?></textarea></td></tr>
					<tr><th><?php esc_html_e( 'Email PDF ticket', 'rebel-studios-event-tickets' ); ?></th>
						<td><label><input type="checkbox" name="send_ticket" value="yes" <?php checked( $s['send_ticket'], 'yes' ); ?>> <?php esc_html_e( 'Email each attendee a PDF ticket on registration', 'rebel-studios-event-tickets' ); ?></label></td></tr>
					<tr><th><?php esc_html_e( 'Paper size', 'rebel-studios-event-tickets' ); ?></th>
						<td><label><input type="radio" name="paper" value="a4" <?php checked( $s['paper'], 'a4' ); ?>> A4</label>
						<label style="margin-left:1em"><input type="radio" name="paper" value="letter" <?php checked( $s['paper'], 'letter' ); ?>> <?php esc_html_e( 'Letter', 'rebel-studios-event-tickets' ); ?></label></td></tr>
					<tr><th><?php esc_html_e( 'Attendee data', 'rebel-studios-event-tickets' ); ?></th>
						<td><label><input type="checkbox" name="delete_on_uninstall" value="yes" <?php checked( $s['delete_on_uninstall'], 'yes' ); ?>> <?php esc_html_e( 'When this plugin is deleted, delete every ticket too (attendee names and emails)', 'rebel-studios-event-tickets' ); ?></label>
						<p class="description"><?php esc_html_e( 'Left off, tickets stay, so deleting and reinstalling the plugin keeps your attendee lists. Events always stay. To remove one person, use Tools → Erase Personal Data.', 'rebel-studios-event-tickets' ); ?></p></td></tr>
					<tr><th><label for="tickets_per_ip"><?php esc_html_e( 'Tickets per connection', 'rebel-studios-event-tickets' ); ?></label></th>
						<td><input name="tickets_per_ip" id="tickets_per_ip" type="number" min="0" step="1" class="small-text" value="<?php echo esc_attr( $s['tickets_per_ip'] ); ?>"> <?php esc_html_e( 'free tickets per event, per hour, from one network address', 'rebel-studios-event-tickets' ); ?>
						<p class="description"><?php esc_html_e( 'Stops one visitor or script from booking a whole event. Everyone on one network shares its address: an office, a school, a venue\'s wifi, or every visitor if your site sits behind a proxy that hides their addresses. If many attendees register from one place, raise this, or set 0 for no limit. Anyone who can edit the event is never limited.', 'rebel-studios-event-tickets' ); ?></p></td></tr>
				</table>
				<h2><?php esc_html_e( 'Paid tickets', 'rebel-studios-event-tickets' ); ?> <?php echo wp_kses_post( Freemium::is_pro() ? '' : Freemium::badge( 'paid_section' ) ); ?></h2>
				<p class="description"><?php esc_html_e( 'Paid tickets through your own WooCommerce checkout, and several ticket types per event, are in Pro. The free plugin handles unlimited free RSVP events.', 'rebel-studios-event-tickets' ); ?></p>
				<?php submit_button( __( 'Save settings', 'rebel-studios-event-tickets' ) ); ?>
			</form>
			<hr>
			<h2><?php esc_html_e( 'Shortcodes', 'rebel-studios-event-tickets' ); ?></h2>
			<p><code>[rsev_events]</code> — <?php esc_html_e( 'a list of upcoming events.', 'rebel-studios-event-tickets' ); ?><br>
			<code>[rsev_event_register id="123"]</code> — <?php esc_html_e( 'the registration form for one event.', 'rebel-studios-event-tickets' ); ?></p>
		</div>
		<?php
	}
}
