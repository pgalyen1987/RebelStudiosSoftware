=== Rebel Studios Membership & Content Restriction ===
Contributors: rebelstudios
Tags: membership, content restriction, members, restrict content, members directory
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Restrict any page or post to logged-in users or members, with a front-end registration form, login, and a members directory. No account limits.

== Description ==

Turn any WordPress site into a members area. Restrict individual pages and posts to **logged-in users** or to **members** you approve, give visitors a front-end **registration** and **login** form, and show a **members directory** — all from three shortcodes and a box in the post editor.

Built to stay out of your way: no page builder lock-in, no account limits on the free plugin, and it never breaks your theme — restricted content is simply replaced with a message and a "Join" call to action.

= What the free plugin does =

* **Restrict any content.** Every page and post gets an "Access & Membership" box: leave it public, limit it to logged-in users, or limit it to members. Editors and admins always see everything.
* **Unlimited free members.** Register as many members as you like — no cap, no per-member fees.
* **Front-end registration** — `[rsmb_register]` drops a clean sign-up form on any page; new members get the Subscriber role and are flagged as members automatically.
* **Front-end login** — `[rsmb_login]` shows a login form so members never have to touch wp-admin.
* **Members directory** — `[rsmb_directory]` lists your members with avatars, and optional short bios.
* **Your branding, no code.** Set the members-only message, the accent color, and the redirect after joining from one settings screen.
* **Never breaks anything.** Restricted content is replaced with your message inside the normal page — no fatal errors, no white screens, no theme conflicts.

= Why this plugin =

Most membership plugins either cap your free members, bury basic content restriction behind a paywall, or take over your whole site with their own pages and templates. This one keeps the essentials free and works with the pages you already have.

= Pro =

[Pro](https://rebelstudiossoftware.com/membership-content-restriction) adds **paid memberships** sold through your own WooCommerce checkout, **access that expires** after a set number of days, and **membership tiers** you can restrict content to. The free plugin handles unlimited free members and content restriction on its own.

== Installation ==

1. Upload the plugin to `wp-content/plugins/` or install it from Plugins → Add New.
2. Activate it.
3. Go to **Membership** in the admin menu to set your members-only message and options.
4. Add the shortcodes `[rsmb_register]`, `[rsmb_login]` and `[rsmb_directory]` to pages, and restrict any page or post from the "Access & Membership" box in its editor.

== Frequently Asked Questions ==

= Does it limit how many members I can have? =

No. The free plugin supports unlimited members.

= Can I charge for membership? =

Charging for membership (through WooCommerce), expiring access and tiers are in Pro. The free plugin handles free members and content restriction.

= What happens to restricted content for visitors who can't see it? =

The content is replaced, inside the normal page, with your members-only message and links to log in or join. The same check runs wherever the post can be read: the blog index, search, RSS and Atom feeds, embeds and the REST API. Its comments are hidden with it.

What stays public: the title, the date, the author and any featured image, so visitors can see what they would be joining for. Content that another plugin copies out of the post into its own pages or files is outside this plugin's reach.

= Does it work with my theme? =

Yes. It uses standard WordPress hooks and shortcodes and doesn't replace your theme's templates.

== Screenshots ==

1. The "Access & Membership" box on the post editor — public, logged-in users, or members.
2. The front-end registration form.
3. The members directory.
4. The settings screen.

== Other plugins by Rebel Studios ==

Focused WooCommerce plugins that each do one job well:

* **[Rebel Studios Event Tickets & QR Check-in](https://rebelstudiossoftware.com/wc-events-pro)** — events, RSVP and QR tickets you scan at the door.
* **[Invoice Documents for WooCommerce](https://wordpress.org/plugins/rebel-studios-invoice-documents-woocommerce/)** — automatic PDF invoices, packing slips and delivery notes.
* **[Brazilian Checkout Fields for WooCommerce](https://rebelstudiossoftware.com/checkout-brasil.html)** — CPF/CNPJ validation and CEP autofill for Brazilian stores.
* **[Restaurant Menu & Reservations](https://rebelstudiossoftware.com/wc-restaurant.html)** — a menu, table reservations and QR ordering.

== Changelog ==

= 1.1.1 =
* Security fix: members-only posts could be read without an account through the REST API, RSS and Atom feeds, the blog index, search and embeds, because the check ran only on the post's own page. The rule is now decided by the post wherever it appears, including hand-written excerpts and Pro membership tiers.
* Security fix: comments on a restricted post were public. They now follow the post's rule.

= 1.1.0 =
* Improvement: the members-only notice leads with "Become a member", with "Log in" beside it for existing members.
* Improvement: redesigned join, login and directory cards; members without a Gravatar show their initials.
* Fix: the settings screen and this readme described Pro as having Stripe and content dripping. It has neither: Pro sells membership plans through your WooCommerce checkout, with expiry and tiers.
* Developer: `rsmb_directory_avatar_default` filter.

= 1.0.1 =
* Fix: "Join" on the members-only notice led to WordPress's registration screen, which is switched off on a default site; it now opens the page with the sign-up form.
* New: a logged-in visitor who is not yet a member can become one in one click (from the sign-up form or the members-only notice).
* Fix: the member directory listed people whose membership had lapsed.
* Improvement: the stylesheet now loads only where membership forms or restricted content appear.
* Fix: the Membership menu and its Members screen linked to a page that did not exist ("not allowed").

= 1.0.0 =
* Initial release: content restriction, front-end registration and login, members directory.
