#!/usr/bin/env bash
# Produce the distributable zip: copy the plugin, drop dev files and vendor
# cruft, and package. Run from the plugin root.
set -euo pipefail
SLUG="rebel-studios-membership-content-restriction"
VERSION="$(grep -m1 "Version:" "${SLUG}.php" | sed -E 's/.*Version: *([0-9.]+).*/\1/')"
STAGE="build/${SLUG}"
rm -rf build
mkdir -p "$STAGE"

# Copy everything except the dist-ignored paths.
rsync -a --exclude-from=.distignore ./ "$STAGE/"

# Trim vendor to what ships: no tests, docs, examples, VCS metadata.
find "$STAGE/vendor" -type d \( -iname test -o -iname tests -o -iname doc -o -iname docs -o -iname examples -o -iname .github \) -prune -exec rm -rf {} + 2>/dev/null || true
find "$STAGE/vendor" -type f \( -iname '*.md' -o -iname '*.dist' -o -iname 'phpunit*' -o -iname '.gitignore' -o -iname '.gitattributes' \) -delete 2>/dev/null || true

rm -f "${SLUG}-${VERSION}.zip"
( cd build && zip -qr "../${SLUG}-${VERSION}.zip" "${SLUG}" )
SIZE="$(du -h "${SLUG}-${VERSION}.zip" | cut -f1)"
echo "built ${SLUG}-${VERSION}.zip (${SIZE})"
