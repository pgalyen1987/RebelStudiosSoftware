<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
delete_option( 'rsmb_settings' );
